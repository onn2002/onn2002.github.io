<div class="flex flex-col gap-4">
    <div>
        <h2 class="text-base font-semibold text-gray-900">
            Folder status
        </h2>
        <p class="text-sm text-gray-500">
            Review required folders for this milestone. Uploads update immediately after each action.
        </p>
    </div>

    <!--[if BLOCK]><![endif]--><?php if($tiles === []): ?>
        <div class="rounded-xl border border-dashed border-gray-200 bg-white p-6 text-sm text-gray-500">
            No folder templates are defined for this milestone yet. Once templates are published, you'll see status tiles here.
        </div>
    <?php else: ?>
        <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isSelected = $selectedFolder === $tile['slug'];
                ?>

                <div
                    wire:key="tile-<?php echo e($tile['slug']); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'flex flex-col gap-4 rounded-xl border bg-white p-4 shadow-sm transition',
                        'border-primary-500 ring-2 ring-primary-200' => $isSelected,
                        'border-gray-200' => ! $isSelected,
                    ]); ?>"
                >
                    <div class="flex items-start justify-between gap-4">
                        <div class="space-y-1">
                            <h3 class="text-sm font-semibold text-gray-900">
                                <?php echo e($tile['label']); ?>

                            </h3>
                            <p class="text-xs text-gray-500">
                                <?php echo e($tile['required'] ? 'Required folder' : 'Optional folder'); ?>

                            </p>
                        </div>
                        <span class="text-2xl leading-none">
                            <?php echo e($tile['done'] ? '✅' : '❌'); ?>

                        </span>
                    </div>

                    <div class="rounded-lg border border-gray-100 bg-gray-50 px-3 py-2 text-sm">
                        <div class="flex items-center justify-between text-gray-600">
                            <span>You / Total</span>
                            <span class="font-semibold text-gray-900">
                                <?php echo e($tile['you']); ?> / <?php echo e($tile['total']); ?>

                            </span>
                        </div>
                    </div>

                    <div class="mt-auto flex flex-wrap gap-2">
                        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['type' => 'button','size' => 'xs','color' => 'gray','wire:click' => 'selectFolder(\''.e($tile['slug']).'\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','size' => 'xs','color' => 'gray','wire:click' => 'selectFolder(\''.e($tile['slug']).'\')']); ?>
                            View files
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['type' => 'button','size' => 'xs','wire:click' => 'openUpload(\''.e($tile['slug']).'\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','size' => 'xs','wire:click' => 'openUpload(\''.e($tile['slug']).'\')']); ?>
                            Upload
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\user\OneDrive\Desktop\ciclearning-main\ciclearning-main\resources\views/livewire/lecturer/folder-tile-grid.blade.php ENDPATH**/ ?>