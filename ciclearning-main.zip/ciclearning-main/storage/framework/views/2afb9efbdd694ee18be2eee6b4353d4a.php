<?php
    $nodeId = $node['id'];
    $isSelected = $selectedNodeId === $nodeId;
    $viewingAll = $this->viewingAllMilestones ?? false;
    $displayPath = $viewingAll
        ? ($node['display_path'] ?? $node['path'] ?? '')
        : ($node['path'] ?? '');
?>

<li
    wire:key="node-<?php echo e($nodeId); ?>"
    data-node-id="<?php echo e($nodeId); ?>"
    class="rounded-xl"
>
    <div
        role="treeitem"
        tabindex="0"
        aria-selected="<?php echo e($isSelected ? 'true' : 'false'); ?>"
        wire:click="selectNode(<?php echo e($nodeId); ?>)"
        wire:keydown.enter.prevent="selectNode(<?php echo e($nodeId); ?>)"
        wire:keydown.space.prevent="selectNode(<?php echo e($nodeId); ?>)"
        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'group flex cursor-pointer flex-col gap-1 rounded-xl border px-3 py-2 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2',
            'border-primary-200 bg-primary-50 ring-2 ring-primary-200' => $isSelected,
            'border-transparent bg-white hover:border-primary-200 hover:bg-primary-50/40' => ! $isSelected,
        ]); ?>"
    >
        <div class="flex items-center gap-2">
            <span
                data-drag-handle
                tabindex="-1"
                class="flex h-6 w-6 cursor-grab items-center justify-center rounded-md text-gray-400 transition group-hover:text-primary-500 group-focus-within:text-primary-500"
                title="Drag to reorder"
                aria-hidden="true"
                onmousedown="event.stopPropagation();"
                onclick="event.stopPropagation();"
            >
                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-o-bars-3','class' => 'h-4 w-4 cursor-grab']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-o-bars-3','class' => 'h-4 w-4 cursor-grab']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
            </span>
            <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => $node['required'] ? 'heroicon-o-check-circle' : 'heroicon-o-minus-circle','class' => \Illuminate\Support\Arr::toCssClasses([
                    'h-5 w-5 flex-shrink-0',
                    'text-emerald-500' => $node['required'],
                    'text-gray-400' => ! $node['required'],
                ])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($node['required'] ? 'heroicon-o-check-circle' : 'heroicon-o-minus-circle'),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses([
                    'h-5 w-5 flex-shrink-0',
                    'text-emerald-500' => $node['required'],
                    'text-gray-400' => ! $node['required'],
                ]))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
            <div class="flex flex-1 items-center gap-2 truncate">
                <span class="truncate text-sm font-medium text-gray-900"><?php echo e($node['label']); ?></span>
            </div>
        </div>
        <div class="truncate text-xs text-gray-500">/<?php echo e($displayPath); ?></div>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(! empty($node['children'])): ?>
        <ul class="ml-3 mt-2 space-y-2 border-l border-gray-200 pl-3" data-folder-list role="group">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $node['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('livewire.admin.partials.folder-node', ['node' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    <?php else: ?>
        <ul class="ml-3 mt-2 space-y-2 border-l border-transparent pl-3" data-folder-list role="group"></ul>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</li>
<?php /**PATH C:\Users\user\OneDrive\Desktop\ciclearning-main\ciclearning-main\resources\views/livewire/admin/partials/folder-node.blade.php ENDPATH**/ ?>