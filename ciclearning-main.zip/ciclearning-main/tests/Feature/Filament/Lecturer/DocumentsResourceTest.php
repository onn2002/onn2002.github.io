<?php

use App\Models\Document;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    $this->seed(RolesAndPermissionsSeeder::class);
});

it('allows lecturers to access the documents resource index', function (): void {
    $lecturer = User::factory()->create();
    $lecturer->assignRole('lecturer');

    $response = $this->actingAs($lecturer)->get(route('filament.lecturer.resources.documents.index'));

    $response->assertOk()
        ->assertSeeText('Documents');
});

it('forbids access to the documents resource for users without the lecturer role', function (): void {
    $user = User::factory()->create();

    $this->actingAs($user)
        ->get(route('filament.lecturer.resources.documents.index'))
        ->assertForbidden();
});

it('forbids unverified lecturers from accessing the documents resource', function (): void {
    $lecturer = User::factory()->unverified()->create();
    $lecturer->assignRole('lecturer');

    $this->actingAs($lecturer)
        ->get(route('filament.lecturer.resources.documents.index'))
        ->assertForbidden();
});

it('shows only documents uploaded by the authenticated lecturer', function (): void {
    $lecturer = User::factory()->create();
    $lecturer->assignRole('lecturer');

    $otherLecturer = User::factory()->create();
    $otherLecturer->assignRole('lecturer');

    $ownDocument = Document::factory()
        ->for($lecturer, 'uploader')
        ->create([
            'stored_filename' => 'own-document.pdf',
            'original_filename' => 'Own Document.pdf',
        ]);

    $otherDocument = Document::factory()
        ->for($otherLecturer, 'uploader')
        ->create([
            'stored_filename' => 'other-document.pdf',
            'original_filename' => 'Other Document.pdf',
        ]);

    $response = $this->actingAs($lecturer)->get(route('filament.lecturer.resources.documents.index'));

    $response->assertOk()
        ->assertSeeText($ownDocument->stored_filename)
        ->assertSeeText($ownDocument->original_filename)
        ->assertDontSeeText($otherDocument->stored_filename)
        ->assertDontSeeText($otherDocument->original_filename);
});
