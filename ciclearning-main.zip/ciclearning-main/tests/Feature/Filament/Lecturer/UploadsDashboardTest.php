<?php

use App\Enums\Milestone;
use App\Livewire\Lecturer\FolderFileList;
use App\Livewire\Lecturer\UploadModal;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\Document;
use App\Models\Programme;
use App\Models\User;
use App\Services\DocumentOperationsService;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Livewire\Features\SupportFileUploads\FileUploadConfiguration;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;
use Livewire\Livewire;
use Spatie\Permission\Models\Role;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    Role::findOrCreate('lecturer');
    Role::findOrCreate('admin');
});

afterEach(function (): void {
    Mockery::close();
});

it('redirects guests to the lecturer login page', function (): void {
    $response = $this->get('/lecturer/uploads');

    $response->assertRedirect('/lecturer/login');
});

it('requires lecturers to verify their email before accessing uploads', function (): void {
    $lecturer = makeLecturerUser(verified: false);

    $response = $this->actingAs($lecturer)->get('/lecturer/uploads');

    $response->assertForbidden();
});

it('shows only assigned offerings to a lecturer', function (): void {
    $lecturer = makeLecturerUser();
    $offerings = setupOfferingsForLecturer($lecturer);

    $response = $this->actingAs($lecturer)->get('/lecturer/uploads');

    $response->assertSuccessful()
        ->assertSee($offerings['assigned']['label'], escape: false)
        ->assertDontSee($offerings['unassigned']['label'], escape: false);
});

it('allows admins to access the uploads dashboard', function (): void {
    $admin = makeAdminUser();

    $response = $this->actingAs($admin)->get('/lecturer/uploads');

    $response->assertSuccessful()
        ->assertSeeText('Documents Management');
});

it('stores a file through the upload modal component', function (): void {
    config(['media-library.disk_name' => 'local']);
    Storage::fake('local');

    $lecturer = makeLecturerUser();
    $offerings = setupOfferingsForLecturer($lecturer);
    $assigned = $offerings['assigned'];
    $leaf = $assigned['leaf'];

    CarbonImmutable::setTestNow('2025-06-01 09:00:00', 'Asia/Kuala_Lumpur');

    Livewire::test(UploadModal::class, [
        'offeringId' => $assigned['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'userId' => $lecturer->id,
    ])
        ->call('openUpload', $leaf->pathString())
        ->set('file', UploadedFile::fake()->create('Lecture Outline.pdf', 128, 'application/pdf'))
        ->call('submit')
        ->assertDispatched('documents-updated')
        ->assertDispatched('open-files');

    CarbonImmutable::setTestNow();

    $document = $lecturer->documents()->first();

    expect($document)->not->toBeNull();

    $expectedPath = implode('/', [
        $assigned['programme']->code,
        $assigned['session']->code,
        $assigned['offering']->fresh()->course_identifier,
        Milestone::FinalExamPackage->pathSegment(),
        $leaf->pathString(),
        $document->stored_filename,
    ]);

    Storage::disk('local')->assertExists($expectedPath);
});

it('only exposes replace and delete actions in the folder file list', function (): void {
    $lecturer = makeLecturerUser();
    $offerings = setupOfferingsForLecturer($lecturer);
    $assigned = $offerings['assigned'];
    $leaf = $assigned['leaf'];

    $document = Document::factory()->create([
        'offering_id' => $assigned['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'folder_slug' => $leaf->pathString(),
        'uploader_id' => $lecturer->id,
        'path_string' => 'documents/'.$leaf->pathString().'/'.$assigned['offering']->id.'.pdf',
    ]);

    expect($document)->not->toBeNull();

    $this->actingAs($lecturer);

    $component = Livewire::test(FolderFileList::class, [
        'offeringId' => $assigned['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'userId' => $lecturer->id,
    ]);

    $actionNames = (function (): array {
        /** @var array<int, \Filament\Tables\Actions\Action> $actions */
        $actions = $this->getTableActions();

        return collect($actions)
            ->map(fn ($action) => $action->getName())
            ->all();
    })->call($component->instance());

    expect($actionNames)->toEqual(['replace', 'delete']);

    $component
        ->call('openFolder', $leaf->pathString())
        ->assertSeeText('Replace')
        ->assertSeeText('Delete')
        ->assertDontSeeText('Rename');
});

it('runs delete table action without root tag errors', function (): void {
    $lecturer = makeLecturerUser();
    $offerings = setupOfferingsForLecturer($lecturer);
    $assigned = $offerings['assigned'];
    $leaf = $assigned['leaf'];

    $document = Document::factory()->create([
        'offering_id' => $assigned['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'folder_slug' => $leaf->pathString(),
        'uploader_id' => $lecturer->id,
        'path_string' => 'documents/'.$leaf->pathString().'/'.$assigned['offering']->id.'.pdf',
    ]);

    $this->actingAs($lecturer);

    Livewire::test(FolderFileList::class, [
        'offeringId' => $assigned['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'userId' => $lecturer->id,
    ])
        ->call('openFolder', $leaf->pathString())
        ->callTableAction('delete', $document)
        ->assertDispatched('documents-updated');
});

it('converts serialized uploads when running the replace action', function (): void {
    Storage::fake('tmp-for-tests');

    $lecturer = makeLecturerUser();
    $offerings = setupOfferingsForLecturer($lecturer);
    $assigned = $offerings['assigned'];
    $leaf = $assigned['leaf'];

    $document = Document::factory()->create([
        'offering_id' => $assigned['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'folder_slug' => $leaf->pathString(),
        'uploader_id' => $lecturer->id,
        'path_string' => 'documents/'.$leaf->pathString().'/'.$assigned['offering']->id.'.pdf',
    ]);

    $fakeUpload = UploadedFile::fake()->create('Replacement.pdf', 64, 'application/pdf');
    $serializedFilename = TemporaryUploadedFile::generateHashNameWithOriginalNameEmbedded($fakeUpload);

    Storage::disk('tmp-for-tests')->put(
        FileUploadConfiguration::path($serializedFilename, false),
        'dummy content'
    );

    $this->actingAs($lecturer);

    $service = Mockery::mock(DocumentOperationsService::class);
    $service
        ->shouldReceive('replace')
        ->once()
        ->withArgs(function (Document $record, UploadedFile $file) use ($document) {
            return $record->is($document) && $file instanceof UploadedFile;
        })
        ->andReturn($document);

    $this->instance(App\Services\DocumentOperationsService::class, $service);

    Livewire::test(FolderFileList::class, [
        'offeringId' => $assigned['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'userId' => $lecturer->id,
    ])
        ->call('openFolder', $leaf->pathString())
        ->callTableAction('replace', $document, [
            'file' => ['livewire-file:'.$serializedFilename],
        ])
        ->assertDispatched('documents-updated');
});

/**
 * @return array{
 *     offering: CourseOffering,
 *     programme: Programme,
 *     session: AcademicSession,
 *     leaf: FolderTemplateNode,
 *     label: string
 * }
 */
function setupOfferingsForLecturer(User $lecturer): array
{
    $programme = Programme::factory()->create(['code' => 'FOCS']);
    $session = AcademicSession::factory()->create(['code' => '2024S1']);
    $course = Course::factory()->create([
        'course_code' => 'CS101',
        'title' => 'Introduction to Computing',
        'title_slug' => 'introduction-to-computing',
    ]);

    $assignedOffering = CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $course->id,
    ]);

    $assignedOffering->lecturers()->attach($lecturer);

    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::FinalExamPackage,
        'label' => 'Final Package',
    ]);

    $root = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->create(['label' => 'Course Materials']);

    $leaf = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->forParent($root)
        ->create(['label' => 'Week 01']);

    // Unassigned offering for negative assertion.
    $unassignedCourse = Course::factory()->create([
        'course_code' => 'CS202',
        'title' => 'Data Structures',
        'title_slug' => 'data-structures',
    ]);

    $unassignedOffering = CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $unassignedCourse->id,
    ]);

    return [
        'assigned' => [
            'offering' => $assignedOffering,
            'programme' => $programme,
            'session' => $session,
            'leaf' => $leaf,
            'label' => sprintf(
                '%s — %s',
                $assignedOffering->fresh()->course?->course_code,
                $assignedOffering->fresh()->course?->title
            ),
        ],
        'unassigned' => [
            'offering' => $unassignedOffering,
            'label' => sprintf(
                '%s — %s',
                $unassignedCourse->course_code,
                $unassignedCourse->title
            ),
        ],
    ];
}

function makeLecturerUser(bool $verified = true): User
{
    /** @var User $user */
    $user = User::factory()->create([
        'email_verified_at' => $verified ? now() : null,
    ]);

    $user->assignRole('lecturer');

    return $user;
}

function makeAdminUser(): User
{
    /** @var User $user */
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $user->assignRole('admin');

    return $user;
}
