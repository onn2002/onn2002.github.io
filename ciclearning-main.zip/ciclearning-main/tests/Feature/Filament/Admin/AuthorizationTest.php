<?php

use App\Filament\Admin\Pages\Settings;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\FolderTemplate;
use App\Models\Programme;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Gate;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

uses(RefreshDatabase::class);

beforeEach(fn () => $this->seed(RolesAndPermissionsSeeder::class));

function createAdminUser(): User
{
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $user->assignRole('admin');

    return $user;
}

function createLecturerUser(): User
{
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $user->assignRole('lecturer');

    return $user;
}

it('allows admins to manage all admin resources', function (): void {
    $admin = createAdminUser();

    expect(Gate::forUser($admin)->allows('viewAny', User::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('create', User::class))->toBeTrue();
    $managedUser = User::factory()->create();
    expect(Gate::forUser($admin)->allows('update', $managedUser))->toBeTrue();

    $role = Role::create([
        'name' => 'qa-manager',
        'guard_name' => 'web',
    ]);
    expect(Gate::forUser($admin)->allows('viewAny', Role::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('create', Role::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('update', $role))->toBeTrue();

    expect(Gate::forUser($admin)->allows('viewAny', Permission::class))->toBeTrue();

    $programme = Programme::factory()->create();
    expect(Gate::forUser($admin)->allows('viewAny', Programme::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('create', Programme::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('update', $programme))->toBeTrue();

    $session = AcademicSession::factory()->create();
    expect(Gate::forUser($admin)->allows('viewAny', AcademicSession::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('create', AcademicSession::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('update', $session))->toBeTrue();

    $course = Course::factory()->create();
    expect(Gate::forUser($admin)->allows('viewAny', Course::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('create', Course::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('update', $course))->toBeTrue();

    $offering = CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $course->id,
    ]);
    expect(Gate::forUser($admin)->allows('viewAny', CourseOffering::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('create', CourseOffering::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('update', $offering))->toBeTrue();
    expect(Gate::forUser($admin)->allows('assignLecturers', $offering))->toBeTrue();

    $template = FolderTemplate::factory()->create();
    expect(Gate::forUser($admin)->allows('viewAny', FolderTemplate::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('create', FolderTemplate::class))->toBeTrue();
    expect(Gate::forUser($admin)->allows('update', $template))->toBeTrue();

    expect(Gate::forUser($admin)->allows('viewAny', Activity::class))->toBeTrue();

    $this->actingAs($admin);
    expect(Settings::canAccess())->toBeTrue();
});

it('prevents lecturers from managing admin resources', function (): void {
    $lecturer = createLecturerUser();

    expect(Gate::forUser($lecturer)->denies('viewAny', Programme::class))->toBeTrue();
    expect(Gate::forUser($lecturer)->denies('create', CourseOffering::class))->toBeTrue();
    expect(Gate::forUser($lecturer)->denies('viewAny', FolderTemplate::class))->toBeTrue();
    expect(Gate::forUser($lecturer)->denies('viewAny', User::class))->toBeTrue();

    $programme = Programme::factory()->create();
    expect(Gate::forUser($lecturer)->denies('update', $programme))->toBeTrue();

    $this->actingAs($lecturer);
    expect(Settings::canAccess())->toBeFalse();
});

it('redirects guests to admin login', function (): void {
    $this->get(route('filament.admin.resources.users.index'))
        ->assertRedirect('/admin/login');
});
