<?php

use App\Filament\Admin\Resources\CourseOfferings\Pages\CreateCourseOffering;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Programme;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    $this->seed(RolesAndPermissionsSeeder::class);
});

function adminForCourseOfferingTests(): User
{
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $user->assignRole('admin');

    return $user;
}

test('course offering combination must be unique', function () {
    $programme = Programme::factory()->create();
    $session = AcademicSession::factory()->create();
    $course = Course::factory()->create();

    CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $course->id,
    ]);

    $this->actingAs(adminForCourseOfferingTests());

    Livewire::test(CreateCourseOffering::class)
        ->set('data', [
            'programme_id' => $programme->id,
            'academic_session_id' => $session->id,
            'course_id' => $course->id,
        ])
        ->call('create')
        ->assertHasErrors(['data.course_id' => ['unique']]);
});

test('assigning the same lecturer twice to an offering is prevented', function () {
    $programme = Programme::factory()->create();
    $session = AcademicSession::factory()->create();
    $course = Course::factory()->create();

    $offering = CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $course->id,
    ]);

    $lecturer = User::factory()->create([
        'email_verified_at' => now(),
    ]);
    $lecturer->assignRole('lecturer');

    $offering->lecturers()->attach($lecturer->id);

    expect(fn () => $offering->lecturers()->attach($lecturer->id))
        ->toThrow(QueryException::class);

    expect($offering->lecturers()->count())->toBe(1);
});
