<?php

namespace Tests\Feature\Filament\Admin;

use App\Models\Course;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CourseResourcePageTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_view_course_create_page(): void
    {
        $this->seed(RolesAndPermissionsSeeder::class);

        $admin = User::factory()->create([
            'email_verified_at' => now(),
        ]);

        $admin->assignRole('admin');

        $response = $this->actingAs($admin)->get('/admin/courses/create');

        $response->assertOk();
    }

    public function test_admin_can_view_course_edit_page(): void
    {
        $this->seed(RolesAndPermissionsSeeder::class);

        $admin = User::factory()->create([
            'email_verified_at' => now(),
        ]);

        $admin->assignRole('admin');

        $course = Course::factory()->create();

        $response = $this->actingAs($admin)->get("/admin/courses/{$course->getRouteKey()}/edit");

        $response->assertOk();
    }
}
