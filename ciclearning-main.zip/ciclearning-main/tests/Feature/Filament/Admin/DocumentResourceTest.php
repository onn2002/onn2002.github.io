<?php

use App\Enums\Milestone;
use App\Filament\Admin\Resources\Documents\Pages\ListDocuments;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\Programme;
use App\Models\User;
use App\Services\DocumentStorageService;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Livewire\Livewire;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    $this->seed(RolesAndPermissionsSeeder::class);
});

it('allows admins to access the documents index', function (): void {
    fakeMediaDisk();

    $admin = makeAdminForDocuments();
    $lecturer = makeLecturerForDocuments();

    $offering = CourseOffering::factory()->create();
    $document = createDocumentForTableTest($offering, $lecturer, Milestone::BeginningOfSemester);

    $this->actingAs($admin)
        ->get(route('filament.admin.resources.documents.index'))
        ->assertOk()
        ->assertSeeText('Documents')
        ->assertSeeText($document->uploader->name);
});

it('prevents lecturers from accessing the documents index', function (): void {
    $lecturer = makeLecturerForDocuments();

    $this->actingAs($lecturer)
        ->get(route('filament.admin.resources.documents.index'))
        ->assertForbidden();
});

it('filters documents by programme milestone and uploader', function (): void {
    fakeMediaDisk();

    $admin = makeAdminForDocuments();

    $programmeA = Programme::factory()->create(['code' => 'ENG']);
    $programmeB = Programme::factory()->create(['code' => 'SCI']);

    $sessionA = AcademicSession::factory()->create(['code' => '2024S1']);
    $sessionB = AcademicSession::factory()->create(['code' => '2024S2']);

    $courseA = Course::factory()->create(['course_code' => 'ENG101', 'title' => 'Engineering Fundamentals']);
    $courseB = Course::factory()->create(['course_code' => 'SCI201', 'title' => 'Advanced Science']);

    $offeringA = CourseOffering::factory()->create([
        'programme_id' => $programmeA->id,
        'academic_session_id' => $sessionA->id,
        'course_id' => $courseA->id,
    ]);

    $offeringB = CourseOffering::factory()->create([
        'programme_id' => $programmeB->id,
        'academic_session_id' => $sessionB->id,
        'course_id' => $courseB->id,
    ]);

    $uploaderA = makeLecturerForDocuments();
    $uploaderB = makeLecturerForDocuments();

    $milestoneA = Milestone::BeginningOfSemester;
    $milestoneB = Milestone::EndOfSemester;

    $documentA = createDocumentForTableTest($offeringA, $uploaderA, $milestoneA);
    $documentB = createDocumentForTableTest($offeringB, $uploaderB, $milestoneB);

    $this->actingAs($admin);

    Livewire::test(ListDocuments::class)
        ->assertCanSeeTableRecords([$documentA, $documentB])
        ->filterTable('programme_id', $programmeA->id)
        ->assertCanSeeTableRecords([$documentA])
        ->assertCanNotSeeTableRecords([$documentB])
        ->resetTableFilters()
        ->filterTable('milestone', $milestoneB->value)
        ->assertCanSeeTableRecords([$documentB])
        ->assertCanNotSeeTableRecords([$documentA])
        ->resetTableFilters()
        ->filterTable('uploader_id', $uploaderA->id)
        ->assertCanSeeTableRecords([$documentA])
        ->assertCanNotSeeTableRecords([$documentB]);
});

function fakeMediaDisk(): void
{
    $disk = config('media-library.disk_name', 'public');

    Storage::fake($disk);
}

function makeAdminForDocuments(): User
{
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $user->assignRole('admin');

    return $user;
}

function makeLecturerForDocuments(): User
{
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $user->assignRole('lecturer');

    return $user;
}

function createDocumentForTableTest(
    CourseOffering $offering,
    User $uploader,
    Milestone $milestone,
    string $filename = 'document.pdf',
    string $mime = 'application/pdf'
): Document {
    $template = FolderTemplate::factory()->create([
        'milestone' => $milestone->value,
    ]);

    $leaf = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->create([
            'label' => 'Reports',
        ]);

    $file = UploadedFile::fake()->create($filename, 200, $mime);

    return app(DocumentStorageService::class)->store(
        $offering,
        $milestone,
        $leaf,
        $file,
        $uploader,
    );
}
