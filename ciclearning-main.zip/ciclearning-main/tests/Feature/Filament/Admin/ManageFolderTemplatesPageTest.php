<?php

use App\Livewire\Admin\FolderTemplateTree;
use App\Models\FolderTemplateNode;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    $this->seed(RolesAndPermissionsSeeder::class);
});

function createAdmin(): User
{
    $admin = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $admin->assignRole('admin');

    return $admin;
}

function createLecturer(): User
{
    $lecturer = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $lecturer->assignRole('lecturer');

    return $lecturer;
}

test('admin can access manage folder templates page', function (): void {
    $admin = createAdmin();

    $this->actingAs($admin)
        ->get(route('filament.admin.pages.folder-templates'))
        ->assertOk()
        ->assertSee('Template management')
        ->assertSee('Node Details');
});

test('lecturer cannot access manage folder templates page', function (): void {
    $lecturer = createLecturer();

    $this->actingAs($lecturer)
        ->get(route('filament.admin.pages.folder-templates'))
        ->assertForbidden();
});

test('component supports node detail editing and deferred reorder', function (): void {
    $admin = createAdmin();
    Livewire::actingAs($admin);

    $component = Livewire::test(FolderTemplateTree::class);

    $component->set('selectedMilestone', 'beginning_of_semester');

    // Add first root folder and rename it.
    $component->call('addRoot');

    $rootA = FolderTemplateNode::whereNull('parent_id')->first();
    expect($rootA)->not->toBeNull();

    $component
        ->set('nodeForm.label', 'Root A')
        ->call('saveNodeDetails')
        ->assertHasNoErrors();

    $rootA->refresh();
    expect($rootA->label)->toBe('Root A')
        ->and($component->get('selectedNodeId'))->toBe($rootA->id);

    // Add a child, set it optional, and rename it.
    $component->call('addChild');

    $child = FolderTemplateNode::where('parent_id', $rootA->id)->first();
    expect($child)->not->toBeNull();

    $component
        ->set('nodeForm.label', 'Child Node')
        ->set('nodeForm.required', false)
        ->call('saveNodeDetails')
        ->assertHasNoErrors();

    $child->refresh();
    expect($child->label)->toBe('Child Node')
        ->and($child->required)->toBeFalse();

    // Add a second root folder.
    $component->call('addRoot');

    $rootB = FolderTemplateNode::whereNull('parent_id')
        ->where('id', '!=', $rootA->id)
        ->first();
    expect($rootB)->not->toBeNull();

    $component
        ->set('nodeForm.label', 'Root B')
        ->call('saveNodeDetails')
        ->assertHasNoErrors();

    $rootB->refresh();
    expect($component->get('selectedNodeId'))->toBe($rootB->id);

    // Reorder by staging the child under Root B. Nothing persists until saveReorder.
    $component->call('selectNode', $rootA->id);

    $component->call('stageReorder', [
        [
            'id' => $rootB->id,
            'children' => [
                ['id' => $child->id, 'children' => []],
            ],
        ],
        ['id' => $rootA->id, 'children' => []],
    ]);

    expect($component->get('hasPendingReorder'))->toBeTrue();

    $stagedTree = $component->get('tree');

    expect($stagedTree)->toHaveCount(2);
    expect($stagedTree[0]['id'])->toBe($rootB->id);
    expect($stagedTree[0]['children'])->toHaveCount(1);
    expect($stagedTree[0]['children'][0]['id'])->toBe($child->id);

    $child->refresh();
    expect($child->parent_id)->toBe($rootA->id);

    $component->call('saveReorder')
        ->assertHasNoErrors();

    $child->refresh();
    expect($child->parent_id)->toBe($rootB->id)
        ->and($child->depth)->toBe(2);

    expect($component->get('hasPendingReorder'))->toBeFalse();

    // Attempting to delete Root B with children leaves it intact.
    $component->call('selectNode', $rootB->id);
    $component->call('deleteSelected');

    expect(FolderTemplateNode::whereKey($rootB->id)->exists())->toBeTrue();

    // Delete the child node and ensure selection clears.
    $component->call('selectNode', $child->id);
    $component->call('deleteSelected');

    expect(FolderTemplateNode::whereKey($child->id)->exists())->toBeFalse();
    expect($component->get('selectedNodeId'))->toBeNull();
});

test('component prevents adding nodes beyond maximum depth', function (): void {
    $admin = createAdmin();
    Livewire::actingAs($admin);

    $component = Livewire::test(FolderTemplateTree::class);

    $component->set('selectedMilestone', 'beginning_of_semester');

    $component->call('addRoot');
    $root = FolderTemplateNode::whereNull('parent_id')->first();
    expect($root)->not->toBeNull();

    $component->set('nodeForm.label', 'Root')->call('saveNodeDetails');

    $component->call('addChild');
    $levelTwo = FolderTemplateNode::where('parent_id', $root->id)->first();
    expect($levelTwo)->not->toBeNull();

    $component->set('nodeForm.label', 'Level Two')->call('saveNodeDetails');

    $component->call('addChild');
    $levelThree = FolderTemplateNode::where('parent_id', $levelTwo->id)->first();
    expect($levelThree)->not->toBeNull();

    $component->set('nodeForm.label', 'Level Three')->call('saveNodeDetails');

    $component->call('addChild');

    expect(FolderTemplateNode::where('parent_id', $levelThree->id)->exists())->toBeFalse();
});
