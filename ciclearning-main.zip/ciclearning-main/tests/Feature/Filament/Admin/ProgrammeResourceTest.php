<?php

use App\Filament\Admin\Resources\Programmes\Pages\CreateProgramme;
use App\Models\Programme;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    $this->seed(RolesAndPermissionsSeeder::class);
});

function adminForProgrammeTests(): User
{
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $user->assignRole('admin');

    return $user;
}

test('programme can be created via filament form', function () {
    $admin = adminForProgrammeTests();

    $this->actingAs($admin);

    Livewire::test(CreateProgramme::class)
        ->set('data', [
            'code' => 'ENG101',
            'name' => 'Engineering',
            'active' => true,
        ])
        ->call('create')
        ->assertHasNoErrors();

    expect(Programme::where('code', 'ENG101')->exists())->toBeTrue();
});

test('programme code must be unique', function () {
    $admin = adminForProgrammeTests();

    Programme::factory()->create([
        'code' => 'FYP',
    ]);

    $this->actingAs($admin);

    Livewire::test(CreateProgramme::class)
        ->set('data', [
            'code' => 'FYP',
            'name' => 'Duplicate Programme',
            'active' => true,
        ])
        ->call('create')
        ->assertHasErrors(['data.code' => ['unique']]);
});
