<?php

use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

beforeEach(function () {
    $this->seed(RolesAndPermissionsSeeder::class);
});

test('guest is redirected to admin login', function () {
    $this->get('/admin')
        ->assertRedirect('/admin/login');
});

test('guest is redirected to lecturer login', function () {
    $this->get('/lecturer')
        ->assertRedirect('/lecturer/login');
});

test('verified admin can access admin and lecturer panels', function () {
    $admin = User::factory()->create();
    $admin->assignRole('admin');

    $this->actingAs($admin);

    $this->get(route('filament.admin.pages.dashboard'))->assertOk();
    $this->get(route('filament.lecturer.pages.dashboard'))->assertOk();
});

test('verified lecturer cannot access admin panel but can access lecturer panel', function () {
    $lecturer = User::factory()->create();
    $lecturer->assignRole('lecturer');

    $this->actingAs($lecturer);

    $this->get(route('filament.lecturer.pages.dashboard'))->assertOk();
    $this->get(route('filament.admin.pages.dashboard'))->assertForbidden();
});

test('unverified user cannot access either panel', function () {
    $user = User::factory()->unverified()->create();
    $user->assignRole('admin');

    $this->actingAs($user);

    $this->get(route('filament.admin.pages.dashboard'))->assertForbidden();
    $this->get(route('filament.lecturer.pages.dashboard'))->assertForbidden();
});

test('user without role cannot access either panel', function () {
    $user = User::factory()->create();

    $this->actingAs($user);

    $this->get(route('filament.admin.pages.dashboard'))->assertForbidden();
    $this->get(route('filament.lecturer.pages.dashboard'))->assertForbidden();
});

test('panel login screens render for guests', function () {
    $this->get('/admin/login')->assertOk();
    $this->get('/lecturer/login')->assertOk();
});
