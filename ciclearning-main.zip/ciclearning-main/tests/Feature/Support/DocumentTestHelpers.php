<?php

use App\Enums\Milestone;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\Programme;
use App\Models\User;
use App\Services\DocumentStorageService;
use App\Services\FolderPathService;
use Carbon\CarbonImmutable;
use Illuminate\Http\UploadedFile;

/**
 * @return array{
 *     programme: Programme,
 *     session: AcademicSession,
 *     course: Course,
 *     offering: CourseOffering,
 *     template: FolderTemplate,
 *     leafA: FolderTemplateNode,
 *     leafB: FolderTemplateNode,
 *     user: User
 * }
 */
function setupDocumentEnvironment(): array
{
    $programme = Programme::factory()->create(['code' => 'FOCS']);
    $session = AcademicSession::factory()->create(['code' => '2024S1']);
    $course = Course::factory()->create([
        'course_code' => 'CS101',
        'title' => 'Introduction to Computing',
        'title_slug' => 'introduction-to-computing',
    ]);

    $offering = CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $course->id,
    ]);

    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::FinalExamPackage,
        'label' => 'Final Exam Package',
        'slug' => 'final-exam-package',
    ]);

    $root = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->create(['label' => 'Course Materials']);

    $leafA = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->forParent($root)
        ->create(['label' => 'Week 01']);

    $leafB = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->forParent($root)
        ->create(['label' => 'Week 02']);

    $user = User::factory()->create();

    return compact(
        'programme',
        'session',
        'course',
        'offering',
        'template',
        'leafA',
        'leafB',
        'user'
    );
}

function createStoredDocument(array $setup, string $fileName, string $leafKey): Document
{
    $offering = $setup['offering']->fresh(['programme', 'session', 'course']);
    $leaf = $setup[$leafKey];
    $user = $setup['user'];

    CarbonImmutable::setTestNow('2025-01-05 09:00:00', 'Asia/Kuala_Lumpur');

    $file = UploadedFile::fake()->create($fileName, 128, 'application/pdf');

    $document = app(DocumentStorageService::class)->store(
        $offering,
        Milestone::FinalExamPackage,
        $leaf->fresh(),
        $file,
        $user
    );

    CarbonImmutable::setTestNow();

    return $document->fresh();
}

function documentPath(array $setup, Document $document): string
{
    $offering = $setup['offering']->fresh(['programme', 'session', 'course']);
    $milestone = $document->milestone instanceof Milestone
        ? $document->milestone
        : Milestone::from($document->milestone);

    return app(FolderPathService::class)
        ->buildPathFromSlug($offering, $milestone, $document->folder_slug)
        .$document->stored_filename;
}
