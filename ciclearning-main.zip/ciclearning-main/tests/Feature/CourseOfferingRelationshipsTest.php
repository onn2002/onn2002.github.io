<?php

use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

test('course offering exposes its core relationships', function () {
    $offering = CourseOffering::factory()->create();

    expect($offering->programme)->not->toBeNull();
    expect($offering->session)->not->toBeNull();
    expect($offering->course)->not->toBeNull();
});

test('course offering exposes computed identifiers', function () {
    $offering = CourseOffering::factory()->create();

    $course = $offering->course;

    expect($offering->course_identifier)
        ->toBe($course->course_code.'_'.$course->title_slug);
    expect($offering->programme_code)->toBe($offering->programme->code);
    expect($offering->session_code)->toBe($offering->session->code);
});

test('course offering prevents duplicate lecturer assignments', function () {
    $offering = CourseOffering::factory()->create();
    $lecturer = User::factory()->create();

    $offering->lecturers()->attach($lecturer->id);

    expect(fn () => $offering->lecturers()->attach($lecturer->id))
        ->toThrow(QueryException::class);
});

test('course offering returns related documents', function () {
    $offering = CourseOffering::factory()->create();
    $uploader = User::factory()->create();

    $document = Document::factory()->create([
        'offering_id' => $offering->id,
        'uploader_id' => $uploader->id,
    ]);

    expect($offering->fresh()->documents)
        ->toHaveCount(1)
        ->first()
        ->id->toBe($document->id);
});
