<?php

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Services\FolderPathService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

uses(RefreshDatabase::class);

test('folder path service builds expected path string', function (): void {
    /** @var CourseOffering $offering */
    $offering = CourseOffering::factory()->create();

    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::BeginningOfSemester->value,
    ]);

    $root = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'label' => 'Deliverables',
        'slug' => 'deliverables',
    ]);

    $leaf = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $root->id,
        'label' => 'Final Report',
        'slug' => 'final-report',
    ]);

    $service = app(FolderPathService::class);

    $path = $service->buildPath($offering, Milestone::BeginningOfSemester, $leaf);

    $normalise = static fn (?string $value): ?string => $value
        ? Str::of($value)
            ->replace(['/', '\\'], '-')
            ->trim()
            ->toString()
        : null;

    $expected = collect([
        $normalise($offering->programme?->code ?? 'programme-'.$offering->programme_id),
        $normalise($offering->session?->code ?? 'session-'.$offering->academic_session_id),
        $normalise($offering->course_identifier ?? 'course-'.$offering->course_id),
        Milestone::BeginningOfSemester->pathSegment(),
        $leaf->pathString(),
    ])->filter(fn (?string $segment) => $segment !== null && $segment !== '')->implode('/').'/';

    expect($path)->toBe($expected);
});

test('folder path service resolves only leaf nodes', function (): void {
    $offering = CourseOffering::factory()->create();

    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::MidTermExamination->value,
    ]);

    $root = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'label' => 'Research',
        'slug' => 'research',
    ]);

    $leaf = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $root->id,
        'label' => 'Interview Notes',
        'slug' => 'interview-notes',
    ]);

    $service = app(FolderPathService::class);

    $resolvedByPath = $service->resolveLeafByPath($template, $leaf->pathString());
    $resolvedById = $service->resolveLeafById($template, $leaf->id);

    expect($resolvedByPath->id)->toBe($leaf->id)
        ->and($resolvedById->id)->toBe($leaf->id);

    expect(fn () => $service->resolveLeafByPath($template, $root->pathString()))
        ->toThrow(ValidationException::class);

    expect(fn () => $service->buildPath($offering, Milestone::MidTermExamination, $root))
        ->toThrow(ValidationException::class);
});
