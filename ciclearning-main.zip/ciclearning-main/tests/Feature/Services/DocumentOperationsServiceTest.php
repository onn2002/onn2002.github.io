<?php

require_once __DIR__.'/../Support/DocumentTestHelpers.php';

use App\Models\Document;
use App\Models\User;
use App\Services\DocumentOperationsService;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    config(['media-library.disk_name' => 'local']);
    Storage::fake('local');
});

it('renames a document and updates the stored file', function (): void {
    $setup = setupDocumentEnvironment();

    $document = createStoredDocument($setup, 'Lecture Plan.pdf', 'leafA');
    $originalPath = $document->path_string;
    $originalFilename = $document->stored_filename;

    CarbonImmutable::setTestNow('2025-02-10 08:00:00', 'Asia/Kuala_Lumpur');

    app(DocumentOperationsService::class)->rename($document, 'Updated Plan');

    CarbonImmutable::setTestNow();

    $updated = $document->fresh();
    $newPath = documentPath($setup, $updated);

    Storage::disk('local')->assertMissing($originalPath);
    Storage::disk('local')->assertExists($newPath);

    expect($updated->stored_filename)->not->toBe($originalFilename)
        ->and($updated->path_string)->toBe($newPath)
        ->and($updated->stored_filename)->toContain('Updated');
});

it('appends a suffix when renaming into an existing filename', function (): void {
    $setup = setupDocumentEnvironment();

    $otherUser = User::factory()->create();
    CarbonImmutable::setTestNow('2025-03-01 09:00:00', 'Asia/Kuala_Lumpur');
    createStoredDocument(array_merge($setup, ['user' => $otherUser]), 'Project Outline.pdf', 'leafA');
    CarbonImmutable::setTestNow();

    $document = createStoredDocument($setup, 'Draft.pdf', 'leafA');
    $originalPath = $document->path_string;
    $initialFilename = $document->stored_filename;

    CarbonImmutable::setTestNow('2025-03-01 10:00:00', 'Asia/Kuala_Lumpur');
    app(DocumentOperationsService::class)->rename($document, 'Project Outline');
    CarbonImmutable::setTestNow();

    $updated = $document->fresh();
    $updatedPath = documentPath($setup, $updated);

    Storage::disk('local')->assertMissing($originalPath);
    Storage::disk('local')->assertExists($updatedPath);

    expect($updated->stored_filename)->not->toBe($initialFilename)
        ->and($updated->path_string)->toBe($updatedPath);
});

it('moves a document to a new folder and refreshes metadata', function (): void {
    $setup = setupDocumentEnvironment();

    $document = createStoredDocument($setup, 'Syllabus.pdf', 'leafA');
    $originalPath = $document->path_string;

    app(DocumentOperationsService::class)->move($document, $setup['leafB']);

    $updated = Document::query()->findOrFail($document->id);
    $updatedPath = documentPath($setup, $updated);

    expect($updated->folder_slug)->toBe($setup['leafB']->pathString());

    Storage::disk('local')->assertMissing($originalPath);
    Storage::disk('local')->assertExists($updatedPath);
});

it('renames when moving into a destination with matching filename', function (): void {
    $setup = setupDocumentEnvironment();

    CarbonImmutable::setTestNow('2025-04-05 11:30:00', 'Asia/Kuala_Lumpur');
    $existing = createStoredDocument($setup, 'Week02 Notes.pdf', 'leafB');
    CarbonImmutable::setTestNow();

    $document = createStoredDocument($setup, 'Week02 Notes.pdf', 'leafA');
    $originalFilename = $document->stored_filename;

    app(DocumentOperationsService::class)->move($document, $setup['leafB']);

    $updated = $document->fresh();
    $updatedPath = documentPath($setup, $updated);

    Storage::disk('local')->assertExists($updatedPath);
    Storage::disk('local')->assertExists($existing->fresh()->path_string);

    expect($updated->stored_filename)->not->toBe($originalFilename);
});

it('replaces a document file and updates metadata', function (): void {
    $setup = setupDocumentEnvironment();

    $document = createStoredDocument($setup, 'Assessment Overview.pdf', 'leafA');
    $previousPath = $document->path_string;
    $originalFilename = $document->stored_filename;

    CarbonImmutable::setTestNow('2025-05-01 14:00:00', 'Asia/Kuala_Lumpur');

    $replacement = UploadedFile::fake()->create('Annotated Overview.pdf', 256, 'application/pdf');
    app(DocumentOperationsService::class)->replace($document, $replacement);

    CarbonImmutable::setTestNow();

    $updated = $document->fresh();
    $updatedPath = documentPath($setup, $updated);

    Storage::disk('local')->assertMissing($previousPath);
    Storage::disk('local')->assertExists($updatedPath);

    expect($updated->stored_filename)->not->toBe($originalFilename);
});

it('deletes a document and removes its stored media', function (): void {
    $setup = setupDocumentEnvironment();

    $document = createStoredDocument($setup, 'Rubric.pdf', 'leafA');
    $path = $document->path_string;

    app(DocumentOperationsService::class)->delete($document);

    Storage::disk('local')->assertMissing($path);

    $deleted = Document::withTrashed()->find($document->id);
    expect($deleted)->not->toBeNull()
        ->and($deleted->trashed())->toBeTrue();
});
