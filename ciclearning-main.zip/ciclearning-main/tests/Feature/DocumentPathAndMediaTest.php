<?php

use App\Enums\Milestone;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\Programme;
use App\Models\User;
use App\Services\DocumentStorageService;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

uses(RefreshDatabase::class);

it('stores documents under enforced path and syncs metadata', function () {
    config(['media-library.disk_name' => 'local']);
    Storage::fake('local');

    $programme = Programme::factory()->create(['code' => 'FOCS']);
    $session = AcademicSession::factory()->create(['code' => '2024S1']);
    $course = Course::factory()->create([
        'course_code' => 'CS101',
        'title' => 'Introduction to Computing',
        'title_slug' => 'introduction-to-computing',
    ]);

    $offering = CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $course->id,
    ]);

    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::FinalExamPackage,
        'label' => 'Final Exam Package',
        'slug' => 'final-exam-package',
    ]);

    $root = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->create(['label' => 'Course Materials']);

    $leaf = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->forParent($root)
        ->create(['label' => 'Week 01']);

    $lecturer = User::factory()->create();
    $service = app(DocumentStorageService::class);

    $fixedNow = CarbonImmutable::parse('2025-01-05 09:00:00', 'Asia/Kuala_Lumpur');
    CarbonImmutable::setTestNow($fixedNow);

    try {
        $file = UploadedFile::fake()->create(
            'Lecture Plan?.pdf',
            256,
            'application/pdf'
        );

        $document = $service->store(
            $offering->fresh(['programme', 'session', 'course']),
            Milestone::FinalExamPackage,
            $leaf->fresh(),
            $file,
            $lecturer
        );
    } finally {
        CarbonImmutable::setTestNow();
    }

    $expectedDirectory = sprintf(
        'FOCS/2024S1/%s/FinalExamPackage/%s/',
        $offering->fresh()->course_identifier,
        $leaf->pathString()
    );

    Storage::disk('local')->assertExists($expectedDirectory.$document->stored_filename);
    $media = $document->getFirstMedia(Document::MEDIA_COLLECTION);
    expect($media)->not->toBeNull();
    expect($media->getPathRelativeToRoot())->toBe($expectedDirectory.$media->file_name);

    expect($document->stored_filename)->toBe($media->file_name);
    expect($document->path_string)->toBe($expectedDirectory.$document->stored_filename);
    expect($document->folder_slug)->toBe($leaf->pathString());
    $expectedOriginal = $media->name;
    $extension = pathinfo($media->file_name, PATHINFO_EXTENSION);
    if ($extension !== '') {
        $expectedOriginal .= '.'.$extension;
    }
    expect($document->original_filename)->toBe($expectedOriginal);
    expect($document->filesize)->toBeGreaterThan(0);
    expect($document->mime)->toBe('application/pdf');
});
