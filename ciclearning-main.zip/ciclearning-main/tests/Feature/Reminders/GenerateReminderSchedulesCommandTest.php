<?php

use App\Models\ReminderSchedule;
use App\Services\SettingsService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Artisan;

uses(RefreshDatabase::class);

beforeEach(function () {
    app(SettingsService::class)->setReminderRecurrence([
        'days' => ['monday'],
        'time' => '09:00',
        'channels' => ['mail', 'database'],
    ]);
});

test('generate reminder schedules creates slots for configured days', function () {
    Carbon::setTestNow(Carbon::parse('2025-01-05 08:00', 'Asia/Kuala_Lumpur'));

    try {
        Artisan::call('reminders:generate-schedules', ['--days' => 2]);
    } finally {
        Carbon::setTestNow();
    }

    $sendAt = Carbon::parse('2025-01-06 09:00', 'Asia/Kuala_Lumpur');

    expect(
        ReminderSchedule::query()
            ->whereBetween('send_at', [$sendAt->copy()->startOfMinute(), $sendAt->copy()->endOfMinute()])
            ->exists()
    )->toBeTrue();
});

test('generate reminder schedules is idempotent', function () {
    Carbon::setTestNow(Carbon::parse('2025-01-05 08:00', 'Asia/Kuala_Lumpur'));

    try {
        Artisan::call('reminders:generate-schedules', ['--days' => 2]);
        Artisan::call('reminders:generate-schedules', ['--days' => 2]);
    } finally {
        Carbon::setTestNow();
    }

    expect(ReminderSchedule::query()->count())->toBe(1);
});
