<?php

use App\Filament\Admin\Pages\Settings as SettingsPage;
use App\Models\Setting;
use App\Services\SettingsService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;

uses(RefreshDatabase::class);

test('reminder settings persist through the settings service', function () {
    $service = app(SettingsService::class);

    $service->setReminderRecurrence([
        'days' => ['monday', 'wednesday'],
        'time' => '10:30',
        'channels' => ['mail', 'database'],
    ]);

    $stored = $service->reminderRecurrence();

    expect($stored['days'])->toMatchArray(['monday', 'wednesday'])
        ->and($stored['time'])->toBe('10:30')
        ->and($stored['channels'])->toMatchArray(['mail', 'database']);

    expect(Setting::where('key', SettingsService::REMINDER_RECURRENCE_KEY)->exists())->toBeTrue();
});

test('reminder settings validation requires days and time', function () {
    $page = app(SettingsPage::class);

    $validateMethod = new ReflectionMethod($page, 'validateReminderSettings');
    $validateMethod->setAccessible(true);

    expect(fn () => $validateMethod->invoke($page, [
        'days' => [],
        'time' => null,
        'channels' => [],
    ]))->toThrow(ValidationException::class);
});
