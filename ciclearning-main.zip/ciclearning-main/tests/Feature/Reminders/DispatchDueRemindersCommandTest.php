<?php

use App\Enums\Milestone;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\Programme;
use App\Models\ReminderSchedule;
use App\Models\User;
use App\Notifications\MissingUploadsReminderNotification;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Notification;

uses(RefreshDatabase::class);

test('dispatch due reminders notifies lecturers with missing uploads', function () {
    Notification::fake();

    Carbon::setTestNow(Carbon::parse('2025-01-06 09:05', 'Asia/Kuala_Lumpur'));

    $programme = Programme::factory()->create(['code' => 'CS']);
    $session = AcademicSession::factory()->create(['code' => '2025']);
    $course = Course::factory()->create(['course_code' => 'CS101', 'title' => 'Intro']);

    $offering = CourseOffering::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'course_id' => $course->id,
    ]);

    $lecturerMissing = User::factory()->create();
    $lecturerComplete = User::factory()->create();

    $offering->lecturers()->sync([$lecturerMissing->id, $lecturerComplete->id]);

    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::BeginningOfSemester,
    ]);

    $node = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->create([
            'slug' => 'LessonPlan',
            'label' => 'Lesson Plan',
        ]);

    Document::factory()->create([
        'offering_id' => $offering->id,
        'milestone' => Milestone::BeginningOfSemester,
        'folder_slug' => $node->path_cache,
        'uploader_id' => $lecturerComplete->id,
    ]);

    $schedule = ReminderSchedule::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'milestone' => Milestone::BeginningOfSemester,
        'send_at' => Carbon::now(),
        'channels' => ['database'],
        'active' => true,
        'sent_at' => null,
    ]);

    Artisan::call('reminders:dispatch-due');

    $schedule->refresh();

    Notification::assertSentTo($lecturerMissing, MissingUploadsReminderNotification::class);
    Notification::assertNotSentTo($lecturerComplete, MissingUploadsReminderNotification::class);

    expect($schedule->sent_at)->not->toBeNull()
        ->and($schedule->active)->toBeFalse();

    Artisan::call('reminders:dispatch-due');

    Notification::assertSentTimes(MissingUploadsReminderNotification::class, 1);

    Carbon::setTestNow();
});
