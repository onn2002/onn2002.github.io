<?php

use App\Models\Document;
use App\Models\User;
use App\Policies\DocumentPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Gate;
use Spatie\Permission\Models\Role;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    Role::findOrCreate('lecturer');
    Role::findOrCreate('admin');
});

it('allows lecturers to manage their own documents', function (): void {
    /** @var User $lecturer */
    $lecturer = User::factory()->create();
    $lecturer->assignRole('lecturer');

    /** @var Document $document */
    $document = Document::factory()
        ->for($lecturer, 'uploader')
        ->create();

    $policy = app(DocumentPolicy::class);

    expect($policy->viewAny($lecturer))->toBeTrue()
        ->and($policy->create($lecturer))->toBeTrue()
        ->and($policy->view($lecturer, $document))->toBeTrue()
        ->and($policy->update($lecturer, $document))->toBeTrue()
        ->and($policy->delete($lecturer, $document))->toBeTrue()
        ->and($policy->restore($lecturer, $document))->toBeTrue()
        ->and($policy->forceDelete($lecturer, $document))->toBeFalse();
});

it('prevents lecturers from managing documents uploaded by others', function (): void {
    /** @var User $owner */
    $owner = User::factory()->create();
    $owner->assignRole('lecturer');

    /** @var Document $document */
    $document = Document::factory()
        ->for($owner, 'uploader')
        ->create();

    /** @var User $otherLecturer */
    $otherLecturer = User::factory()->create();
    $otherLecturer->assignRole('lecturer');

    $policy = app(DocumentPolicy::class);

    expect($policy->viewAny($otherLecturer))->toBeTrue()
        ->and($policy->view($otherLecturer, $document))->toBeFalse()
        ->and($policy->update($otherLecturer, $document))->toBeFalse()
        ->and($policy->delete($otherLecturer, $document))->toBeFalse()
        ->and($policy->restore($otherLecturer, $document))->toBeFalse()
        ->and($policy->forceDelete($otherLecturer, $document))->toBeFalse();
});

it('grants admins full access to any document', function (): void {
    /** @var User $admin */
    $admin = User::factory()->create();
    $admin->assignRole('admin');

    /** @var Document $document */
    $document = Document::factory()->create();

    expect(Gate::forUser($admin)->allows('viewAny', Document::class))->toBeTrue()
        ->and(Gate::forUser($admin)->allows('create', Document::class))->toBeTrue()
        ->and(Gate::forUser($admin)->allows('view', $document))->toBeTrue()
        ->and(Gate::forUser($admin)->allows('update', $document))->toBeTrue()
        ->and(Gate::forUser($admin)->allows('delete', $document))->toBeTrue()
        ->and(Gate::forUser($admin)->allows('restore', $document))->toBeTrue()
        ->and(Gate::forUser($admin)->allows('forceDelete', $document))->toBeTrue();
});
