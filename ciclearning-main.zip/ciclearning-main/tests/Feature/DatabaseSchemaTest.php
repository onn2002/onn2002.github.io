<?php

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Schema;

uses(RefreshDatabase::class);

test('programmes table structure', function () {
    expect(Schema::hasColumns('programmes', [
        'id',
        'code',
        'name',
        'active',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('academic sessions table structure', function () {
    expect(Schema::hasColumns('academic_sessions', [
        'id',
        'code',
        'starts_at',
        'ends_at',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('courses table structure', function () {
    expect(Schema::hasColumns('courses', [
        'id',
        'course_code',
        'title',
        'title_slug',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('course offerings table structure', function () {
    expect(Schema::hasColumns('course_offerings', [
        'id',
        'programme_id',
        'academic_session_id',
        'course_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('course offering user pivot structure', function () {
    expect(Schema::hasColumns('course_offering_user', [
        'course_offering_id',
        'user_id',
        'created_at',
        'updated_at',
    ]))->toBeTrue();
});

test('folder templates table structure', function () {
    expect(Schema::hasColumns('folder_templates', [
        'id',
        'slug',
        'label',
        'milestone',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('folder template nodes table structure', function () {
    expect(Schema::hasColumns('folder_template_nodes', [
        'id',
        'folder_template_id',
        'parent_id',
        'slug',
        'label',
        'depth',
        'position',
        'path_cache',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('documents table structure', function () {
    expect(Schema::hasColumns('documents', [
        'id',
        'offering_id',
        'milestone',
        'folder_slug',
        'uploader_id',
        'stored_filename',
        'original_filename',
        'path_string',
        'filesize',
        'mime',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('reminder schedules table structure', function () {
    expect(Schema::hasColumns('reminder_schedules', [
        'id',
        'programme_id',
        'academic_session_id',
        'milestone',
        'send_at',
        'channels',
        'active',
        'sent_at',
        'created_at',
        'updated_at',
        'deleted_at',
    ]))->toBeTrue();
});

test('settings table structure', function () {
    expect(Schema::hasColumns('settings', [
        'id',
        'key',
        'value',
        'created_at',
        'updated_at',
    ]))->toBeTrue();
});
