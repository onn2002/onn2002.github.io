<?php

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\User;
use App\Services\CompletenessService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;

uses(RefreshDatabase::class);

it('computes lecturer completeness and invalidates cache on changes', function () {
    Cache::flush();

    $milestone = Milestone::FinalExamPackage;

    $offering = CourseOffering::factory()->create();

    $template = FolderTemplate::factory()->create([
        'milestone' => $milestone,
    ]);

    $requiredLeaf = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->create(['label' => 'Required Docs', 'required' => true]);

    $optionalParent = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->create(['label' => 'Optional']);

    $optionalLeaf = FolderTemplateNode::factory()
        ->forTemplate($template)
        ->forParent($optionalParent)
        ->optional()
        ->create(['label' => 'Reference']);

    $lecturerA = User::factory()->create();
    $lecturerB = User::factory()->create();

    $firstDoc = Document::factory()->create([
        'offering_id' => $offering->id,
        'milestone' => $milestone,
        'folder_slug' => $requiredLeaf->pathString(),
        'uploader_id' => $lecturerA->id,
    ]);

    Document::factory()->create([
        'offering_id' => $offering->id,
        'milestone' => $milestone,
        'folder_slug' => $requiredLeaf->pathString(),
        'uploader_id' => $lecturerB->id,
    ]);

    Document::factory()->create([
        'offering_id' => $offering->id,
        'milestone' => $milestone,
        'folder_slug' => $optionalLeaf->pathString(),
        'uploader_id' => $lecturerB->id,
    ]);

    $service = app(CompletenessService::class);

    $status = $service->statusFor($lecturerA, $offering, $milestone);

    expect($status)
        ->toHaveKey($requiredLeaf->pathString())
        ->and($status[$requiredLeaf->pathString()]['you'])->toBe(1)
        ->and($status[$requiredLeaf->pathString()]['total'])->toBe(2)
        ->and($status[$requiredLeaf->pathString()]['done'])->toBeTrue();

    expect($status[$optionalLeaf->pathString()]['you'])->toBe(0);
    expect($status[$optionalLeaf->pathString()]['total'])->toBe(1);
    expect($status[$optionalLeaf->pathString()]['done'])->toBeTrue();

    // Trigger cache invalidation via document creation.
    Document::factory()->create([
        'offering_id' => $offering->id,
        'milestone' => $milestone,
        'folder_slug' => $optionalLeaf->pathString(),
        'uploader_id' => $lecturerA->id,
    ]);

    $updated = $service->statusFor($lecturerA, $offering, $milestone);

    expect($updated[$optionalLeaf->pathString()]['you'])->toBe(1);
    expect($updated[$optionalLeaf->pathString()]['total'])->toBe(2);

    // Trigger invalidation via deletion.
    $firstDoc->delete();

    $afterDelete = $service->statusFor($lecturerA, $offering, $milestone);

    expect($afterDelete[$requiredLeaf->pathString()]['you'])->toBe(0);
    expect($afterDelete[$requiredLeaf->pathString()]['total'])->toBe(1);
    expect($afterDelete[$requiredLeaf->pathString()]['done'])->toBeFalse();
});
