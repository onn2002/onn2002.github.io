<?php

use App\Enums\Milestone;
use App\Models\Document;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

uses(RefreshDatabase::class);

beforeEach(function () {
    Storage::fake(config('media-library.disk_name'));
});

test('document syncs metadata after media upload', function () {
    $document = Document::factory()->create([
        'stored_filename' => null,
        'original_filename' => null,
        'path_string' => null,
        'filesize' => 0,
        'mime' => null,
    ]);

    $file = UploadedFile::fake()->create('syllabus.pdf', 256, 'application/pdf');

    $document
        ->addMedia($file)
        ->toMediaCollection(Document::MEDIA_COLLECTION);

    $document->refreshMediaMetadata();

    $document->refresh();
    $media = $document->getFirstMedia(Document::MEDIA_COLLECTION);

    expect($media)->toBeInstanceOf(Media::class);
    expect($document->milestone)->toBeInstanceOf(Milestone::class);
    expect($document->offering)->not->toBeNull();
    expect($document->uploader)->toBeInstanceOf(User::class);
    expect($document->stored_filename)->toBe($media->file_name);
    expect($document->original_filename)->toBe('syllabus.pdf');
    expect($document->path_string)->toBe($media->getPathRelativeToRoot());
    expect($document->filesize)->toBe($media->size);
    expect($document->mime)->toBe($media->mime_type);
});

test('deleting a document removes its media', function () {
    $document = Document::factory()->create([
        'stored_filename' => null,
        'original_filename' => null,
        'path_string' => null,
        'filesize' => 0,
        'mime' => null,
    ]);

    $file = UploadedFile::fake()->create('rubric.docx', 128, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');

    $document
        ->addMedia($file)
        ->toMediaCollection(Document::MEDIA_COLLECTION);

    $mediaId = $document->getFirstMedia(Document::MEDIA_COLLECTION)?->id;

    $document->forceDelete();

    expect(Media::find($mediaId))->toBeNull();
});
