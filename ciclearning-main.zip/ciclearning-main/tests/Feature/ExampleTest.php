<?php

test('the application redirects guests to the lecturer panel', function () {
    $this->get('/')
        ->assertRedirect('/lecturer');
});
