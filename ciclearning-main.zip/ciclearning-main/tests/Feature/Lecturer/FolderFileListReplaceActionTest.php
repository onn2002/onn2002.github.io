<?php

require_once __DIR__.'/../Support/DocumentTestHelpers.php';

use App\Enums\Milestone;
use App\Livewire\Lecturer\FolderFileList;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Livewire\Livewire;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    config(['media-library.disk_name' => 'local']);
    Storage::fake('local');
});

it('replaces a document and refreshes the table through the replace action', function (): void {
    $setup = setupDocumentEnvironment();
    $document = createStoredDocument($setup, 'Week 01 Outline.pdf', 'leafA');

    $previousPath = $document->path_string;
    $previousFilename = $document->stored_filename;
    $previousOriginal = $document->original_filename;
    $previousSize = $document->filesize;
    $previousMime = $document->mime;

    $user = $setup['user'];
    $slug = $setup['leafA']->pathString();

    $this->actingAs($user);

    $component = Livewire::test(FolderFileList::class, [
        'offeringId' => $setup['offering']->id,
        'milestone' => Milestone::FinalExamPackage->value,
        'userId' => $user->id,
    ])
        ->call('openFolder', $slug)
        ->assertCanSeeTableRecords([$document]);

    $replacement = UploadedFile::fake()->create('Week 01 Outline v2.pdf', 512, 'application/pdf');

    $component
        ->callTableAction('replace', $document, data: ['file' => $replacement])
        ->assertDispatched('documents-updated');

    $updated = $document->fresh();
    $updatedPath = documentPath($setup, $updated);

    $disk = Storage::disk('local');

    $disk->assertMissing($previousPath);
    $disk->assertExists($updatedPath);

    expect($updated->stored_filename)->not->toBe($previousFilename)
        ->and($updated->original_filename)->not->toBe($previousOriginal)
        ->and($updated->path_string)->toBe($updatedPath)
        ->and($updated->filesize)->not->toBe($previousSize)
        ->and($updated->mime)->toBeString()
        ->and($updated->mime)->not->toBe('');

    $component
        ->call('loadTable')
        ->assertSeeText($updated->path_string);
});
