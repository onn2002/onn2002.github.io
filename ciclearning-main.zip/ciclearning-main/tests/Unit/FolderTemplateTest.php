<?php

use App\Enums\Milestone;
use App\Models\FolderTemplate;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(\Tests\TestCase::class, RefreshDatabase::class);

test('folder template slug unique per milestone', function () {
    FolderTemplate::factory()->create([
        'milestone' => Milestone::BeginningOfSemester->value,
        'slug' => 'rubric',
    ]);

    expect(fn () => FolderTemplate::factory()->create([
        'milestone' => Milestone::BeginningOfSemester->value,
        'slug' => 'rubric',
    ]))->toThrow(QueryException::class);
});

test('folder template slug can repeat across milestones', function () {
    expect(fn () => FolderTemplate::factory()->create([
        'milestone' => Milestone::BeginningOfSemester->value,
        'slug' => 'rubric',
    ]))->not->toThrow(QueryException::class);

    expect(fn () => FolderTemplate::factory()->create([
        'milestone' => Milestone::MidTermExamination->value,
        'slug' => 'rubric',
    ]))->not->toThrow(QueryException::class);
});
