<?php

use App\Support\FilenameSanitizer;

it('strips reserved characters and control bytes', function () {
    $sanitizer = new FilenameSanitizer;

    $result = $sanitizer->sanitize("Plan:/\\*\x03?<>|");

    expect($result)->toBe('Plan');
});

it('collapses whitespace and trims ends', function () {
    $sanitizer = new FilenameSanitizer;

    $result = $sanitizer->sanitize("  Semester\t Report \n Draft  ");

    expect($result)->toBe('Semester Report Draft');
});

it('falls back to default when name becomes empty', function () {
    $sanitizer = new FilenameSanitizer;

    expect($sanitizer->sanitize('    '))->toBe('file');
});
