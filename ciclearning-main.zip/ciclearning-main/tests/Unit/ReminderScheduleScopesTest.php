<?php

use App\Enums\Milestone;
use App\Models\AcademicSession;
use App\Models\Programme;
use App\Models\ReminderSchedule;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;

uses(\Tests\TestCase::class, RefreshDatabase::class);

test('active scope filters by active flag', function () {
    ReminderSchedule::factory()->count(2)->create();
    ReminderSchedule::factory()->inactive()->create();

    expect(ReminderSchedule::active()->count())->toBe(2);
});

test('due scope respects timezone and sent flag', function () {
    Carbon::setTestNow(Carbon::parse('2024-01-10 08:00:00', config('app.timezone')));

    $due = ReminderSchedule::factory()->create([
        'send_at' => Carbon::now()->subHour(),
    ]);

    ReminderSchedule::factory()->create([
        'send_at' => Carbon::now()->addHour(),
    ]);

    ReminderSchedule::factory()->sent()->create([
        'send_at' => Carbon::now()->subHours(2),
    ]);

    expect(ReminderSchedule::due()->pluck('id'))->toContain($due->id);
    expect(ReminderSchedule::due()->count())->toBe(1);

    Carbon::setTestNow();
});

test('scopedTo applies programme session and milestone filters', function () {
    $programme = Programme::factory()->create();
    $session = AcademicSession::factory()->create();

    $target = ReminderSchedule::factory()->create([
        'programme_id' => $programme->id,
        'academic_session_id' => $session->id,
        'milestone' => Milestone::BeginningOfSemester->value,
    ]);

    ReminderSchedule::factory()->create([
        'programme_id' => Programme::factory()->create()->id,
        'academic_session_id' => $session->id,
        'milestone' => Milestone::BeginningOfSemester->value,
    ]);

    $result = ReminderSchedule::query()
        ->scopedTo($programme->id, $session->id, Milestone::BeginningOfSemester)
        ->get();

    expect($result)->toHaveCount(1);
    expect($result->first()->id)->toBe($target->id);
});
