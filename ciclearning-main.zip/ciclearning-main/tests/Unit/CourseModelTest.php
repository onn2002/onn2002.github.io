<?php

use App\Models\Course;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(\Tests\TestCase::class, RefreshDatabase::class);

test('course slug generated on create', function () {
    $course = Course::factory()->create([
        'title' => 'Advanced Algorithms',
        'title_slug' => null,
    ]);

    expect($course->title_slug)->toBe('advanced-algorithms');
});

test('course slug refreshes when title changes', function () {
    $course = Course::factory()->create([
        'title' => 'Introduction to Databases',
    ]);

    $course->update(['title' => 'Relational Database Systems']);

    expect($course->fresh()->title_slug)
        ->toBe('relational-database-systems');
});
