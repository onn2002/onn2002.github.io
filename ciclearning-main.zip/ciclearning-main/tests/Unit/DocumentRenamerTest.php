<?php

use App\Services\DocumentRenamer;
use App\Support\FilenameSanitizer;
use Carbon\CarbonImmutable;

beforeEach(function (): void {
    $this->renamer = new DocumentRenamer(new FilenameSanitizer);
    $this->timestamp = CarbonImmutable::parse('2025-03-18 09:15:00', 'Asia/Kuala_Lumpur');
});

it('formats filename with sanitized base, course code, and MYT date', function () {
    $filename = $this->renamer->generate(
        'Course Outline?.PDF',
        'CS101',
        $this->timestamp
    );

    expect($filename)->toBe('Course Outline_CS101_20250318.pdf');
});

it('appends numeric suffix when collisions occur', function () {
    $existing = [
        'file_CS101_20250318.pdf',
        'file_CS101_20250318_2.pdf',
    ];

    $filename = $this->renamer->generate(
        'file.pdf',
        'CS101',
        $this->timestamp,
        fn (string $candidate) => in_array($candidate, $existing, true),
    );

    expect($filename)->toBe('file_CS101_20250318_3.pdf');
});

it('omits extension segment when original name has none', function () {
    $filename = $this->renamer->generate(
        'Checklist',
        'CS101',
        $this->timestamp
    );

    expect($filename)->toBe('Checklist_CS101_20250318');
});
