<?php

use App\Enums\Milestone;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;

uses(Tests\TestCase::class, RefreshDatabase::class);

test('it computes depth and path cache for nested nodes', function (): void {
    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::BeginningOfSemester->value,
    ]);

    $root = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'label' => 'Top Level',
        'slug' => 'top-level',
    ]);

    expect($root->depth)->toBe(1)
        ->and($root->pathString())->toBe('TopLevel');

    $child = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $root->id,
        'label' => 'Requirements',
        'slug' => 'requirements',
    ]);

    expect($child->depth)->toBe(2)
        ->and($child->pathString())->toBe('TopLevel/Requirements');

    $grandchild = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $child->id,
        'label' => 'Draft',
        'slug' => 'draft',
    ]);

    expect($grandchild->depth)->toBe(3)
        ->and($grandchild->pathString())->toBe('TopLevel/Requirements/Draft');
});

test('it prevents creating nodes deeper than three levels', function (): void {
    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::MidTermExamination->value,
    ]);

    $levelOne = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'label' => 'Root',
        'slug' => 'root',
    ]);

    $levelTwo = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $levelOne->id,
        'label' => 'Child',
        'slug' => 'child',
    ]);

    $levelThree = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $levelTwo->id,
        'label' => 'Grandchild',
        'slug' => 'grandchild',
    ]);

    expect(fn () => FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $levelThree->id,
        'label' => 'Too Deep',
        'slug' => 'too-deep',
    ]))->toThrow(ValidationException::class);
});

test('it enforces unique slugs per sibling group', function (): void {
    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::EndOfSemester->value,
    ]);

    $root = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'label' => 'Reports',
        'slug' => 'reports',
    ]);

    expect(fn () => FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $root->id,
        'label' => 'Summary',
        'slug' => 'summary',
    ]))->not->toThrow(QueryException::class);

    expect(fn () => FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $root->id,
        'label' => 'Summary Duplicate',
        'slug' => 'summary',
    ]))->toThrow(QueryException::class);
});

test('reparenting updates descendant depth and paths', function (): void {
    $template = FolderTemplate::factory()->create([
        'milestone' => Milestone::BeginningOfSemester->value,
    ]);

    $rootA = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'label' => 'Root A',
        'slug' => 'root-a',
    ]);

    $rootB = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'label' => 'Root B',
        'slug' => 'root-b',
    ]);

    $child = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $rootA->id,
        'label' => 'Child',
        'slug' => 'child',
    ]);

    $grandchild = FolderTemplateNode::create([
        'folder_template_id' => $template->id,
        'parent_id' => $child->id,
        'label' => 'Leaf',
        'slug' => 'leaf',
    ]);

    $child->parent_id = $rootB->id;
    $child->save();

    $child->refresh();
    $grandchild->refresh();

    expect($child->depth)->toBe(2)
        ->and($child->pathString())->toBe('RootB/Child')
        ->and($grandchild->depth)->toBe(3)
        ->and($grandchild->pathString())->toBe('RootB/Child/Leaf');
});

test('required flag defaults to true and can be toggled', function (): void {
    $node = FolderTemplateNode::factory()->create();

    expect($node->required)->toBeTrue();

    $node->required = false;
    $node->save();

    $node->refresh();

    expect($node->required)->toBeFalse();
});
