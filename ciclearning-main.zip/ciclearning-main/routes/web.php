<?php

use Illuminate\Support\Facades\Route;

Route::redirect('/', 'lecturer');
