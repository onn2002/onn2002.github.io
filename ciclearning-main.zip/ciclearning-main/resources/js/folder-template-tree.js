import Sortable from 'sortablejs';

const TREE_ROOT_SELECTOR = '[data-template-tree]';
const LIST_SELECTOR = '[data-folder-list]';
const ROOT_LIST_SELECTOR = '[data-folder-list-root]';

function focusSelectedNode(id) {
    const root = document.querySelector(TREE_ROOT_SELECTOR);

    if (! root) {
        return;
    }

    if (! id) {
        return;
    }

    const target = root.querySelector(`[data-node-id="${id}"] [role="treeitem"]`);

    if (target) {
        target.focus({ preventScroll: false });
        target.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
    }
}

function serialize(list) {
    if (! list) {
        return [];
    }

    return Array.from(list.children)
        .filter((item) => item.matches('[data-node-id]'))
        .map((item) => ({
            id: Number.parseInt(item.dataset.nodeId, 10),
            children: serialize(item.querySelector(':scope > ' + LIST_SELECTOR)),
        }));
}

function bindSortable(list) {
    if (! list) {
        return;
    }

    if (list._folderTemplateSortable) {
        return;
    }

    list._folderTemplateSortable = new Sortable(list, {
        group: {
            name: 'folder-template-tree',
            pull: true,
            put: true,
        },
        draggable: '[data-node-id]',
        handle: '[data-drag-handle]',
        animation: 160,
        fallbackOnBody: true,
        swapThreshold: 0.65,
        dragClass: 'cursor-grabbing',
        ghostClass: 'opacity-70',
        onEnd: () => {
            const root = document.querySelector(TREE_ROOT_SELECTOR);

            if (! root || ! window.Livewire) {
                return;
            }

            const tree = serialize(root.querySelector(ROOT_LIST_SELECTOR));
            window.Livewire.dispatch('tree-reordered', { tree });
        },
    });
}

function refreshSortables() {
    const root = document.querySelector(TREE_ROOT_SELECTOR);

    if (! root) {
        return;
    }

    root.querySelectorAll(LIST_SELECTOR).forEach((list) => {
        if (list._folderTemplateSortable) {
            list._folderTemplateSortable.destroy();
            delete list._folderTemplateSortable;
        }

        bindSortable(list);
    });
}

function registerHooks() {
    if (! window.Livewire) {
        return;
    }

    if (registerHooks._registered) {
        return;
    }

    registerHooks._registered = true;

    window.Livewire.hook('message.processed', (message, component) => {
        if (component.fingerprint?.name === 'admin.folder-template-tree') {
            refreshSortables();
        }
    });

    window.Livewire.on('tree-updated', () => {
        refreshSortables();
    });

    window.Livewire.on('node-selected', (payload = {}) => {
        focusSelectedNode(payload.id);
    });
}

function boot() {
    if (boot._booted) {
        return;
    }

    if (! window.Livewire) {
        window.setTimeout(boot, 50);
        return;
    }

    boot._booted = true;

    refreshSortables();
    registerHooks();
}

if (typeof window !== 'undefined') {
    if (window.Livewire) {
        if (typeof queueMicrotask === 'function') {
            queueMicrotask(boot);
        } else {
            Promise.resolve().then(boot);
        }
    } else {
        document.addEventListener('livewire:init', boot, { once: true });
        document.addEventListener('livewire:load', boot, { once: true });
    }

    document.addEventListener('livewire:navigated', () => {
        refreshSortables();
    });
}
