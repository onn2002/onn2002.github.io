<x-filament-panels::page>
    <div class="space-y-6">
        <x-filament::section>
            <x-slot name="heading">
                Filters
            </x-slot>

            <x-slot name="description">
                Choose an assigned course offering and milestone to review folder status and manage uploads.
            </x-slot>

            <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">
                        Programme
                        <select
                            wire:model.live="selectedProgrammeId"
                            class="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
                        >
                            <option value="">All programmes</option>
                            @foreach ($programmeOptions as $option)
                                <option value="{{ $option['value'] }}">{{ $option['label'] }}</option>
                            @endforeach
                        </select>
                    </label>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">
                        Academic session
                        <select
                            wire:model.live="selectedSessionId"
                            class="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
                        >
                            <option value="">All sessions</option>
                            @foreach ($sessionOptions as $option)
                                <option value="{{ $option['value'] }}">{{ $option['label'] }}</option>
                            @endforeach
                        </select>
                    </label>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">
                        Course offering
                        <select
                            wire:model.live="selectedOfferingId"
                            class="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
                        >
                            @foreach ($offeringOptions as $option)
                                <option value="{{ $option['value'] }}">{{ $option['label'] }}</option>
                            @endforeach
                        </select>
                    </label>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">
                        Milestone
                        <select
                            wire:model.live="selectedMilestone"
                            class="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
                        >
                            @foreach ($milestoneOptions as $option)
                                <option value="{{ $option['value'] }}">{{ $option['label'] }}</option>
                            @endforeach
                        </select>
                    </label>
                </div>
            </div>
        </x-filament::section>

        @if (! $this->hasOfferings)
            <x-filament::empty-state icon="heroicon-o-queue-list" heading="No assigned offerings">
                <x-slot name="description">
                    You do not have any course offerings assigned yet. Once an offering is assigned, this dashboard will show the required folders and upload status.
                </x-slot>
            </x-filament::empty-state>
        @else
            @if ($this->selectedOffering)
                <x-filament::card>
                    <div class="space-y-1">
                        <h3 class="text-sm font-semibold text-gray-900">
                            {{ $this->selectedOffering->course?->course_code ?? 'Course '.$this->selectedOffering->course_id }}
                        </h3>

                        <p class="text-sm text-gray-600">
                            {{ $this->selectedOffering->course?->title ?? 'Untitled course' }}
                            · Programme {{ $this->selectedOffering->programme?->code ?? $this->selectedOffering->programme_id }}
                            · Session {{ $this->selectedOffering->session?->code ?? $this->selectedOffering->academic_session_id }}
                        </p>

                        @if ($this->selectedMilestoneEnum)
                            <p class="text-sm text-gray-500">
                                Managing milestone: {{ $this->selectedMilestoneEnum->label() }}
                            </p>
                        @endif
                    </div>
                </x-filament::card>
            @endif

            <div class="">
                <livewire:lecturer.folder-tile-grid
                    :offering-id="$this->selectedOfferingId"
                    :milestone="$this->selectedMilestone"
                    :user-id="$this->currentUserId"
                    wire:key="tiles-{{ $this->selectedOfferingId }}-{{ $this->selectedMilestone }}"
                />
            </div>
            <livewire:lecturer.folder-file-list
                :offering-id="$this->selectedOfferingId"
                :milestone="$this->selectedMilestone"
                :user-id="$this->currentUserId"
                wire:key="files-{{ $this->selectedOfferingId }}-{{ $this->selectedMilestone }}"
            />
        @endif

        <livewire:lecturer.upload-modal
            :offering-id="$this->selectedOfferingId"
            :milestone="$this->selectedMilestone"
            :user-id="$this->currentUserId"
            wire:key="upload-modal-{{ $this->selectedOfferingId }}-{{ $this->selectedMilestone }}"
        />
    </div>
</x-filament-panels::page>
@push('scripts')
    @vite('resources/css/app.css')
    @vite('resources/js/app.js')
@endpush
