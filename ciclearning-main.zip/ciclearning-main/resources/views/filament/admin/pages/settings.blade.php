<x-filament-panels::page>
    <form wire:submit.prevent="submit" class="space-y-6">
        {{ $this->form }}

        <div class="flex items-center justify-end">
            <x-filament::button type="submit">
                Save settings
            </x-filament::button>
        </div>
    </form>

    <p class="mt-6 text-sm text-gray-500">
        {{-- TODO: Persist these settings to a dedicated storage layer (database/settings table) for production deployments. --}}
    </p>
</x-filament-panels::page>
