<x-filament-panels::page>
    <livewire:admin.folder-template-tree />
</x-filament-panels::page>

@push('scripts')
    @vite('resources/css/app.css')
    @vite('resources/js/app.js')
@endpush
