<div class="space-y-6" data-template-tree>
    <div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div class="space-y-1">
            <h2 class="text-lg font-semibold text-gray-900">Template management</h2>
            <p class="text-sm text-gray-500">Drag folders to reorder, then save. Select a folder to edit its details.</p>
        </div>

        <div class="w-full sm:w-64">
            <label class="block text-sm font-medium text-gray-700">
                Milestone
                <select
                    wire:model.live="selectedMilestone"
                    class="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
                >
                    @foreach ($milestones as $option)
                        <option value="{{ $option['value'] }}">{{ $option['label'] }}</option>
                    @endforeach
                </select>
            </label>
        </div>
    </div>

    @error('tree')
        <div class="rounded-lg border border-danger-200 bg-danger-50 px-4 py-3 text-sm text-danger-700">
            {{ $message }}
        </div>
    @enderror

    <div class="grid gap-6 lg:grid-cols-6">
        @php /** @var \App\Livewire\Admin\FolderTemplateTree $this */ $viewingAll = $this->viewingAllMilestones; @endphp
        <div class="flex flex-col gap-4 rounded-2xl border border-gray-200 bg-white p-4 shadow-sm sm:p-6 col-span-4">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h3 class="text-base font-semibold text-gray-900">Template Tree</h3>
                    <p class="text-sm text-gray-500 max-w-md">
                        @if ($viewingAll)
                            Viewing every milestone. Select a specific milestone to add or reorder folders.
                        @else
                            Select a node to edit details. Drag to reorder up to three levels.
                        @endif
                    </p>
                </div>

                <div class="flex items-center gap-3">
                    <x-filament::button
                        size="sm"
                        wire:click="addRoot"
                        type="button"
                        wire:loading.attr="disabled"
                        wire:target="addRoot,loadTemplate"
                        :disabled="$viewingAll"
                    >
                        <x-filament::icon icon="heroicon-o-plus" class="h-4 w-4" />
                        Add Root
                    </x-filament::button>

                    <div class="flex items-center gap-3">
                        <x-filament::button
                            size="sm"
                            wire:click="saveReorder"
                            type="button"
                            wire:loading.attr="disabled"
                            wire:target="saveReorder,stageReorder"
                            :disabled="$viewingAll || ! $hasPendingReorder"
                        >
                            @if ($hasPendingReorder)
                                <x-filament::icon icon="heroicon-o-exclamation-triangle" class="h-4 w-4"/>
                            @else
                                <x-filament::icon icon="heroicon-o-check" class="h-4 w-4"/>
                            @endif
                            Save
                        </x-filament::button>
                    </div>
                </div>
            </div>

            <ul
                class="flex-1 space-y-2"
                data-folder-list-root
                data-folder-list
                role="tree"
                aria-label="Folder template tree"
            >
                @if ($viewingAll)
                    @forelse ($tree as $section)
                        <li
                            class="space-y-3 rounded-xl border border-gray-200 bg-gray-50 p-4"
                            data-milestone-section="{{ $section['milestone'] ?? 'unassigned' }}"
                        >
                            <div class="flex items-center justify-between">
                                <span class="text-sm font-semibold text-gray-900">
                                    {{ $section['label'] }}
                                </span>
                                @if (! empty($section['nodes']))
                                    <span class="text-xs text-gray-500">
                                        {{ count($section['nodes']) }} {{ \Illuminate\Support\Str::plural('folder', count($section['nodes'])) }}
                                    </span>
                                @endif
                            </div>

                            @if (! empty($section['nodes']))
                                <ul class="space-y-2" data-folder-list role="group">
                                    @foreach ($section['nodes'] as $node)
                                        @include('livewire.admin.partials.folder-node', ['node' => $node])
                                    @endforeach
                                </ul>
                            @else
                                <div class="rounded-lg border border-dashed border-gray-200 bg-white p-4 text-sm text-gray-500">
                                    No folders yet for this milestone.
                                </div>
                            @endif
                        </li>
                    @empty
                        <li class="rounded-xl border border-dashed border-gray-200 bg-gray-50 p-6 text-center text-sm text-gray-500">
                            No folders yet. Use “Add Root” to create the first folder.
                        </li>
                    @endforelse
                @else
                    @forelse ($tree as $node)
                        @include('livewire.admin.partials.folder-node', ['node' => $node])
                    @empty
                        <li class="rounded-xl border border-dashed border-gray-200 bg-gray-50 p-6 text-center text-sm text-gray-500">
                            No folders yet. Use “Add Root” to create the first folder.
                        </li>
                    @endforelse
                @endif
            </ul>
        </div>

        @include('livewire.admin.partials.node-details')
    </div>
</div>
