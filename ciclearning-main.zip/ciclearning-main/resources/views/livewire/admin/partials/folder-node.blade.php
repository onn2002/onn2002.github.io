@php
    $nodeId = $node['id'];
    $isSelected = $selectedNodeId === $nodeId;
    $viewingAll = $this->viewingAllMilestones ?? false;
    $displayPath = $viewingAll
        ? ($node['display_path'] ?? $node['path'] ?? '')
        : ($node['path'] ?? '');
@endphp

<li
    wire:key="node-{{ $nodeId }}"
    data-node-id="{{ $nodeId }}"
    class="rounded-xl"
>
    <div
        role="treeitem"
        tabindex="0"
        aria-selected="{{ $isSelected ? 'true' : 'false' }}"
        wire:click="selectNode({{ $nodeId }})"
        wire:keydown.enter.prevent="selectNode({{ $nodeId }})"
        wire:keydown.space.prevent="selectNode({{ $nodeId }})"
        @class([
            'group flex cursor-pointer flex-col gap-1 rounded-xl border px-3 py-2 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2',
            'border-primary-200 bg-primary-50 ring-2 ring-primary-200' => $isSelected,
            'border-transparent bg-white hover:border-primary-200 hover:bg-primary-50/40' => ! $isSelected,
        ])
    >
        <div class="flex items-center gap-2">
            <span
                data-drag-handle
                tabindex="-1"
                class="flex h-6 w-6 cursor-grab items-center justify-center rounded-md text-gray-400 transition group-hover:text-primary-500 group-focus-within:text-primary-500"
                title="Drag to reorder"
                aria-hidden="true"
                onmousedown="event.stopPropagation();"
                onclick="event.stopPropagation();"
            >
                <x-filament::icon icon="heroicon-o-bars-3" class="h-4 w-4 cursor-grab" />
            </span>
            <x-filament::icon
                :icon="$node['required'] ? 'heroicon-o-check-circle' : 'heroicon-o-minus-circle'"
                @class([
                    'h-5 w-5 flex-shrink-0',
                    'text-emerald-500' => $node['required'],
                    'text-gray-400' => ! $node['required'],
                ])
            />
            <div class="flex flex-1 items-center gap-2 truncate">
                <span class="truncate text-sm font-medium text-gray-900">{{ $node['label'] }}</span>
            </div>
        </div>
        <div class="truncate text-xs text-gray-500">/{{ $displayPath }}</div>
    </div>

    @if (! empty($node['children']))
        <ul class="ml-3 mt-2 space-y-2 border-l border-gray-200 pl-3" data-folder-list role="group">
            @foreach ($node['children'] as $child)
                @include('livewire.admin.partials.folder-node', ['node' => $child])
            @endforeach
        </ul>
    @else
        <ul class="ml-3 mt-2 space-y-2 border-l border-transparent pl-3" data-folder-list role="group"></ul>
    @endif
</li>
