@php
    use App\Models\FolderTemplateNode;

    $viewingAll = $this->viewingAllMilestones ?? false;
    $selected = $selectedNodeId !== null;
    $depth = $selected ? ($selectedNodeDetails['depth'] ?? 0) : 0;
    $childrenCount = $selected ? ($selectedNodeDetails['children_count'] ?? 0) : 0;
    $canAddChild = $selected && $depth < FolderTemplateNode::MAX_DEPTH;
    $templateLabel = $selected ? ($selectedNodeDetails['template_label'] ?? null) : null;
    $milestoneLabel = $selected ? ($selectedNodeDetails['milestone_label'] ?? null) : null;
@endphp

<div class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm sm:p-6 col-span-2">
    <div class="flex items-start justify-between gap-3">
        <div>
            <h3 class="text-base font-semibold text-gray-900">Node Details</h3>
            <p class="text-sm text-gray-500">
                @if ($selected)
                    Editing
                    @if ($viewingAll && $templateLabel)
                        <span class="font-medium text-gray-900">{{ $templateLabel }}</span>
                        <span class="mx-1 text-gray-400">•</span>
                    @endif
                    <span class="font-medium text-gray-900">{{ $selectedNodeDetails['path'] ?? '' }}</span>
                @else
                    Select a folder from the tree to edit.
                @endif
            </p>
        </div>

        @if ($selected)
            <x-filament::button type="button" color="gray" size="xs" wire:click="deselectNode">
                Clear
            </x-filament::button>
        @endif
    </div>

    @if (! $selected)
        <div class="mt-6 rounded-xl border border-dashed border-gray-200 bg-gray-50 p-6 text-sm text-gray-500">
            Choose a folder in the left pane to manage its label, requirement status, or hierarchy.
        </div>
    @else
        <form class="mt-6 space-y-6" wire:submit.prevent="saveNodeDetails">
            <div class="space-y-2">
                <label for="node-label" class="text-sm font-medium text-gray-700">Label</label>
                <input
                    id="node-label"
                    type="text"
                    wire:model.defer="nodeForm.label"
                    class="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
                    autocomplete="off"
                />
                @error('nodeForm.label')
                    <p class="text-xs text-danger-600">{{ $message }}</p>
                @enderror
            </div>

            <div class="flex flex-col items-start gap-3">
                <label class="inline-flex items-center gap-2 text-sm font-medium text-gray-700">
                    <input
                        type="checkbox"
                        wire:model="nodeForm.required"
                        class="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    Required
                </label>
                <p class="text-xs text-gray-500">
                    Required folders must be completed by lecturers; optional folders are treated as flexible.
                </p>
            </div>

            <div class="space-y-3 rounded-xl border border-gray-100 bg-gray-50 p-4 text-sm">
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-700">Depth</span>
                    <span class="text-gray-600">{{ $depth }}</span>
                </div>
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-700">Children</span>
                    <span class="text-gray-600">{{ $childrenCount }}</span>
                </div>
                @if ($viewingAll && $templateLabel)
                    <div class="flex items-center justify-between">
                        <span class="font-medium text-gray-700">Template</span>
                        <span class="text-gray-600">{{ $templateLabel }}</span>
                    </div>
                @endif
                @if ($viewingAll && $milestoneLabel)
                    <div class="flex items-center justify-between">
                        <span class="font-medium text-gray-700">Milestone</span>
                        <span class="text-gray-600">{{ $milestoneLabel }}</span>
                    </div>
                @endif
            </div>

            @if (! $canAddChild)
                <p class="text-xs text-gray-500">
                    Maximum depth of {{ FolderTemplateNode::MAX_DEPTH }} reached for this branch.
                </p>
            @endif

            @if ($childrenCount > 0)
                <p class="text-xs text-gray-500">
                    Delete child folders before removing this node.
                </p>
            @endif

            <div class="flex flex-col gap-3 border-t border-gray-100 pt-4">
                <div class="flex flex-wrap items-center gap-2">
                    <x-filament::button
                        type="button"
                        size="sm"
                        wire:click="addChild"
                        wire:loading.attr="disabled"
                        wire:target="addChild,loadTemplate"
                        :disabled="$viewingAll || ! $canAddChild"
                    >
                        <x-filament::icon icon="heroicon-o-plus" class="h-4 w-4" />
                        Add Child
                    </x-filament::button>

                    <x-filament::button
                        type="button"
                        size="sm"
                        color="danger"
                        wire:click="deleteSelected"
                        wire:loading.attr="disabled"
                        wire:target="deleteSelected,loadTemplate"
                        :disabled="$viewingAll || $childrenCount > 0"
                    >
                        <x-filament::icon icon="heroicon-o-trash" class="h-4 w-4" />
                        Delete
                    </x-filament::button>
                </div>

                <div>
                    <x-filament::button
                        type="submit"
                        size="sm"
                        wire:loading.attr="disabled"
                        wire:target="saveNodeDetails,loadTemplate"
                    >
                        Save Changes
                    </x-filament::button>
                </div>
            </div>
        </form>
    @endif
</div>
