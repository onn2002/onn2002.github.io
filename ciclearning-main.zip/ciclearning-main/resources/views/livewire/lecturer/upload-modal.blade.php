@php
    $allowedTypes = array_values(array_filter((array) config('admin.mime_whitelist', [])));
    $maxMb = (int) config('admin.max_upload_mb', 25);
@endphp

<div>
    <x-filament::modal
        id="lecturer-upload-modal"
        close-button
        close-by-clicking-away
        width="lg"
    >
        <x-slot name="heading">
            Upload document
        </x-slot>

        <form wire:submit.prevent="submit" class="space-y-5">
        <div class="rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm text-gray-600">
            <div class="font-medium text-gray-900">
                {{ $folderLabel ?? 'Select a folder from the status grid to upload' }}
            </div>

            @if ($pathPreview)
                <p class="mt-1 text-xs text-gray-500 text-wrap max-w-full">
                    {{ $pathPreview }}
                </p>
            @else
                <p class="mt-1 text-xs text-gray-500">
                    Choose a folder tile to see the enforced storage path preview.
                </p>
            @endif
        </div>

        <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">
                Select file
                <input
                    type="file"
                    wire:model="file"
                    @if ($allowedTypes !== [])
                        accept="{{ implode(',', $allowedTypes) }}"
                    @endif
                    class="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
                >
            </label>

            @error('file')
                <p class="text-sm text-danger-600">
                    {{ $message }}
                </p>
            @enderror

            <p class="text-xs text-gray-500">
                Files are server-renamed to follow <code class="font-mono">Name_COURSECODE_YYYYMMDD.ext</code> (MYT). Maximum size: {{ $maxMb }}&nbsp;MB.
                @if ($allowedTypes !== [])
                    Allowed MIME types: {{ implode(', ', $allowedTypes) }}.
                @endif
            </p>
        </div>

        <div class="flex items-center justify-end gap-3">
            <x-filament::button
                type="button"
                color="gray"
                wire:click="close"
            >
                Cancel
            </x-filament::button>

            <x-filament::button
                type="submit"
                wire:loading.attr="disabled"
                wire:target="submit,file"
            >
                Upload
            </x-filament::button>
        </div>
        </form>
    </x-filament::modal>
</div>
