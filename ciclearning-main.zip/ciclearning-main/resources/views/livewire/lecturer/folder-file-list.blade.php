<div>
    <x-filament::section>
        <x-slot name="heading">
            Folder files
        </x-slot>

        <x-slot name="description">
            Manage uploads within the selected folder. Replace or delete files you own (admins can manage any document).
        </x-slot>

        <div class="space-y-4">
            @if ($this->folderLabel)
                <div class="rounded-lg border border-gray-200 bg-gray-50 px-4 py-2 text-sm text-gray-600">
                    Currently viewing: <span class="font-medium text-gray-900">{{ $this->folderLabel }}</span>
                </div>
            @endif

            {{ $this->table }}

            <x-filament-actions::modals />
        </div>
    </x-filament::section>
</div>
