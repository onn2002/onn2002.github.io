<div class="flex flex-col gap-4">
    <div>
        <h2 class="text-base font-semibold text-gray-900">
            Folder status
        </h2>
        <p class="text-sm text-gray-500">
            Review required folders for this milestone. Uploads update immediately after each action.
        </p>
    </div>

    @if ($tiles === [])
        <div class="rounded-xl border border-dashed border-gray-200 bg-white p-6 text-sm text-gray-500">
            No folder templates are defined for this milestone yet. Once templates are published, you'll see status tiles here.
        </div>
    @else
        <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            @foreach ($tiles as $tile)
                @php
                    $isSelected = $selectedFolder === $tile['slug'];
                @endphp

                <div
                    wire:key="tile-{{ $tile['slug'] }}"
                    @class([
                        'flex flex-col gap-4 rounded-xl border bg-white p-4 shadow-sm transition',
                        'border-primary-500 ring-2 ring-primary-200' => $isSelected,
                        'border-gray-200' => ! $isSelected,
                    ])
                >
                    <div class="flex items-start justify-between gap-4">
                        <div class="space-y-1">
                            <h3 class="text-sm font-semibold text-gray-900">
                                {{ $tile['label'] }}
                            </h3>
                            <p class="text-xs text-gray-500">
                                {{ $tile['required'] ? 'Required folder' : 'Optional folder' }}
                            </p>
                        </div>
                        <span class="text-2xl leading-none">
                            {{ $tile['done'] ? '✅' : '❌' }}
                        </span>
                    </div>

                    <div class="rounded-lg border border-gray-100 bg-gray-50 px-3 py-2 text-sm">
                        <div class="flex items-center justify-between text-gray-600">
                            <span>You / Total</span>
                            <span class="font-semibold text-gray-900">
                                {{ $tile['you'] }} / {{ $tile['total'] }}
                            </span>
                        </div>
                    </div>

                    <div class="mt-auto flex flex-wrap gap-2">
                        <x-filament::button
                            type="button"
                            size="xs"
                            color="gray"
                            wire:click="selectFolder('{{ $tile['slug'] }}')"
                        >
                            View files
                        </x-filament::button>

                        <x-filament::button
                            type="button"
                            size="xs"
                            wire:click="openUpload('{{ $tile['slug'] }}')"
                        >
                            Upload
                        </x-filament::button>
                    </div>
                </div>
            @endforeach
        </div>
    @endif
</div>
