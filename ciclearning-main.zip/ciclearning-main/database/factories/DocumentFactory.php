<?php

namespace Database\Factories;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Document>
 */
class DocumentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $storedFilename = Str::uuid().'.pdf';

        $segments = collect(range(1, fake()->numberBetween(1, 3)))
            ->map(fn () => Str::slug(fake()->unique()->words(2, true)));

        return [
            'offering_id' => CourseOffering::factory(),
            'milestone' => fake()->randomElement(Milestone::cases())->value,
            'folder_slug' => $segments->implode('/'),
            'uploader_id' => User::factory(),
            'stored_filename' => $storedFilename,
            'original_filename' => fake()->unique()->words(2, true).'.pdf',
            'path_string' => 'documents/'.$storedFilename,
            'filesize' => fake()->numberBetween(10_000, 1_000_000),
            'mime' => 'application/pdf',
        ];
    }
}
