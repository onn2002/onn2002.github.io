<?php

namespace Database\Factories;

use App\Enums\Milestone;
use App\Models\AcademicSession;
use App\Models\Programme;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\ReminderSchedule>
 */
class ReminderScheduleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'programme_id' => Programme::factory(),
            'academic_session_id' => AcademicSession::factory(),
            'milestone' => fake()->optional()->randomElement(Milestone::cases())?->value,
            'send_at' => Carbon::now(config('app.timezone'))->addDays(fake()->numberBetween(1, 14)),
            'channels' => ['mail'],
            'active' => true,
            'sent_at' => null,
        ];
    }

    public function inactive(): static
    {
        return $this->state(fn () => ['active' => false]);
    }

    public function sent(): static
    {
        return $this->state(fn () => ['sent_at' => Carbon::now(config('app.timezone'))]);
    }
}
