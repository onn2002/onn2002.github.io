<?php

namespace Database\Factories;

use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\FolderTemplateNode>
 */
class FolderTemplateNodeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'folder_template_id' => FolderTemplate::factory(),
            'parent_id' => null,
            'slug' => Str::slug(fake()->unique()->words(2, true)),
            'label' => Str::headline(fake()->words(3, true)),
            'required' => true,
        ];
    }

    public function forTemplate(FolderTemplate $template): static
    {
        return $this->state(fn () => [
            'folder_template_id' => $template->id,
        ]);
    }

    public function forParent(FolderTemplateNode $parent): static
    {
        return $this->state(fn () => [
            'folder_template_id' => $parent->folder_template_id,
            'parent_id' => $parent->id,
        ]);
    }

    public function optional(): static
    {
        return $this->state(fn () => [
            'required' => false,
        ]);
    }
}
