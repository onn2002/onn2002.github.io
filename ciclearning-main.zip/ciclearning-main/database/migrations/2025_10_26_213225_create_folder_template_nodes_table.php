<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('folder_template_nodes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('folder_template_id')
                ->constrained()
                ->cascadeOnDelete();
            $table->foreignId('parent_id')
                ->nullable()
                ->constrained('folder_template_nodes')
                ->cascadeOnDelete();
            $table->string('slug');
            $table->string('label');
            $table->unsignedTinyInteger('depth');
            $table->unsignedInteger('position')->default(0);
            $table->string('path_cache');
            $table->timestamps();
            $table->softDeletes();

            $table->unique(
                ['folder_template_id', 'parent_id', 'slug'],
                'folder_template_nodes_unique_sibling_slug'
            );
            $table->unique(
                ['folder_template_id', 'path_cache'],
                'folder_template_nodes_unique_path'
            );
            $table->index(['folder_template_id', 'depth']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('folder_template_nodes');
    }
};
