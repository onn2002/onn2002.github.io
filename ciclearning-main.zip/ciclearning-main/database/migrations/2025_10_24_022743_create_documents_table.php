<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('offering_id')
                ->constrained('course_offerings')
                ->cascadeOnDelete();
            $table->string('milestone');
            $table->string('folder_slug');
            $table->foreignId('uploader_id')
                ->constrained('users')
                ->restrictOnDelete();
            $table->string('stored_filename')->nullable();
            $table->string('original_filename')->nullable();
            $table->string('path_string')->nullable();
            $table->unsignedBigInteger('filesize')->default(0);
            $table->string('mime', 191)->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['offering_id', 'milestone', 'folder_slug', 'uploader_id'], 'documents_lookup_index');
            $table->index('path_string');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('documents');
    }
};
