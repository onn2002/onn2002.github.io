<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reminder_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('programme_id')
                ->nullable()
                ->constrained()
                ->cascadeOnDelete();
            $table->foreignId('academic_session_id')
                ->nullable()
                ->constrained('academic_sessions')
                ->cascadeOnDelete();
            $table->string('milestone')->nullable();
            $table->timestamp('send_at')->index();
            $table->json('channels');
            $table->boolean('active')->default(true)->index();
            $table->timestamp('sent_at')->nullable()->index();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['programme_id', 'academic_session_id', 'milestone'], 'reminder_scope_index');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reminder_schedules');
    }
};
