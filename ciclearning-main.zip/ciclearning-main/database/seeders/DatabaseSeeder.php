<?php

namespace Database\Seeders;

use App\Enums\Milestone;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\Programme;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call(RolesAndPermissionsSeeder::class);

        $programme = Programme::factory()->create([
            'code' => 'DSC',
            'name' => 'Diploma in Software Computing',
        ]);

        $session = AcademicSession::factory()->create([
            'code' => '202509',
        ]);

        $course = Course::factory()->create([
            'course_code' => 'DCS1103',
            'title' => 'Computer Programming',
            'title_slug' => Str::of('Computer Programming')->title()->replaceMatches('/[^A-Za-z0-9]/', '')->toString(),
        ]);

        $offering = CourseOffering::factory()->create([
            'programme_id' => $programme->id,
            'academic_session_id' => $session->id,
            'course_id' => $course->id,
        ]);

        $admin = User::factory()->create([
            'name' => 'System Administrator',
            'email' => 'admin@admin.com',
            'email_verified_at' => now(),
        ]);
        $admin->assignRole('admin');

        $lecturers = User::factory()
            ->count(2)
            ->sequence(
                ['name' => 'Lecturer One', 'email' => 'lecturer1@lecturer.com'],
                ['name' => 'Lecturer Two', 'email' => 'lecturer2@lecturer.com'],
            )
            ->create()
            ->each(function (User $user): void {
                $user->forceFill(['email_verified_at' => now()])->save();
                $user->assignRole('lecturer');
            });

        $offering->lecturers()->sync($lecturers->modelKeys());

        $tree = [
            [
                'milestone' => 'beginning_of_semester',
                'children' => [
                    ['label' => 'Lesson Plan'],
                ],
            ],
            [
                'milestone' => 'mid_term_examination',
                'children' => [
                    ['label' => 'Mid Term Exam Paper'],
                    ['label' => 'Mid Term Exam Marking Scheme'],
                ],
            ],
            [
                'milestone' => 'final_exam_package',
                'children' => [
                    ['label' => 'Final Exam Paper'],
                    ['label' => 'Final Exam Marking Scheme'],
                    ['label' => 'Exam Requirement Form'],
                    ['label' => 'Moderator Form'],
                    ['label' => 'Exam Question Review Form'],
                    ['label' => 'Student Attainment Tools'],
                ],
            ],
            [
                'milestone' => 'end_of_semester',
                'children' => [
                    ['label' => 'Attendance'],
                    ['label' => 'Teaching Materials'],
                    [
                        'label' => 'Tutorial',
                        'children' => [
                            ['label' => 'Questions'],
                            ['label' => 'Solutions'],
                            ['label' => 'Samples'],
                        ],
                    ],
                    [
                        'label' => 'Practical',
                        'children' => [
                            ['label' => 'Questions'],
                            ['label' => 'Solutions'],
                            ['label' => 'Samples'],
                        ],
                    ],
                    [
                        'label' => 'Quizzes',
                        'children' => [
                            ['label' => 'Questions'],
                            ['label' => 'Marking Scheme'],
                            ['label' => 'Samples'],
                        ],
                    ],
                    [
                        'label' => 'Assignment',
                        'children' => [
                            ['label' => 'Questions'],
                            ['label' => 'Marking Scheme'],
                            ['label' => 'Samples'],
                        ],
                    ],
                    [
                        'label' => 'Group Assignment',
                        'children' => [
                            ['label' => 'Log'],
                            ['label' => 'Mark Detail'],
                        ],
                    ],
                    [
                        'label' => 'Project',
                        'children' => [
                            ['label' => 'Questions'],
                            ['label' => 'Marking Scheme'],
                            ['label' => 'Samples'],
                        ],
                    ],
                    [
                        'label' => 'Group Project',
                        'children' => [
                            ['label' => 'Log'],
                            ['label' => 'Mark Detail'],
                        ],
                    ],
                    ['label' => 'SAT (Filled)'],
                    ['label' => 'Final Exam Samples'],
                ],
            ],
        ];

        collect(Milestone::cases())->each(function (Milestone $milestone) use ($tree): void {
            $template = FolderTemplate::firstOrCreate(
                ['milestone' => $milestone->value],
                [
                    'slug' => Str::of($milestone->label())->title()->replaceMatches('/[^A-Za-z0-9]/', '')->toString(),
                    'label' => $milestone->label(),
                ],
            );

            if ($template->nodes()->exists()) {
                return;
            }

            // search milestone from tree
            $tree = collect($tree)->firstWhere('milestone', $milestone->value)['children'] ?? [];

            $this->seedFolderTree($template, $tree);
        });
    }

    private function seedFolderTree(FolderTemplate $template, array $nodes, ?FolderTemplateNode $parent = null): void
    {
        foreach ($nodes as $index => $definition) {
            $slug = Str::of($definition['label'])->title()->replaceMatches('/[^A-Za-z0-9]/', '')->toString();
            $node = FolderTemplateNode::create([
                'folder_template_id' => $template->id,
                'parent_id' => $parent?->id,
                'label' => $definition['label'],
                'depth' => $parent ? $parent->depth + 1 : 0,
                'path_cache' => $parent ? ($parent->path_cache.'/'.$slug) : $slug,
                'slug' => $slug,
                'position' => $index,
            ]);

            if (! empty($definition['children'])) {
                $this->seedFolderTree($template, $definition['children'], $node);
            }
        }
    }
}
