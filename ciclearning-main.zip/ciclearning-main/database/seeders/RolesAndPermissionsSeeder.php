<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class RolesAndPermissionsSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        app(PermissionRegistrar::class)->forgetCachedPermissions();

        $permissions = collect([
            'programme.view',
            'programme.manage',
            'academic-session.view',
            'academic-session.manage',
            'course.view',
            'course.manage',
            'course-offering.view',
            'course-offering.manage',
            'course-offering.assign-lecturer',
            'folder-template.view',
            'folder-template.manage',
            'user.view',
            'user.manage',
            'role.view',
            'role.manage',
            'permission.view',
            'activity-log.view',
            'settings.manage',
            'document.view',
            'document.upload',
            'document.manage',
            'reminder.manage',
        ])->map(fn (string $name) => Permission::firstOrCreate([
            'name' => $name,
            'guard_name' => 'web',
        ]));

        $adminRole = Role::firstOrCreate([
            'name' => 'admin',
            'guard_name' => 'web',
        ]);

        $adminRole->syncPermissions($permissions);

        $lecturerRole = Role::firstOrCreate([
            'name' => 'lecturer',
            'guard_name' => 'web',
        ]);

        $lecturerRole->syncPermissions($permissions->whereIn('name', [
            'course-offering.view',
            'document.view',
            'document.upload',
        ]));
    }
}
