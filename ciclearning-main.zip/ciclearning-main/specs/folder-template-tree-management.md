# Feature: FolderTemplate Tree Management Page (Admin-only, Drag & Drop, Max 3 Levels)

## Feature Description
A redesigned FolderTemplate implementation that lets Admins define and maintain hierarchical folder structures (up to 3 levels deep) per milestone (no programme/course scoping). The new custom Filament page replaces the current FolderTemplateResource CRUD and provides an intuitive tree view with drag-and-drop reordering and nesting, plus quick add/edit/remove actions. Lecturers will upload files to the leaf folders defined by these templates; completeness tracking uses the leaf nodes.

Value:
- Admins can model real-world folder hierarchies instead of a flat list, improving clarity and governance.
- Lecturers see exactly which folders are required (leaves) and where to upload, reducing ambiguity.
- Enforces consistency across offerings by using a single template per milestone.

## User Story
As an Admin
I want to design and manage milestone-specific folder structures with drag-and-drop
So that lecturers can upload to a clear, enforced directory hierarchy and we can track completeness reliably

## Problem Statement
The current FolderTemplate CRUD is flat and not suitable for representing hierarchical structures. It lacks a tree UI and bulk organize capabilities, making it hard for admins to model complex but standardized folder hierarchies. Lecturers need clear leaf-level targets to upload into; without a structured template, completeness tracking and UX suffer. We also need to ensure Admin-only management.

## Solution Statement
- Keep the existing FolderTemplate model as a per-milestone template owner (no programme/course scoping).
- Introduce FolderTemplateNode to store a 3-level hierarchical folder tree per milestone template.
- Replace the Filament FolderTemplateResource with a custom Admin-only Filament Page that:
  - Shows the tree view of folders.
  - Supports drag-and-drop to reorder and nest within max depth 3.
  - Supports add, rename, and delete nodes with confirmations and validation.
- Treat leaf nodes as “required upload slots” for lecturers and completeness.
- Update the upload path generation to include nested folders: {programme}/{session}/{course_identifier}/{milestone}/{folder_path}/
- Gate access strictly to Admins via permissions and panel access rules. Log all changes via activitylog.

## Relevant Files
Use these files to implement the feature:

- app/Models/FolderTemplate.php
  - Per-milestone template owner model (remove programme/course usage). Extend with relationship to nodes.
- app/Policies/FolderTemplatePolicy.php
  - Enforce Admin-only manage permission; add policy for node operations if a separate policy is created.
- app/Models/Document.php
  - Uses milestone and folder_slug; adjust semantics to store a leaf node path (multi-segment) and update related helpers.
- app/Enums/Milestone.php
  - Used for milestone validation and UI options.
- app/Providers/Filament/AdminPanelProvider.php
  - Discover new custom page; remove old resource from navigation (by deleting it).
- app/Filament/Admin/Resources/FolderTemplates/**
  - Remove this resource entirely; replace with the custom page.
- config/activitylog.php
  - Add morph map for FolderTemplateNode; ensure FolderTemplate changes are logged.
- database/migrations/2025_10_24_022741_create_folder_templates_table.php
  - Historical migration; a follow-up migration will drop `programme_id` and `course_id` and adjust unique indexes to `(milestone, slug)`.
- database/seeders/DatabaseSeeder.php
  - Seed a single FolderTemplate per milestone (no programme/course). Optionally seed example trees under each milestone using the provided structure.
- tests/**
  - Update and add tests for nodes, access control, page actions, and path enforcement.
- composer.json, package.json
  - Register any new PHP or JS dependencies used for the tree UI (e.g., SortableJS or a Filament tree plugin).
- resources/views/**
  - Blade views for the custom page and Livewire component rendering the tree/list.

### New Files
- app/Models/FolderTemplateNode.php
  - Eloquent model for template nodes with relationships and helpers (path building, depth validation, sibling uniqueness).
- database/migrations/XXXX_XX_XX_XXXXXX_create_folder_template_nodes_table.php
  - Nodes table for hierarchical folders.
- app/Filament/Admin/Pages/ManageFolderTemplates.php
  - Custom Filament page (Admin-only) providing the tree UI and actions.
- app/Livewire/Admin/FolderTemplateTree.php
  - Livewire component backing the tree with drag-and-drop, add/rename/delete, and persistence.
- resources/views/livewire/admin/folder-template-tree.blade.php
  - Tree UI markup using nested lists and drag-and-drop.
 - app/Services/FolderPathService.php
  - Generates enforced upload paths using offering + milestone + node path; resolves leaf nodes by id or path safely.
- tests/Unit/FolderTemplateNodeTest.php
  - Unit tests for path, depth enforcement, uniqueness, and reorder helpers.
- tests/Feature/Filament/Admin/ManageFolderTemplatesPageTest.php
  - Feature tests for access control, rendering, CRUD actions on nodes, and drag-and-drop persistence.
- tests/Feature/Uploads/FolderEnforcementTest.php
  - Verifies uploads validate against leaf nodes and paths are generated as expected.
 - database/migrations/XXXX_XX_XX_XXXXXX_drop_scope_columns_from_folder_templates_table.php
  - Drops `programme_id` and `course_id` columns from `folder_templates` and replaces unique index with `(milestone, slug)`.

## Implementation Plan
### Phase 1: Foundation
- Data model for hierarchical nodes (adjacency list): add FolderTemplateNode with columns and constraints; relationships; activity logging.
- Services: FolderPathService to compute and validate nested folder paths; update Document semantics to accept multi-segment folder paths.
- Authorization: ensure only Admins can manage templates and nodes; update policies.
 - Database change: Drop `programme_id` and `course_id` from `folder_templates`; update unique/index constraints to `(milestone, slug)`; update factories/seeders/tests accordingly.

### Phase 2: Core Implementation
- Custom Filament Page with a Livewire-powered tree UI.
- Drag-and-drop using SortableJS (or a Filament tree plugin), with server-side validation for max depth 3 and sibling uniqueness.
- Node CRUD (add sibling/child, rename, delete with cascade or safety checks) and ordering persistence.

### Phase 3: Integration
- Remove FolderTemplateResource; register the new ManageFolderTemplates page in Admin navigation under Catalog.
- Lecturer-facing completeness and upload flows read leaf nodes and enforce nested folder paths.
- Seed example structure for demo; update tests and activity logging.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1) Create nodes table and model
- Add migration `create_folder_template_nodes_table` with columns:
  - `id`, `folder_template_id` (FK), `parent_id` (nullable FK self-ref), `slug` (ASCII), `label`, `depth` (1..3), `position` (int), timestamps, soft deletes.
  - Unique constraints: (`folder_template_id`, `parent_id`, `slug`, `deleted_at` NULL) to prevent duplicate sibling slugs.
  - Index: (`folder_template_id`, `depth`, `position`).
- Create `FolderTemplateNode` model:
  - Relationships: `template()`, `parent()`, `children()`.
  - Accessors/helpers: `isLeaf()`, `pathSegments()`, `pathString()` (join by `/`).
  - Mutators/guards: enforce `depth <= 3`; validate slug ASCII; maintain `position` on reorder.
  - Activity logging via spatie/activitylog.

### 2) Wire relationships on FolderTemplate
- Add `nodes()` and `rootNodes()` relationships on `FolderTemplate`.
- Convenience method to fetch leaf nodes in display order.

### 3) Add Activitylog morph map
- Update `config/activitylog.php` to include `'folder_template_node' => App\\Models\\FolderTemplateNode::class`.
- Ensure logging options on both models include fillable, label, and path changes.

### 4) Path service
- Create `FolderPathService` with methods:
  - `buildPath(CourseOffering $offering, Milestone $milestone, FolderTemplateNode $leaf): string` → `{programme}/{session}/{course_identifier}/{milestone}/{leaf.pathString()}/`.
  - `validateLeafForMilestone(CourseOffering $offering, Milestone $milestone, string $leafPath): FolderTemplateNode` → resolves and validates existence against the global per-milestone template.
- Update any upload logic (or placeholder service) to consume `FolderPathService` and store `Document::folder_slug` as the full node path (multi-segment).

### 5) Policies & permissions
- Keep `folder-template.view` for viewing; require `folder-template.manage` for all node CRUD.
- Create `FolderTemplateNodePolicy` if needed, or gate actions via the page with checks against the template policy.
- Ensure only Admins have `folder-template.manage` (already true via seeder).

### 6) Build custom Filament page skeleton
- Create `app/Filament/Admin/Pages/ManageFolderTemplates.php` with:
  - Navigation: group “Catalog”, icon Folder, sort similar to current resource.
  - Selector for `Milestone` to resolve or create the per-milestone FolderTemplate record (no programme/course selectors).
  - Mounting logic: loads nodes with eager-loaded children; guards for Admin-only.
  - Register assets (JS/CSS) if using SortableJS.

### 7) Implement Livewire tree component
- Create `FolderTemplateTree` component and Blade view:
  - Render nested `<ul><li>` tree with up to 3 levels; show label and slug; mark leaves.
  - Add controls: add sibling, add child (disabled at depth 3), rename, delete (confirm when children exist), and drag handles.
  - Integrate SortableJS (nested) to support drag-and-drop reordering and reparenting; block moves that exceed depth 3.
  - Persist operations via actions: create, update, delete, reorder (update `position` and `parent_id` where needed).
  - Show inline validation errors and success notifications.

### 8) Enforce depth and uniqueness server-side
- Validate max depth on create/move; prevent siblings with duplicate slugs.
- Normalize slugs on edit; auto-generate from label by default; keep `label` user-editable.

### 9) Replace FolderTemplateResource with custom page
- Delete `app/Filament/Admin/Resources/FolderTemplates/**`.
- Confirm Admin navigation shows “Folder Templates” pointing to the new page.
- Verify policies still protect all actions.

### 10) Lecturer integration (read-only)
- Expose read API/service to list leaf nodes for a given (offering, milestone) in display order.
- Ensure completeness calculations use leaf nodes and `Document::folder_slug` as the node path string.

### 11) Seed example tree
- In `DatabaseSeeder`, ensure exactly one FolderTemplate per milestone, then seed nodes using the provided example structure under each milestone, honoring max 3 levels.

### 12) Tests
- Unit: `FolderTemplateNodeTest` for path building, depth enforcement, uniqueness, reorder.
- Feature: `ManageFolderTemplatesPageTest` for Admin-only access, CRUD, drag-and-drop reorder persistence, and validations.
- Feature: `FolderEnforcementTest` verifying `FolderPathService` builds expected paths and rejects invalid leaf paths.
- Update existing authorization tests if references to the removed Resource need adjustments (page route checks).

### 13) Docs and cleanup
- Update README (Filament Panels section) to reflect the new Folder Templates page.
- Remove any stale references to the old resource in docs.

### 14) Validation and QA
- Run the validation commands below and manually verify:
  - Admin can manage trees; Lecturer cannot access the page.
  - Drag-and-drop prevents exceeding depth 3.
  - Upload flow (if present) validates against leaf paths and shows correct computed storage path.

## Testing Strategy
### Unit Tests
- FolderTemplateNode
  - Creates root, child, and grandchild nodes; asserts `depth`, `position`, `pathString()` correctness.
  - Prevents creation/move beyond depth 3; throws validation exception.
  - Prevents duplicate sibling slugs under the same parent.
  - Reorder updates `position` consistently among siblings.
- FolderPathService
  - Builds exact path strings according to offering + milestone + node path.
  - Resolves leaf path to a node for the given milestone.

### Integration Tests
- ManageFolderTemplates page
  - Admin access allowed; Lecturer denied.
  - Create, rename, delete, and drag-and-drop reorder actions persist to DB and reflect in the UI.
  - Attempting to drop a node to an invalid depth is rejected with a clear message.
- Upload enforcement (if upload UI exists)
  - Selecting a leaf path succeeds; invalid/missing leaf path fails validation.

### Edge Cases
- Moving a whole branch where any child would exceed depth 3 → reject and restore original position.
- Deleting a node with children → block with message or cascade delete after confirmation (choose behavior and test it).
- Same leaf slugs may exist across different milestones; within a single milestone tree, sibling slugs must be unique.
- Concurrent edits: stale reorder payloads should fail gracefully (re-emit fresh state to client).

## Acceptance Criteria
- A custom Admin-only “Folder Templates” page exists in the Admin panel navigation under Catalog.
- The page shows a tree view with add/rename/delete and drag-and-drop reordering/nesting up to 3 levels.
- Server-side validations enforce ASCII slugs, unique sibling slugs, and max depth = 3.
- All create/update/delete/reorder actions are logged in activity log with actor and diffs.
- FolderPathService generates nested paths and validates leaf paths against the active milestone template.
- Lecturer completeness logic reads leaf nodes and works with multi-segment folder paths.
- The old FolderTemplateResource and its routes are removed; no dead links in navigation.
- All tests pass; no regressions in existing schema tests; new tests cover nodes and page behavior.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `php artisan migrate` — Apply new nodes table and any related changes
- `php artisan config:clear` — Ensure updated config (activitylog morph map) is loaded
- `php artisan test` — Run tests to validate the feature works with zero regressions
- `composer lint` — Code style checks (Pint in test mode)
- `composer stan` — Static analysis (PHPStan) to catch type and API issues
- `npm install` — Ensure JS dependencies are installed (SortableJS if added)
- `npm run build` — Build assets (Vite) for Filament and Livewire page assets
- `php artisan serve` — Manual QA: visit `/admin` → “Folder Templates” page and exercise the tree UI

## Notes
- Drag-and-drop UI:
  - Preferred: SortableJS for nested lists with Livewire events; alternative is a Filament tree plugin (e.g., awcodes/filament-tree). If a plugin is used, add via `composer require` and register assets accordingly.
- Data model choice:
  - Adjacency list is sufficient for a max depth of 3 and straightforward to manage with drag-and-drop and constraints.
- Backward compatibility:
  - Keep existing `folder_templates` table as the per-milestone template owner; attach nodes under each milestone.
  - Store `Document::folder_slug` as the full leaf path string (multi-segment); no column rename needed.
- Seeding:
  - Optionally seed the provided example hierarchy for quick demos under each milestone-specific template.
- Security:
  - Strictly Admin-only for management; lecturers access read-only leaf lists for uploads; all changes audited.
- Future:
  - Add “required” toggle per leaf; add copy/duplicate template across milestones; export/import JSON for bulk edits.
