# Plan: Lecturer Documents Management Resource

## Task Description
Implement a new Filament resource under the Lecturer panel that mirrors the existing Admin Documents resource (`app/Filament/Admin/Resources/Documents`) but scopes visibility and actions so that lecturers can only see and manage documents they uploaded. The lecturer portal will gain a “documents management” list view with the same columns, filters, and record actions (replace, delete) as the Admin Documents table, but filtered to the current user while still leveraging the shared `Document`, `DocumentPolicy`, and `DocumentOperationsService` logic.

Task type: `feature`  
Complexity: `medium`

## Objective
Provide lecturers with a single list view in the Lecturer Filament panel that:
- Lists all `Document` records uploaded by the current lecturer across all offerings and milestones.
- Mirrors the Admin Documents table’s columns, filters, and record actions for consistency.
- Enforces that lecturers can only see and act on their own documents, using both query scoping and existing policies.
- Integrates cleanly into the existing Lecturer panel navigation without duplicating core document logic.

## Problem Statement
Currently, lecturers have the `UploadsDashboard` page that lets them manage documents within the context of a single course offering and milestone via folder tiles and per-folder lists. However, they lack a consolidated “all my documents” view. The Admin panel’s Documents resource provides such a list with powerful filters and actions, but it is Admin-focused (global visibility) and not exposed in the Lecturer panel. Lecturers need:
- A centralized, searchable table listing all documents they have uploaded, regardless of course offering or milestone.
- The same filters (programme, session, course, offering, milestone, folders, date range, MIME) to quickly locate specific uploads.
- The same record actions (replace file, delete/archive) but restricted to their own documents.

Without this, lecturers have to drill into offerings one-by-one via the Uploads Dashboard or rely on admins to manage documents, which is inefficient and error-prone.

## Solution Approach
Introduce a Lecturer-specific Filament resource that reuses the existing Admin Documents table configuration but scopes the underlying Eloquent query to the authenticated user’s `uploader_id`. The approach:

- Create a new resource `App\Filament\Lecturer\Resources\Documents\DocumentResource` that:
  - Uses `App\Models\Document` as its model.
  - Uses the same navigation icon and labels adjusted for a Lecturer context.
  - Registers a single List page (`ListDocuments`) and no create/edit pages (uploads continue to flow through `UploadsDashboard` and Livewire upload modal).
- In the Lecturer `DocumentResource::table()` method:
  - Call the existing `App\Filament\Admin\Resources\Documents\Tables\DocumentsTable::configure($table)` to reuse columns, filters, and record actions.
  - Chain an additional `->modifyQueryUsing()` scope that constrains the query to `uploader_id = auth()->id()`, ensuring lecturers only see their own documents.
- Leverage the existing `DocumentPolicy` for authorization:
  - `viewAny` and `create` already allow lecturers.
  - `view`, `update`, `delete`, and `restore` are restricted to documents where `uploader_id` matches the user.
  - Admins retain global privileges via the policy’s `before()` method and can continue using the Admin Documents resource for global management.
- Rely on the Lecturer panel’s existing `LecturerPanelProvider` discovery configuration so the new resource is automatically picked up and added to navigation when `shouldRegisterNavigation()` returns true.
- Add focused feature tests to confirm:
  - Lecturers can access the Lecturer Documents index page.
  - The table only lists documents belonging to the current lecturer.
  - Documents owned by other lecturers are neither visible nor actionable.
  - Replace and delete actions succeed for own documents and are disallowed at the policy level for others.

This approach avoids duplicating table configuration, keeps Admin and Lecturer document management behavior aligned, and centralizes the “my documents” view in the Lecturer panel.

## Relevant Files
Use these files to complete the task:

- `app/Filament/Admin/Resources/Documents/DocumentResource.php`
  - Existing Admin Documents resource; provides the pattern to mirror into the Lecturer panel (single List page, empty form, uses `DocumentsTable::configure`).
- `app/Filament/Admin/Resources/Documents/Tables/DocumentsTable.php`
  - Defines the Admin Documents table: query modification (`with` relationships + `latest('created_at')`), columns, filters, record actions (replace, delete), and helper methods for allowed MIME types and options.
  - This will be reused in the Lecturer resource (via `configure()` plus an extra query scope).
- `app/Filament/Admin/Resources/Documents/Pages/ListDocuments.php`
  - Admin List page implementation; provides a baseline for the Lecturer `ListDocuments` page (heading, subheading, header actions).
- `app/Filament/Lecturer/Pages/UploadsDashboard.php`
  - Current Lecturer documents UI (dashboard + folder grid + per-folder file list). Important for understanding existing lecturer workflows and ensuring the new list view complements rather than replaces it.
- `app/Models/Document.php`
  - Eloquent model backing documents; includes relationships (`offering`, `uploader`), media syncing, completeness cache invalidation, and SoftDeletes.
  - The `uploader_id` column is the key field for scoping lecturer visibility.
- `app/Policies/DocumentPolicy.php`
  - Governs authorization: lecturers can view/manage their own documents; admins have full access via `before()`.
  - Ensures that even if query scoping fails, lecturers cannot act on documents they do not own.
- `app/Providers/Filament/LecturerPanelProvider.php`
  - Configures the Lecturer Filament panel and discovers resources in `app/Filament/Lecturer/Resources`.
  - No code changes required for discovery, but useful for understanding panel id, path, and navigation behavior.
- `app/Providers/AuthServiceProvider.php`
  - Registers `DocumentPolicy` against `Document::class`; ensures Filament uses the correct policy for the new Lecturer resource.
- `tests/Feature/Filament/PanelAccessTest.php`
  - Verifies basic access rules for the Admin and Lecturer panels; provides patterns for setting up seeded roles and permissions in feature tests.
- `tests/Feature/Policies/DocumentPolicyTest.php`
  - Validates `DocumentPolicy` behavior; informs expectations around per-user access and reinforces that policy protections already exist.

### New Files
- `app/Filament/Lecturer/Resources/Documents/DocumentResource.php`
  - New Filament resource for the Lecturer panel; mirrors Admin `DocumentResource` but:
    - Uses Lecturer namespace and discovery path.
    - Scopes table queries to the authenticated lecturer via `modifyQueryUsing`.
    - Adjusts navigation label/group for a Lecturer context (e.g., “Documents” under a suitable group).
- `app/Filament/Lecturer/Resources/Documents/Pages/ListDocuments.php`
  - Lecturer List page for `DocumentResource`; similar to Admin `ListDocuments` but with headings/subheading tailored to “your documents” and no header actions.
- `tests/Feature/Filament/Lecturer/DocumentsResourceTest.php`
  - New feature test file verifying access to the Lecturer Documents resource and scoping behavior (only own documents visible and manageable).

## Implementation Phases

### Phase 1: Foundation
Establish the Lecturer Documents resource structure and determine how to safely reuse the Admin table configuration without duplicating logic.

- Confirm Filament’s `Table::modifyQueryUsing()` supports multiple scopes (already true via `HasQuery` trait), so we can safely call it both in `DocumentsTable::configure()` and in the new Lecturer resource.
- Decide on naming and navigation metadata for the new Lecturer resource (e.g., label “Documents”, navigation group “Documents”, icon `Heroicon::OutlinedDocumentText`, sort order near `UploadsDashboard`).
- Ensure `DocumentPolicy` registration in `AuthServiceProvider` is correct and continues to apply for the new resource.

### Phase 2: Core Implementation
Create the Lecturer resource and page, then wire up table scoping to the current lecturer.

- Add `app/Filament/Lecturer/Resources/Documents/DocumentResource.php`:
  - Define namespace `App\Filament\Lecturer\Resources\Documents`.
  - Set `$model = Document::class` and appropriate static navigation properties.
  - Implement `shouldRegisterNavigation()` similar to Admin resources:
    - Return `auth()->check() && static::canViewAny()`, so navigation respects `DocumentPolicy`.
  - Implement `form(Schema $schema): Schema` to return an empty schema (no create/edit forms required).
  - Implement `table(Table $table): Table` to:
    - Import and delegate to `App\Filament\Admin\Resources\Documents\Tables\DocumentsTable::configure($table)`.
    - Chain a `->modifyQueryUsing()` closure that:
      - Accepts `Builder $query`.
      - Reads `$userId = auth()->id();`.
      - If `$userId` is null, returns a query that yields no records (defensive, though navigation should already gate this).
      - Otherwise, adds `where('uploader_id', $userId)` and returns the query.
  - Implement `getRelations()` returning an empty array.
  - Implement `getPages()` to map `'index'` to the new Lecturer `ListDocuments` page.
- Add `app/Filament/Lecturer/Resources/Documents/Pages/ListDocuments.php`:
  - Namespace `App\Filament\Lecturer\Resources\Documents\Pages`.
  - Extend `Filament\Resources\Pages\ListRecords`.
  - Set `protected static string $resource = DocumentResource::class;`.
  - Override `getHeaderActions()` to return an empty array (no “Create” button).
  - Override `getHeading()` and `getSubheading()` to present a Lecturer-focused description (e.g., “My Documents” and “Search and manage documents you’ve uploaded across all offerings.”).
- Verify that `LecturerPanelProvider` does not need changes:
  - It already calls `->discoverResources(in: app_path('Filament/Lecturer/Resources'), for: 'App\Filament\Lecturer\Resources')`.
  - Once the new resource exists, Filament will register routes under the Lecturer panel and include the navigation item.

### Phase 3: Integration & Polish
Integrate with existing behavior, ensure policy alignment, and add tests.

- Ensure the Lecturer Documents resource:
  - Appears in the Lecturer navigation for users who can `viewAny` `Document` (lecturers and admins).
  - Correctly routes to `/lecturer/documents` (actual path determined by Filament; confirm via `php artisan route:list`).
  - Shows the same table configuration as the Admin Documents resource (columns, filters, record actions).
- Confirm behavior for different roles:
  - Lecturer:
    - Can see the Lecturer Documents navigation item.
    - Index page only lists documents where `uploader_id` matches the lecturer’s id.
    - Replace/delete actions work for their own documents and are denied by policy for others (even if accessed via crafted URLs).
  - Admin:
    - Can still use the Admin Documents resource for global management.
    - In the Lecturer panel, the Documents resource will show only documents where `uploader_id` matches the admin (as constrained by the query scope); this is acceptable since the primary global view remains the Admin panel.
- Add `tests/Feature/Filament/Lecturer/DocumentsResourceTest.php`:
  - Use existing testing patterns (`PanelAccessTest`, `DocumentPolicyTest`) to set up seeded roles and `Document` records.
  - Verify:
    - A lecturer with role `lecturer` can access the Lecturer Documents index route.
    - A lecturer only sees their own documents in the table.
    - Documents created for other lecturers do not appear.
    - Replace/delete actions succeed for their own documents (happy path).
    - Replace/delete are not authorized via policy for documents owned by other lecturers.
- Run and iterate on tests and any static analysis (e.g., type hints, imports) to ensure consistency with the existing codebase.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1. Review Existing Admin Documents Resource
- Open `app/Filament/Admin/Resources/Documents/DocumentResource.php` and confirm structure (model, navigation, `table()` delegating to `DocumentsTable`).
- Inspect `app/Filament/Admin/Resources/Documents/Tables/DocumentsTable.php` to understand existing query modification, columns, filters, and record actions.
- Note that `modifyQueryUsing()` is already used and can be safely chained from another resource.

### 2. Define Lecturer DocumentResource Class
- Create `app/Filament/Lecturer/Resources/Documents/DocumentResource.php` with the correct namespace and `extends Resource`.
- Set static properties:
  - `$model = Document::class`.
  - `$navigationIcon = Heroicon::OutlinedDocumentText`.
  - `$navigationGroup` to a suitable Lecturer grouping (for example, “Documents” or similar, consistent with other Lecturer nav items).
  - `$navigationSort` to position the item near the uploads dashboard (e.g., just after it).
  - `$navigationLabel`, `$modelLabel`, and `$pluralModelLabel` as “Documents” / “Document” or similar, mirroring the Admin resource where reasonable.
- Implement `shouldRegisterNavigation()` to return `auth()->check() && static::canViewAny()`, leveraging `DocumentPolicy`.

### 3. Implement Lecturer table() with Scoped Query
- In the new `DocumentResource::table(Table $table): Table`:
  - Import and call `App\Filament\Admin\Resources\Documents\Tables\DocumentsTable::configure($table)` to reuse all columns, filters, and actions.
  - Chain `.modifyQueryUsing()` with a closure:
    - Type-hint `Builder $query`.
    - Resolve `$userId = auth()->id();`.
    - If `$userId` is null, return `$query->whereRaw('1 = 0')` or equivalent to yield no records (defensive).
    - Otherwise, return `$query->where('uploader_id', $userId);`.
- Ensure the method imports `Illuminate\Database\Eloquent\Builder` and any Filament types as needed.
- Confirm that the combined query:
  - Still eager-loads relationships (`offering.programme`, `offering.session`, `offering.course`, `uploader`).
  - Orders by `created_at` descending.
  - Applies the lecturer-specific `uploader_id` filter.

### 4. Add Lecturer ListDocuments Page
- Create `app/Filament/Lecturer/Resources/Documents/Pages/ListDocuments.php` and extend `Filament\Resources\Pages\ListRecords`.
- Set `protected static string $resource = DocumentResource::class;`.
- Override `getHeaderActions()` to return an empty array, matching Admin behavior (no “Create” button).
- Override `getHeading()` to something Lecturer-friendly like “Documents”.
- Override `getSubheading()` to describe the purpose, e.g., “Search and manage documents you’ve uploaded across all offerings.”
- Check that the default route segment (`/`) under the resource path is acceptable (Filament will generate the full path under the Lecturer panel).

### 5. Verify Navigation and Routing in Lecturer Panel
- Confirm that `LecturerPanelProvider` requires no code change due to `discoverResources()` already pointing to `app/Filament/Lecturer/Resources`.
- Run `php artisan route:list | grep lecturer` (or equivalent) to verify that routes for the Lecturer Documents resource are registered (e.g., `filament.lecturer.resources.documents.index`).
- Manually verify (in a dev environment) that:
  - A lecturer sees the Documents navigation item when logged in and verified.
  - Clicking the navigation item loads the Lecturer Documents list page.
  - The table layout matches the Admin Documents table (columns, filters, actions) visually and functionally.

### 6. Validate Lecturer Scoping and Policy Enforcement
- Create test data with at least two lecturers and multiple `Document` records:
  - Some documents for lecturer A (`uploader_id` = A).
  - Some documents for lecturer B (`uploader_id` = B).
- As lecturer A:
  - Navigate to the Lecturer Documents list:
    - Verify only A’s documents appear.
    - Confirm that filters (programme, session, course, offering, milestone, folder, date range, MIME) still behave correctly within A’s subset.
  - Attempt to use replace/delete actions on A’s documents; ensure they succeed as expected.
- Confirm via tests and/or manual checks that:
  - Documents owned by lecturer B do not appear in lecturer A’s table.
  - If a lecturer somehow crafts a URL to another lecturer’s document record, `DocumentPolicy` prevents viewing/managing it.

### 7. Add Feature Tests for Lecturer Documents Resource
- Create `tests/Feature/Filament/Lecturer/DocumentsResourceTest.php`.
- Seed roles and permissions as done in `PanelAccessTest` (e.g., using `RolesAndPermissionsSeeder` or equivalent).
- Write tests that:
  - Assert a lecturer with role `lecturer` can GET the Lecturer Documents index route and receives an OK response.
  - Assert a lecturer without the `lecturer` role (or an unverified user) receives a forbidden/redirect response when trying to access the Lecturer Documents index.
  - Create documents for two lecturers and assert that the Lecturer Documents table response for lecturer A includes A’s document metadata and excludes B’s.
  - Optionally, exercise a replace or delete action via HTTP/Livewire if feasible, asserting that policy prevents acting on another lecturer’s document.
- Keep tests consistent with existing Pest-based test style and naming.

### 8. Run Tests and Static Checks
- Execute the application’s test suite (or at least the subset relevant to documents and Filament) to ensure no regressions:
  - Existing Document-related tests (`DocumentPolicyTest`, `DocumentOperationsServiceTest`, `DocumentPathAndMediaTest`) should continue to pass unchanged.
  - New `DocumentsResourceTest` should pass and validate scoping.
- Fix any failures related to missing imports, namespaces, or route naming.

### 9. Document Any Deviations from Admin Behavior
- Note (in commit message or internal docs) that:
  - The Lecturer Documents resource intentionally scopes to the current user’s documents only, even for admins when accessing the Lecturer panel.
  - Admins continue to have a global view via the Admin Documents resource.
- Confirm that product stakeholders are aware of this scoping behavior for the Lecturer panel.

### 10. Final Verification
- Perform a final manual QA pass in a local environment:
  - Log in as a lecturer, navigate between Uploads Dashboard and the new Documents list, and ensure the experiences complement each other.
  - Confirm that replacing/deleting documents in the Lecturer Documents list still triggers all existing backend behavior (media replacement, metadata sync, completeness cache invalidation).
  - Verify no navigation clutter or confusing duplication appears in the Lecturer panel.

## Testing Strategy

### Automated Testing
- **Feature tests**:
  - `tests/Feature/Filament/Lecturer/DocumentsResourceTest.php`:
    - Verifies lecturer role access to the Lecturer Documents index route.
    - Ensures only documents with `uploader_id` equal to the logged-in lecturer are visible.
    - Confirms that documents belonging to other lecturers do not appear.
    - Optionally exercises replace/delete actions to validate that they succeed for own documents and are denied for others (via policy).
- **Existing tests** (regression coverage):
  - `tests/Feature/Policies/DocumentPolicyTest.php`: continues to ensure lecturers can only manage their own documents and admins can manage any.
  - `tests/Feature/Services/DocumentOperationsServiceTest.php` and `tests/Feature/DocumentMediaTest.php`: ensure document operations and media integration continue to work correctly when invoked from the new resource actions.
  - `tests/Feature/Filament/PanelAccessTest.php`: ensures panel-level access control remains correct for Admin vs Lecturer panels.

### Manual Testing
- As a lecturer:
  - Confirm you can see the Documents navigation item in the Lecturer panel.
  - Verify the list shows all and only your uploads, with working filters and actions.
  - Replace and delete a sample document; confirm notifications and behavior mirror the Admin panel.
- As an admin:
  - Confirm Admin Documents resource still shows all documents without the lecturer scope.
  - Optionally log into the Lecturer panel and confirm the Lecturer Documents list shows only admin-uploaded documents, as per scoped query.

### Edge Cases
- Lecturer with no documents:
  - Ensure the table handles an empty state gracefully (e.g., shows no rows but does not error).
- Documents without certain relationships:
  - Documents where `offering` or related `programme/session/course` are missing should still render without breaking columns; existing Admin behavior should already define how these cases are handled.
- Auth anomalies:
  - If `auth()->id()` is unexpectedly null when accessing the Lecturer Documents resource, ensure the query yields no records and access is ultimately guarded by panel auth middleware.

## Acceptance Criteria
- A new Lecturer Documents resource exists at `app/Filament/Lecturer/Resources/Documents/DocumentResource.php` with a corresponding `ListDocuments` page under the Lecturer panel.
- The Lecturer Documents table:
  - Uses the same columns, filters, and record actions as the Admin Documents table by delegating to `DocumentsTable::configure()`.
  - Is scoped so that lecturers only see documents where `uploader_id` equals the logged-in user’s id.
- `DocumentPolicy` continues to enforce that lecturers can only view and manage their own documents, and admins retain full access.
- Navigation:
  - Lecturers see a “Documents” (or equivalent) item in the Lecturer panel navigation and can access the list view.
  - Unauthorized or unverified users cannot access the Lecturer Documents resource.
- Tests:
  - New `DocumentsResourceTest` passes and clearly validates scoping behavior.
  - All existing tests (unit and feature) continue to pass without modification.

## Validation Commands
Execute these commands to validate the task is complete:

- `php artisan test --filter=DocumentsResourceTest` - Run the new Lecturer Documents resource tests.
- `php artisan test --testsuite=Feature` - Run feature tests, including policies and document operations.
- `php artisan test` - Run the full test suite to ensure no regressions.
- `php artisan route:list | grep filament.lecturer.resources.documents` - Confirm Lecturer Documents routes are registered.

## Notes
- No new packages are required; the implementation reuses existing Filament, Spatie Media Library, and shared document services.
- Query scoping and `DocumentPolicy` together provide defense-in-depth:
  - The query ensures lecturers cannot see other lecturers’ documents in the table.
  - The policy ensures lecturers cannot act on documents they do not own, even if a URL is manually crafted.
- If future requirements diverge between Admin and Lecturer document views (e.g., different columns), consider extracting a shared table definition class or trait for columns/filters while allowing per-panel query configuration.

