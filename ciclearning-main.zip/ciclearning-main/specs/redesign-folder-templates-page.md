# Feature: Redesign Folder Templates Page (Two-Pane UI with Node Details)

## Feature Description
Redesign the Admin “Folder Templates” management page to a two-pane layout that mirrors the provided UI. The left pane presents the hierarchical Template Tree with drag-and-drop reordering and an explicit Save action. The right pane shows Node Details for the selected node, including Label, a Required toggle, and actions to Add Child, Delete, and Save Changes. The redesign improves clarity, reduces in-list editing clutter, and introduces a first-class “required vs optional” flag for each node used later by completeness checks and lecturer UX.

## User Story
As an Administrator
I want to manage the folder template tree with a clear tree view and a dedicated details panel
So that I can quickly edit labels, set whether folders are required, and reorganize nodes confidently

## Problem Statement
- The current page edits nodes inline within the tree, which is visually noisy and increases cognitive load.
- There’s no explicit “required” attribute to distinguish mandatory folders from optional ones; future completeness logic needs this.
- Reordering persists immediately on drop, offering no chance to review changes before saving.

## Solution Statement
Implement a split layout:
- Left: Template Tree with “+ Add Root” and a prominent “Save” button to persist reorder changes. Nodes are clickable to select, and the selected node is highlighted. Drag-and-drop supports re-parenting and reordering up to depth 3.
- Right: Node Details card containing Label, Required toggle, Add Child, Delete, and Save Changes. Saving validates uniqueness per-sibling and cascades path updates as today. Add Child pre-fills parent from the selected node.
- Add a boolean `required` column to `folder_template_nodes` and surface it in the UI. Tree icons reflect required (green check) vs optional (gray/no-check), matching the reference layout.

## Relevant Files
Use these files to implement the feature:

- app/Filament/Admin/Pages/ManageFolderTemplates.php
  - Filament page definition and authorization; remains the entry point. May need only copy updates to title/description.
- app/Livewire/Admin/FolderTemplateTree.php
  - Livewire component that loads/persists the tree. Extend with: `selectedNodeId`, `nodeForm` (label, required), explicit `saveReorder()` method, `selectNode()`, and `saveNodeDetails()`; keep `MAX_DEPTH` enforcement.
- app/Models/FolderTemplateNode.php
  - Add `required` boolean, casts/fillable; ensure path and depth recalculations remain intact; guard uniqueness and depth as before.
- app/Models/FolderTemplate.php
  - No functional changes; ensure eager loading helpers still apply.
- resources/views/filament/admin/pages/manage-folder-templates.blade.php
  - Update to load the new two-pane tree view layout and assets.
- resources/views/livewire/admin/folder-template-tree.blade.php
  - Replace inline edit forms with split-pane markup; left panel tree + top actions (Add Root, Save), right panel Node Details form.
- resources/views/livewire/admin/partials/folder-node.blade.php
  - Update to be a clickable, selectable tree item; render required/optional icons; remove embedded forms.
- resources/js/folder-template-tree.js
  - Keep SortableJS; add explicit “Save” trigger wiring to call `saveReorder()`; refresh sortables on Livewire updates; highlight selected node.
- resources/css/app.css
  - Minor utility class additions if needed for the panel visuals (stick to Tailwind 4 + Filament patterns).
- database/migrations/*create_folder_template_nodes_table.php
  - New migration to add `required` boolean with default true; index if needed.
- database/factories/FolderTemplateNodeFactory.php
  - Default `required` => true; include state helpers for optional.
- tests/Feature/Filament/Admin/ManageFolderTemplatesPageTest.php
  - Extend with tests for selection → form editing, required toggle persistence, explicit reorder Save behavior.
- tests/Unit/FolderTemplateNodeTest.php
  - Add tests for `required` default/cast and sibling-unique slug behavior unchanged.

### New Files
- database/migrations/XXXX_XX_XX_XXXXXX_add_required_to_folder_template_nodes_table.php
  - Adds `required` boolean (default true) to `folder_template_nodes`.
- resources/views/livewire/admin/partials/node-details.blade.php
  - Extracted Node Details form view for clarity and reuse.

## Implementation Plan
### Phase 1: Foundation
- Add `required` column to `folder_template_nodes` (boolean, default true, not nullable).
- Update `FolderTemplateNode` model: `$fillable`, `$casts['required' => 'bool']`.
- Update factory and seeders to populate realistic required/optional mixes.
- Confirm policy continues to restrict page to admins via `folder-template.manage` permission.

### Phase 2: Core Implementation
- Livewire state additions:
  - `selectedNodeId`, `nodeForm = ['label' => '', 'required' => true]`, `pendingTree = []`, `hasPendingReorder = false`.
- Methods:
  - `selectNode(int $id)`, `deselectNode()`: populate `nodeForm` from node, manage highlight.
  - `saveNodeDetails()`: validate label presence/length and sibling-unique slug, persist `label` + `required`, cascade path cache.
  - `addChild()`: validates depth limit; creates child under `selectedNodeId` with default `required = true`.
  - `deleteSelected()`: prevent delete if children exist; soft delete; clear selection if deleting selected.
  - `saveReorder(array $tree = null)`: persist branch using existing `persistBranch()`; invoked by Save button after drag-and-drop. Set `hasPendingReorder = false`.
  - Keep `reorder(array $tree)`: update `pendingTree` and set `hasPendingReorder = true` without persisting.
- Blade changes:
  - Two responsive columns: left tree + right details card.
  - Left: page title, help text, milestone select, “+ Add Root”, “Save” (disabled unless `hasPendingReorder`).
  - Tree items are clickable; selected node uses a highlight background.
  - Right: Node Details with Label input, “Required” toggle, “+ Add Child”, “Delete”, and “Save Changes”. Include UX tip copy.
- JS changes:
  - Continue using SortableJS; on drag end emit `tree-reordered` with serialized tree; Livewire sets `hasPendingReorder` instead of persisting immediately.
  - Add `data-selected` attributes to sync selection highlight.

### Phase 3: Integration
- Activity log: ensure create/update/delete/reorder actions still produce logs via `LogsActivity` traits.
- Surface required/optional state in tree icons (green check for required, gray/outline for optional) for instant scanning.
- Keep max depth and sibling slug uniqueness validations with clear error notifications.
- Ensure first root node auto-selects to populate the details panel on page load.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1) Add DB column `required`
- Create migration `add_required_to_folder_template_nodes_table` with `table->boolean('required')->default(true);`.
- Run `php artisan migrate`.
- Update `app/Models/FolderTemplateNode.php` `$fillable` and `$casts`.
- Update `database/factories/FolderTemplateNodeFactory.php` to include `required`.

### 2) Extend Livewire component state and actions
- In `app/Livewire/Admin/FolderTemplateTree.php`:
  - Add properties: `public ?int $selectedNodeId = null; public array $nodeForm = ['label' => '', 'required' => true]; public array $pendingTree = []; public bool $hasPendingReorder = false;`.
  - Add methods: `selectNode`, `deselectNode`, `saveNodeDetails`, `addChild`, `deleteSelected`, `saveReorder`.
  - Modify `reorder()` to only set `pendingTree` and `hasPendingReorder = true`.
  - Update `buildTree()` to include `required` in mapped nodes for icon rendering.
  - Keep `persistBranch()` and max depth validation logic.

### 3) Replace Blade layouts to two-pane design
- Update `resources/views/livewire/admin/folder-template-tree.blade.php` to the two-column layout:
  - Top area: title + help, milestone select.
  - Left card: Template Tree, “+ Add Root”, “Save”. List uses `data-folder-list` for Sortable. Items clickable; highlight if `$selectedNodeId === $node['id']`.
  - Right card: Include `partials/node-details.blade.php` rendering Label, Required toggle, “+ Add Child”, “Delete”, “Save Changes”. Disabled state if no node selected.
- Update `resources/views/livewire/admin/partials/folder-node.blade.php`:
  - Remove inline forms; render label, path, and icon depending on `required`.
  - Add click handler `wire:click="selectNode({{ $nodeId }})"` and selection styling.
- Add `resources/views/livewire/admin/partials/node-details.blade.php` partial.

### 4) Wire JS for explicit Save
- Update `resources/js/folder-template-tree.js`:
  - Keep Sortable init; onEnd dispatch `tree-reordered` (no immediate persist).
  - Add handler for a global `data-action="save-reorder"` button to call `saveReorder` on the Livewire component with the latest serialized tree.
  - Ensure sortables are refreshed on `tree-updated` and `message.processed` hooks.

### 5) Update Filament page wrapper (minor)
- Keep `resources/views/filament/admin/pages/manage-folder-templates.blade.php` calling the Livewire component and asset pushes.
- Optionally add page description text per mock.

### 6) Tests
- Unit: `tests/Unit/FolderTemplateNodeTest.php`
  - Assert default `required` true; cast to bool; ensure path/depth logic remains intact when toggling.
- Feature: `tests/Feature/Filament/Admin/ManageFolderTemplatesPageTest.php`
  - Admin can select a node and see details panel populated.
  - Save label change persists and refreshes tree label/path.
  - Toggle required off/on and verify DB value + tree icon state via rendered HTML.
  - Drag → no DB changes until clicking Save; after Save, positions/parents persist.
  - Depth limit still enforced when attempting to add child at level 3 → error.
- Keep existing reorder/CRUD tests and adapt to new methods if signatures changed.

### 7) Accessibility & UX polish
- Ensure buttons have clear labels and focus rings; keyboard tab order works; `aria-selected` on selected tree node.
- Confirm validation errors render near inputs and as Filament notifications.

### 8) Run Validation Commands
- Execute the commands listed below; ensure green test suite and asset build without errors.

## Testing Strategy
### Unit Tests
- FolderTemplateNode
  - Defaults: `required = true` and boolean cast.
  - Path/depth recalculation unchanged when editing label or moving nodes.
  - Sibling slug uniqueness errors remain enforced.

### Integration Tests
- Livewire FolderTemplateTree
  - Select node → nodeForm hydration.
  - SaveNodeDetails updates label and required; path cache recalc; notifications success.
  - AddChild respects MAX_DEPTH; creates child under selected.
  - DeleteSelected rejects when children exist; succeeds when leaf; clears selection.
  - Reorder via `tree-reordered` does not persist until `saveReorder`.

### Edge Cases
- Deleting the selected node resets the details panel state gracefully.
- Re-parenting branches near depth limit is rejected with helpful error.
- Duplicate label producing same slug in same parent triggers validation error.
- Switching milestones reloads the correct template, clears pending reorder, and resets selection.

## Acceptance Criteria
- Page shows a two-pane layout: left Template Tree with “+ Add Root” and “Save” buttons; right Node Details card with Label, Required toggle, Add Child, Delete, Save Changes.
- Clicking any node highlights it and populates the Node Details panel.
- Drag-and-drop reordering works; no DB writes occur until Save is clicked; Save persists order and parentage with depth ≤ 3.
- Editing a node and saving updates label and path for it and descendants; Required toggle persists and updates left-pane icon.
- Add Child creates a new node under the selected node; Delete prevents deletion when children exist.
- Validation and errors surface via Filament notifications and inline messages; all actions are audited.
- All tests pass; asset build succeeds; no PHPStan/Pint errors.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `php artisan migrate` - Apply the new `required` column.
- `php artisan test` - Run tests to validate the feature works with zero regressions
- `composer lint` - Ensure code style passes.
- `composer stan` - Static analysis for added/changed code.
- `pnpm install` - Install/update SortableJS if versions changed.
- `pnpm run build` - Build assets for the updated Livewire/JS.
- `php artisan serve` - Manual smoke test at `/admin` → “Folder Templates”.

## Notes
- Libraries: No new PHP packages required. Frontend continues to use `sortablejs` (already in `package.json`).
- Keep max depth at 3 (`FolderTemplateNode::MAX_DEPTH`). If future needs expand, consider converting to an adjacency list with nested set helpers, but current design is sufficient for MVP.
- The `required` flag unlocks downstream completeness logic (✅ vs ❌ per lecturer). Future work: lecturer views should suppress optional folders from affecting completeness.
