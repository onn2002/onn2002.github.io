# Feature: Shared — Documents, Paths & Services

## Feature Description
Introduce shared backend services to consistently enforce document storage rules across both Admin and Lecturer panels: path generation, filename sanitization and renaming, collision-safe storage, and per-lecturer folder completeness computation. These services centralize core behaviors specified in the PRD so uploads land under the correct directory structure, files are renamed deterministically, and UI can reliably show ✅/❌ status and counts. The shared services are framework-agnostic (usable from Filament forms, actions, or controllers) and designed for extensibility.

## User Story
As a Developer
I want to centralize documents pathing, renaming, and completeness logic
So that both panels apply identical, reliable rules with minimal duplication

## Problem Statement
Currently, the application lacks a single, authoritative implementation for PRD-defined storage behaviors. Without shared services: uploads risk drifting from the path format, filenames may be inconsistent or collide, and completeness needs duplicative queries. This increases maintenance cost and the chance of regressions when integrating upload UIs, admin file operations, and reports.

## Solution Statement
Build shared services that encapsulate PRD rules and integrate with Spatie Media Library:
- Path builder: `{programme_code}/{semester_code}/{course_identifier}/{milestone}/{folder_path}/` derived from `CourseOffering`, `Milestone`, and a leaf `FolderTemplateNode`.
- Sanitizer & renamer: `{original_base_name_sanitized}_{course_code}_{YYYYMMDD}.{ext}` using MYT date; append `_{n}` on collision.
- Storage orchestration: a small service that uses the path builder + renamer to write to disk atomically and update `Document` + MediaLibrary metadata.
- Completeness service: compute ✅/❌ per lecturer for each leaf folder (with aggregate counts) and cache results, invalidated on upload/move/replace/delete.
- Media Library path generator: ensure Media files physically live under the enforced directory path.

## Relevant Files
Use these files to implement the feature:

- app/Services/FolderPathService.php
  - Existing path service; align output to PRD format (milestone segment and normalization rules), add helpers as needed.
- app/Models/Document.php
  - Owner model for binaries; holds metadata (`offering_id`, `milestone`, `folder_slug`, `uploader_id`, etc.). Will leverage shared services and refresh metadata post-upload.
- app/Models/CourseOffering.php
  - Source for `programme_code`, `session_code`, `course_identifier`, and related relations.
- app/Models/FolderTemplate.php, app/Models/FolderTemplateNode.php
  - Provides leaf nodes and `path_cache` used for `{folder_path}` segment.
- app/Enums/Milestone.php
  - Extend with a method for the path segment (e.g., `FinalExamPackage`), used by the path builder.
- config/media-library.php
  - Register a custom path generator for `Document` so Media files are stored under the enforced path.
- config/admin.php
  - Read MIME whitelist and max upload size; used for validation in upload orchestration.
- database/migrations/2025_10_24_022743_create_documents_table.php
  - Confirms metadata columns needed by services; no schema change required for this feature.
- tests/**
  - Add tests for sanitizer, renamer, path generation, Media storage, and completeness computation.

### New Files
- app/Services/DocumentRenamer.php
  - Generates `{sanitized_original}_{course_code}_{YYYYMMDD}.{ext}`; includes collision resolution by probing the target folder.
- app/Support/FilenameSanitizer.php
  - Implements sanitization rules: strip `\/:*?"<>|` and control chars, collapse whitespace, trim, preserve casing.
- app/Services/DocumentStorageService.php
  - Orchestrates storage: validate input, build path, generate filename, ensure directory exists, handle collisions, attach Media to `Document`, and return updated model.
- app/Services/CompletenessService.php
  - Computes per-lecturer ✅/❌ for all leaf folders of a milestone and aggregate counts; caches by `(user, offering, milestone)`; exposes invalidate methods.
- app/MediaLibrary/DocumentPathGenerator.php
  - Custom Spatie PathGenerator that returns the enforced directory path for `Document` media items.
- tests/Unit/FilenameSanitizerTest.php
  - Unit tests for sanitization rules and representative edge cases.
- tests/Unit/DocumentRenamerTest.php
  - Unit tests for rename format and collision suffixing.
- tests/Feature/DocumentPathAndMediaTest.php
  - Integration test verifying on-disk path matches PRD structure and `Document::path_string` syncs.
- tests/Feature/CompletenessServiceTest.php
  - Integration tests for ✅/❌ per lecturer and aggregate counts; includes cache invalidation on upload/delete.

## Implementation Plan
### Phase 1: Foundation
- Align `FolderPathService` with PRD path format and add a Milestone path segment helper.
- Implement `FilenameSanitizer` and `DocumentRenamer` with MYT date handling and collision logic.
- Create `DocumentPathGenerator` and register it for `Document` in `config/media-library.php`.

### Phase 2: Core Implementation
- Build `DocumentStorageService` that composes path builder + renamer and integrates with Media Library for atomic writes.
- Implement `CompletenessService` (query + cache + invalidate hooks) using `FolderTemplate::leafNodes()` and `documents` table index.
- Add unit/integration tests for the above; ensure Storage fakes isolate on-disk assertions.

### Phase 3: Integration
- Wire cache invalidation on `Document` model events (created, updated: folder/milestone/offering/uploader, deleted).
- Ensure Admin and Lecturer flows later call the storage/completeness services (no UI changes in this feature; provide usage examples for later integration).
- Verify config: `FILESYSTEM_DISK=local`, `MEDIA_DISK=local`, MIME whitelist and max size respected.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1) Add Milestone path-segment helper
- Extend `app/Enums/Milestone.php` with `public function pathSegment(): string` returning label with spaces removed (e.g., `FinalExamPackage`).
- Use this method anywhere path segments are constructed.

### 2) Align FolderPathService output
- Update `app/Services/FolderPathService.php::buildPath()` to build:
  - `{programme_code}/{semester_code}/{course_identifier}/{milestone_path_segment}/{folder_path}/`.
  - Stop lowercasing or slugging codes/identifiers; only replace `/` and `\` with `-` to preserve casing (PRD says preserve casing).
- Add guard to ensure `$node->isLeaf()`; return trailing slash.

### 3) Implement FilenameSanitizer
- Create `app/Support/FilenameSanitizer.php` with a `sanitize(string $name): string` method:
  - Strip `\/:*?"<>|` and UTF-8 control chars.
  - Collapse internal whitespace to single spaces; trim; preserve casing.
  - Ensure result is non-empty; if empty, default to `file`.

### 4) Implement DocumentRenamer
- Create `app/Services/DocumentRenamer.php` with:
  - `generate(string $originalName, string $courseCode, \DateTimeInterface $mytNow, ?callable $existsProbe): string`.
  - Parse extension; sanitize base name; compose `{base}_{courseCode}_{YYYYMMDD}.{ext}` using MYT date (`Asia/Kuala_Lumpur`).
  - Collision handler: use `$existsProbe($candidate)` to check existence in target folder; append `_{n}` before extension until unique.

### 5) Implement DocumentPathGenerator
- Add `app/MediaLibrary/DocumentPathGenerator.php` implementing `Spatie\MediaLibrary\Support\PathGenerator\PathGenerator`:
  - For `getPath(Media $media)`, compute path via `FolderPathService` from `$media->model` (`Document`), using related `offering`, `milestone`, and `folder_slug` (resolved via template node path).
  - Mirror behavior for `getPathForConversions()` to store conversions alongside originals.
- Register it in `config/media-library.php` under `custom_path_generators` for `App\Models\Document::class`.

### 6) Implement DocumentStorageService
- Create `app/Services/DocumentStorageService.php` with a method like `store(CourseOffering $offering, Milestone $milestone, FolderTemplateNode $leaf, UploadedFile $file, User $uploader): Document`.
- Validate MIME and size against `config('admin.*')`.
- Build folder path via `FolderPathService` and generate filename via `DocumentRenamer` (with collision probe using the Media disk and computed directory).
- Create a `Document` row with metadata (offering, milestone, folder path string, uploader) and attach Media using `usingFileName($final)` and `toMediaCollection(Document::MEDIA_COLLECTION)`.
- Return refreshed `Document`.

### 7) Implement CompletenessService
- Create `app/Services/CompletenessService.php` with methods:
  - `statusFor(User $user, CourseOffering $offering, Milestone $milestone): array` → array keyed by leaf `path_cache` with fields `{required: bool, you: int, total: int, done: bool}`.
  - `invalidate(User $user, CourseOffering $offering, Milestone $milestone): void`.
- Compute counts using the indexed `(offering_id, milestone, folder_slug, uploader_id)` and `FolderTemplate::leafNodes()` for the milestone.
- Cache results by a deterministic key; invalidate on `Document` created/moved/replaced/deleted.

### 8) Hook cache invalidation on Document events
- In `app/Models/Document.php::booted()`, add listeners for `created`, `updated` (when folder/milestone/offering/uploader change), and `deleted` to call `CompletenessService::invalidate(...)` for affected lecturer and offering/milestone.
- Ensure this does not introduce circular dependencies with Media events (prefer resolving service via container with `app(CompletenessService::class)`).

### 9) Add tests
- Unit: `FilenameSanitizerTest` (character stripping, whitespace collapse, empty name fallback).
- Unit: `DocumentRenamerTest` (date formatting, collision suffixing, extension handling, casing preserved).
- Feature: `DocumentPathAndMediaTest` (fake storage; create offering + leaf; upload file via storage service; assert on-disk relative path equals PRD format; assert `Document::path_string` syncs).
- Feature: `CompletenessServiceTest` (seed leaves; create documents for different users; assert per-lecturer ✅/❌ and aggregate counts; assert cache invalidates on create/delete).

### 10) Run Validation Commands
- See commands below; ensure all pass without errors.

## Testing Strategy
### Unit Tests
- Sanitizer strips disallowed characters, removes control chars, collapses whitespace, preserves casing, and handles empty base names.
- Renamer composes `{base}_{courseCode}_{YYYYMMDD}.{ext}` with MYT date and correctly appends `_{2}`, `_{3}`, … on collision.

### Integration Tests
- Media path generation stores files under `{programme}/{session}/{course_identifier}/{milestone}/{folder}/` with trailing slash; `Document::path_string` matches Media path.
- Completeness service returns accurate status for the current lecturer and aggregate counts across all uploaders; cache invalidates on mutations.

### Edge Cases
- Original filenames with only illegal characters or only spaces.
- Very long base names; ensure truncated where necessary (optional cap, e.g., 200 chars before extension).
- Duplicate uploads on the same day (collision suffix increments).
- Folder paths with 2–3 nested segments in leaf nodes.
- Multiple lecturers uploading to the same leaf.
- Timezone correctness around MYT midnight (date component).

## Acceptance Criteria
- Files stored under exact PRD path format using offering codes, course identifier, milestone path segment, and leaf folder path.
- Server-side rename follows `{sanitized_original}_{course_code}_{YYYYMMDD}.{ext}` with MYT date and collision suffixing.
- `Document::path_string`, `stored_filename`, `original_filename`, `filesize`, and `mime` are accurate after upload.
- Completeness service returns ✅/❌ for current lecturer per leaf folder and exposes aggregate counts; caches and invalidates correctly.
- Media Library configured with a custom path generator for `Document`.
- All new and existing tests pass.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- php artisan migrate:fresh --seed
- php artisan test --testsuite=Unit
- php artisan test --testsuite=Feature --filter=DocumentPathAndMediaTest
- php artisan test --testsuite=Feature --filter=CompletenessServiceTest
- php artisan test
- vendor/bin/pint --test
- php -d detect_unicode=0 -l $(git ls-files "app/**/*.php")
- php -v > /dev/null && node -v > /dev/null
- php artisan about
- `php artisan test` - Run tests to validate the feature works with zero regressions

## Notes
- No new PHP packages required. Uses existing Spatie Media Library via a custom PathGenerator and `usingFileName()` during upload.
- Ensure `.env` has `FILESYSTEM_DISK=local` and set `MEDIA_DISK=local` to keep files private under `storage/app/private` per README; adjust `config/media-library.php` if needed.
- Use `Asia/Kuala_Lumpur` for all date formatting related to renaming. Prefer `now('Asia/Kuala_Lumpur')` or `Carbon::now('Asia/Kuala_Lumpur')` consistently.
- Services are framework-neutral and can be consumed from Filament actions/forms later when implementing Lecturer uploads and Admin file operations.

