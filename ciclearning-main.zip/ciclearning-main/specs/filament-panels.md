# Feature: Filament Panels (Single User Model; Two Distinct Panels)

## Feature Description
Introduce two separate Filament panels that both authenticate against a single `User` model: an Admin Panel (`/admin`) for catalog, configuration, reporting, and file operations; and a Lecturer Panel (`/lecturer`) focused on uploads and personal progress. Access to each panel is gated via Spatie roles on the same user table. This separation clarifies UX, reduces cognitive load, and enforces least-privilege access while retaining a unified identity store.

## User Story
As a system user (admin or lecturer)
I want a dedicated panel tailored to my role
So that I only see and can access the features relevant to my responsibilities

## Problem Statement
The project currently exposes only a single Filament panel and lacks role-gated separation of concerns. Admin tasks (catalog, templates, reports) and lecturer tasks (uploads, progress) need distinct navigation, branding, and access rules to reduce confusion and improve security.

## Solution Statement
Create a second Filament panel and gate both panels by role using `FilamentUser::canAccessPanel()`. Keep a single `users` table and session guard. Register an `AdminPanelProvider` (existing) and a new `LecturerPanelProvider`, each with its own path, color theme, and discovery namespaces. Update the `User` model to implement `Filament\Models\Contracts\FilamentUser` and return role-based access: only `admin` can access the Admin panel; `lecturer` (and optionally `admin`) can access the Lecturer panel. Provide HTTP tests that validate access per role, including verified vs unverified users.

## Relevant Files
Use these files to implement the feature:

- `README.md` – Update “Filament Admin Panel” section to document two panels: `/admin`, `/lecturer`.
- `docs/TODO.md` – The source of truth listing “Filament Panels (single User model; two distinct panels)”.
- `docs/prd.md` – Roles, RBAC expectations, and user flows that map to panel separation.
- `docs/filament/05-panel-configuration.md` – Reference for multi-panel configuration and discovery.
- `app/Providers/Filament/AdminPanelProvider.php` – Scope discovery to `App\Filament\Admin\…`, confirm path/id/colors.
- `app/Providers/Filament/LecturerPanelProvider.php` – New provider for the Lecturer panel.
- `bootstrap/providers.php` – Register both panel providers.
- `app/Models/User.php` – Implement `FilamentUser` and add `canAccessPanel(Panel $panel)` using Spatie roles.
- `routes/web.php` – No changes required; Filament registers its own routes via panel providers.
- `tests/**` – Add feature tests for role-gated access to `/admin` and `/lecturer`.

### New Files
- `app/Providers/Filament/LecturerPanelProvider.php` – Panel provider with `->id('lecturer')`, `->path('lecturer')`, `->login()`, `->colors(['primary' => Color::Green])`, and discovery for `App\Filament\Lecturer\…` namespaces.
- `tests/Feature/Filament/PanelAccessTest.php` – Integration tests asserting access rules for both panels.
- (Optional, stubbed later) `app/Filament/Lecturer/Pages/Dashboard.php` – Custom lecturer dashboard; initially use Filament’s default `Dashboard` class.

## Implementation Plan
### Phase 1: Foundation
- Adopt a panel-specific resource/page namespace to avoid cross-panel collisions: `App\Filament\Admin\…` and `App\Filament\Lecturer\…`.
- Implement `FilamentUser` on `User` with role-gated `canAccessPanel()`.
- Ensure roles `admin` and `lecturer` exist via seeders (already present), and keep a single `web` guard.

### Phase 2: Core Implementation
- Create `LecturerPanelProvider` with `->id('lecturer')`, `->path('lecturer')`, login enabled, green primary color, SPA mode optional, and middleware stack similar to admin.
- Update `AdminPanelProvider` to:
  - Use `->id('admin')`, `->path('admin')`, blue primary color (already present).
  - Scope discovery to `App\Filament\Admin\Resources`, `App\Filament\Admin\Pages`, `App\Filament\Admin\Widgets`.
- Register both providers in `bootstrap/providers.php`.

### Phase 3: Integration
- Confirm Filament route groups are available at `/admin/*` and `/lecturer/*` with separate login pages.
- Add tests covering access for admin, lecturer, unverified users, and users with no role.
- Update README to document both panels, paths, and initial login instructions.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### Step 1 — Add FilamentUser gating on User
- Edit `app/Models/User.php`:
  - `implements Filament\Models\Contracts\FilamentUser`.
  - Add `public function canAccessPanel(\Filament\Panel $panel): bool`:
    - If email verification is required, return `false` if `! $this->hasVerifiedEmail()`.
    - If `$panel->getId() === 'admin'`: return `$this->hasRole('admin') /* && optional: $this->isApprovedAdmin() */`.
    - If `$panel->getId() === 'lecturer'`: return `$this->hasRole('lecturer') || $this->hasRole('admin')` (allow admins to view lecturer panel for parity, per TODO notes).
    - Default: `false`.

### Step 2 — Create LecturerPanelProvider
- Add `app/Providers/Filament/LecturerPanelProvider.php` with:
  - `->id('lecturer')`, `->path('lecturer')`, `->login()`.
  - `->colors(['primary' => Color::Green])`.
  - `->discoverResources(in: app_path('Filament/Lecturer/Resources'), for: 'App\\Filament\\Lecturer\\Resources')`.
  - `->discoverPages(in: app_path('Filament/Lecturer/Pages'), for: 'App\\Filament\\Lecturer\\Pages')`.
  - `->discoverWidgets(in: app_path('Filament/Lecturer/Widgets'), for: 'App\\Filament\\Lecturer\\Widgets')`.
  - `->pages([\Filament\Pages\Dashboard::class])` initially.
  - Mirror the admin middleware/auth middleware list.

### Step 3 — Refactor AdminPanelProvider discovery
- Edit `app/Providers/Filament/AdminPanelProvider.php` to:
  - Keep `->id('admin')`, `->path('admin')`, blue theme, and default login.
  - Change discovery to `App\Filament\Admin\…` namespaces:
    - `->discoverResources(in: app_path('Filament/Admin/Resources'), for: 'App\\Filament\\Admin\\Resources')`
    - `->discoverPages(in: app_path('Filament/Admin/Pages'), for: 'App\\Filament\\Admin\\Pages')`
    - `->discoverWidgets(in: app_path('Filament/Admin/Widgets'), for: 'App\\Filament\\Admin\\Widgets')`

### Step 4 — Register the provider
- Edit `bootstrap/providers.php` to add `App\Providers\Filament\LecturerPanelProvider::class` to the array after Admin.

### Step 5 — Tests for access rules
- Add `tests/Feature/Filament/PanelAccessTest.php` with scenarios:
  - Guest → `/admin` redirects to `/admin/login`.
  - Guest → `/lecturer` redirects to `/lecturer/login`.
  - Verified admin can access `/admin` (200), `/lecturer` (200 allowed by design).
  - Verified lecturer can access `/lecturer` (200) but not `/admin` (403 or redirect to `/admin/login`).
  - Unverified user cannot access either panel (403 or redirect to login). Mark users verified in factories as needed to control state.
  - User with no role cannot access either panel.

### Step 6 — README update
- Update the “Filament Admin Panel” section to “Filament Panels” with paths and short access matrix.

### Step 7 — Run Validation Commands
- Run the commands below and ensure zero errors; fix tests or config if any failures.

## Testing Strategy
### Unit Tests
- `User::canAccessPanel()` returns expected values for:
  - Admin → admin panel: true; lecturer panel: true.
  - Lecturer → lecturer panel: true; admin panel: false.
  - Unverified user: false for both panels.
  - User with no role: false for both panels.

### Integration Tests
- HTTP tests for `/admin` and `/lecturer` as guest, admin, lecturer, and unverified user, asserting redirect targets or status codes as appropriate.
- Ensure the distinct login routes exist: `/admin/login` and `/lecturer/login` render successfully.

### Edge Cases
- Users holding both roles (admin + lecturer) → allowed into both panels (by design).
- Guard misconfiguration (ensure both panels use `web`).
- If admin approval flags are added later, ensure `canAccessPanel()` also checks approval for admin panel.
- Ensure SPA mode (if enabled later) does not break auth redirects.

## Acceptance Criteria
- Two panels exist and are reachable at `/admin` and `/lecturer`, each with its own login page and color theme.
- `User` implements `FilamentUser` and gates access as specified, using Spatie roles.
- Verified admins can access Admin panel; verified lecturers cannot.
- Verified lecturers can access Lecturer panel; admins can also access it (per design).
- Guests are redirected to the correct panel-specific login pages.
- Test suite passes with new panel access tests.
- README documents both panels and access expectations.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `php artisan config:clear`
- `php artisan migrate:fresh --seed`
- `php artisan route:list | grep -E "admin|lecturer|filament"`
- `php artisan test` - Run tests to validate the feature works with zero regressions
- `php artisan serve` (manual smoke check: visit `/admin`, `/admin/login`, `/lecturer`, `/lecturer/login`)

## Notes
- No new Composer packages are required; Filament multi-panel is supported out-of-the-box.
- Namespacing Filament resources/pages by panel (`App\Filament\Admin\…`, `App\Filament\Lecturer\…`) prevents cross-panel collisions and keeps future resources tidy.
- If an admin approval flag is introduced (per Auth feature plan), extend `canAccessPanel()` to deny unapproved admins.
- Consider enabling Filament SPA mode (`->spa()`) later for perceived performance if it doesn’t complicate auth flows.

