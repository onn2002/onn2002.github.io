# Plan: Fix Lecturer Folder Replace Action to Update Document Metadata

## Task Description
The lecturer uploads dashboard exposes a **Replace** action in `FolderFileList` that should swap out the stored file for a `Document` record and ensure all relevant columns in the `documents` table (e.g. `stored_filename`, `original_filename`, `path_string`, `filesize`, `mime`) reflect the replacement. Currently, the replace flow can fail or leave metadata stale because the Livewire/Filament file value is not always converted to an `UploadedFile`, and the UI does not explicitly verify that the replacement has propagated to the database. This plan describes how to make the replace workflow robust from the lecturer-facing Livewire component down through `DocumentOperationsService`, ensuring both the file on disk and the `documents` row are updated consistently.

## Objective
Ensure the **Replace** action in the lecturer uploads UI reliably:
- Accepts the file value from Filament’s `FileUpload` and converts it into an `UploadedFile`/`TemporaryUploadedFile`.
- Invokes `DocumentOperationsService::replace()` with a valid `Document` and `UploadedFile`.
- Replaces the underlying media file on disk in the correct folder path and removes the previous file.
- Updates all relevant metadata fields in the `documents` table so that queries and UI components see the new file information immediately.

## Problem Statement
The lecturer-facing replace feature (implemented in `FolderFileList`) currently has a fragile boundary between the Filament `FileUpload` field and `DocumentOperationsService::replace()`:

- Filament’s `FileUpload` stores a serialized token (e.g. `livewire-file:...`) which is not directly an `UploadedFile`. If passed directly, `DocumentOperationsService::replace()` will throw a type error and no replacement occurs.
- Even when the service call succeeds, we must guarantee that the `documents` table is updated to reflect the new media record (filename, path, mime, size). Any mismatch between the stored file and metadata can break downstream features (e.g. completeness calculations, path-based assertions, or admin exports).
- The replace flow must stay consistent with how initial uploads are handled in `DocumentStorageService` and with path generation rules in `DocumentPathGenerator`, so that renames, moves, and replaces all operate on the same physical layout and metadata conventions.

We need a clearly defined and tested replace pipeline that converts UI input into a proper `UploadedFile`, delegates to `DocumentOperationsService`, and ensures metadata in `documents` is in sync with the media library.

## Solution Approach
The fix will be implemented in two layers:

1. **Livewire/Filament boundary (FolderFileList)**
   - Normalize the `file` value coming from the Filament `FileUpload` component into an `UploadedFile`, handling:
     - Serialized Livewire temporary uploads (`livewire-file:<hash>`).
     - Array-wrapped values for single uploads.
     - Already-instantiated `UploadedFile` instances (e.g. from tests).
   - Only call `DocumentOperationsService::replace()` when a valid `UploadedFile` is available; otherwise, short-circuit gracefully.
   - After replacement, dispatch the existing `documents-updated` event and reset the Filament table so the UI reflects updated metadata.

2. **Domain/service layer (DocumentOperationsService::replace)**
   - Validate the incoming file against `config('admin.mime_whitelist')` and `config('admin.max_upload_mb')`, mirroring `DocumentStorageService::store()` behaviour.
   - Resolve the current document context (offering, milestone, folder slug) and ensure they are present.
   - Use `FolderPathService` and `DocumentRenamer` to compute a new filename in the correct folder, avoiding collisions with existing files in that folder while allowing the existing file name to be “reused” for this document.
   - Add the new media to the `document`’s `document` collection (which is configured as `singleFile()`), letting the media library remove the previous media and its stored file.
   - Refresh metadata on the `Document` via `refreshMediaMetadata()`, which reads from the media model (using the custom `DocumentPathGenerator`) and writes back to `stored_filename`, `original_filename`, `path_string`, `filesize`, and `mime`.
   - Wrap storage and database writes in a transaction, and return a freshly loaded `Document` so calling code can rely on up-to-date attributes if needed.

We will extend tests to verify that:
- The Livewire `replace` table action converts Filament’s serialized uploads into an `UploadedFile` before calling the service.
- `DocumentOperationsService::replace()` removes the old file, creates the new file at the expected path, and updates `documents` metadata.

## Relevant Files
Use these files to complete the task:

- `app/Livewire/Lecturer/FolderFileList.php`
  - Hosts the Filament table used in the lecturer uploads dashboard.
  - Defines the `replace` table action and is responsible for converting Filament’s `FileUpload` value into an `UploadedFile` before delegating to the service.
- `app/Services/DocumentOperationsService.php`
  - Encapsulates document rename, move, replace, and delete operations.
  - `replace()` must ensure both file replacement on disk and metadata refresh on the `documents` table.
- `app/Services/DocumentStorageService.php`
  - Reference for initial upload logic (validation, naming, storage) to keep `replace()` behaviour consistent with `store()`.
- `app/Services/FolderPathService.php`
  - Builds deterministic folder paths based on `CourseOffering`, `Milestone`, and `FolderTemplateNode`/folder slug.
  - Used both during initial upload and in `DocumentPathGenerator` to determine where files should live.
- `app/MediaLibrary/DocumentPathGenerator.php`
  - Custom path generator used by Spatie Media Library for `Document` models.
  - Ensures media files are stored under the same course/milestone/folder structure used by `FolderPathService`.
- `app/Models/Document.php`
  - Owner model for document media; defines the `document` media collection as `singleFile()` and syncs media metadata back into the `documents` table via `refreshMediaMetadata()` / `syncMediaMetadata()`.
- `config/media-library.php`
  - Registers `DocumentPathGenerator` as the custom path generator for `App\Models\Document`.
- `config/admin.php`
  - Provides MIME whitelist and max upload size configuration, which must be respected by both initial uploads and replacements.
- `tests/Feature/Services/DocumentOperationsServiceTest.php`
  - Contains existing tests for rename, move, replace, and delete operations; extend to assert full metadata updates and file replacement behaviour.
- `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php`
  - Contains tests for lecturer uploads dashboard, including the replace action; extend/adjust to ensure a serialized upload is converted to `UploadedFile` and that the `documents-updated` event is dispatched.

### New Files
- _None required._ All changes can be implemented in existing files and covered by extending existing tests.

## Implementation Phases

### Phase 1: Foundation
- Confirm how Filament’s `FileUpload` serializes temporary uploads (via `TemporaryUploadedFile` and `FileUploadConfiguration`) and how these are currently handled in `FolderFileList`.
- Verify `Document`’s media collection is configured as `singleFile()` and that `refreshMediaMetadata()` correctly updates `stored_filename`, `original_filename`, `path_string`, `filesize`, and `mime` from the first media record.
- Review `DocumentStorageService::store()` and `DocumentOperationsService::rename()`/`move()` for naming and path conventions, to ensure `replace()` matches expectations.

### Phase 2: Core Implementation
- Update `FolderFileList`’s `replace` action to normalize the `file` data into an `UploadedFile` and call `DocumentOperationsService::replace()` only when valid.
- Refine `DocumentOperationsService::replace()` (if needed) to guarantee deletion of the old file, creation of the new file in the correct folder path, and metadata refresh in a transaction.
- Align file validation, naming, and path resolution in `replace()` with the conventions used by `DocumentStorageService::store()`.

### Phase 3: Integration & Polish
- Extend service-level and UI-level tests to cover the replace flow end to end (file + metadata).
- Verify that notifications and Livewire events behave correctly and that the table reflects updated records after replacement.
- Perform manual checks (e.g. via the lecturer panel) to confirm that replacing files behaves as expected across MIME types and sizes allowed by configuration.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1. Analyse Current Replace Flow and Failure Modes
- Review `app/Livewire/Lecturer/FolderFileList.php` to map the current `replace` action, including its form schema (`FileUpload`) and action closure.
- Inspect recent logs (e.g. `storage/logs/laravel.log`) for `DocumentOperationsService::replace()` type errors or validation failures to understand real-world failure modes (e.g. strings passed instead of `UploadedFile`).
- Confirm how the `documents` table is currently updated when `replace()` succeeds by inspecting the `Document` model’s metadata syncing logic.

### 2. Ensure File Value Normalisation in FolderFileList
- Implement (or verify and refine) a private helper method in `FolderFileList` such as `normalizeUploadedFile(mixed $value): ?UploadedFile` that:
  - Accepts raw `$data['file']` from Filament (string, array, or `UploadedFile`).
  - If array, returns the first non-empty entry.
  - If string and `TemporaryUploadedFile::canUnserialize($value)` is true, calls `TemporaryUploadedFile::unserializeFromLivewireRequest($value)` to obtain a `TemporaryUploadedFile` instance.
  - If the final value is an instance of `UploadedFile` (or subclass), returns it; otherwise returns `null`.
- Update the `replace` action closure to:
  - Extract `$file = $this->normalizeUploadedFile($data['file'] ?? null);`.
  - Bail out early (no service call) if `$file` is `null` to avoid type errors.
  - Pass the normalized `$file` to `DocumentOperationsService::replace($record, $file)`.

### 3. Harden DocumentOperationsService::replace Logic
- In `app/Services/DocumentOperationsService.php`, verify `replace(Document $document, UploadedFile $file)`:
  - Calls a validation method (e.g. `validateFile`) that enforces the same MIME and size rules as `DocumentStorageService::store()`.
  - Uses `assertDocumentContext($document)` to retrieve `$offering` and `$milestone`, and throws a `ValidationException` with a clear message if required associations are missing.
  - Resolves the current media instance for the document (via `resolveMedia($document)`) to support collision checks and path calculations.
- Compute the replacement filename and directory:
  - Use `FolderPathService::buildPathFromSlug($offering, $milestone, $document->folder_slug)` to derive the base directory.
  - Generate `$original` from `$file->getClientOriginalName()` (fallback to `$file->getFilename()`).
  - Use `DocumentRenamer::generate()` to derive `$filename`, passing a callback that:
    - Returns `false` when `$candidate === $media->file_name` (allowing reuse of the current filename).
    - Returns `true` if a different candidate already exists in `$directory` to force a new unique filename.
  - Derive `$mediaName = pathinfo($filename, PATHINFO_FILENAME)`.
- Replace the media in a transaction:
  - Ensure the directory exists via a helper like `ensureDirectory($disk, $directory)`.
  - In a `DB::transaction` block:
    - Add media to the document via:
      - `$document->addMedia($file)->usingName($mediaName)->usingFileName($filename)->toMediaCollection(Document::MEDIA_COLLECTION);`
      - Rely on the `singleFile()` collection to remove the old media record and file via the configured media library file remover.
    - Call `$document->refreshMediaMetadata()` so the `documents` table is updated with the latest filename, path, mime, and size based on the new media record and `DocumentPathGenerator`.
  - Return `$document->fresh()` so any caller has the newest state.

### 4. Align Replace Behaviour with Initial Uploads
- Compare the behaviour of `replace()` with `DocumentStorageService::store()`:
  - Ensure both use the same MIME whitelist and max size configuration keys.
  - Confirm that both use the same `DocumentRenamer` and derive filenames in a similar way (course code + timestamp + original name).
  - Verify that both rely on `DocumentPathGenerator` to place files under the same per-offering/milestone/folder directory structure.
- Decide whether any additional metadata fixes from `store()` (e.g. forcing `filesize` or `mime` based on the original uploaded file when media library values are unreliable) should be mirrored in `replace()`; if so, add that logic right after `refreshMediaMetadata()`.

### 5. Refresh UI After Successful Replacement
- Keep or refine the existing notification in `FolderFileList`:
  - On success, show a success notification such as “Document replaced” with additional context (“The file was replaced successfully and metadata has been updated.”).
  - On validation or service errors, ensure Filament displays errors from `ValidationException` nicely in the modal.
- After a successful call to `DocumentOperationsService::replace()`:
  - Dispatch the `documents-updated` Livewire event with the current `folder_slug` so that parent components/widgets can react.
  - Call `$this->resetTable()` to force the Filament table to re-query `getTableQuery()` and show updated rows from the `documents` table.

### 6. Extend Service-Level Tests for Replace
- In `tests/Feature/Services/DocumentOperationsServiceTest.php`:
  - Enhance the existing “replaces a document file and updates metadata” test to also assert:
    - `updated->path_string` matches the expected path returned by `documentPath($setup, $updated)`.
    - `updated->original_filename` equals the new original name (e.g. `'Annotated Overview.pdf'`).
    - `updated->mime` matches the MIME of the replacement upload.
    - `updated->filesize` is non-zero and reflects the new file size.
  - Assert that:
    - The old file path no longer exists on the disk.
    - The new file path exists.
  - Add a negative test for replace validation, e.g.:
    - Attempt to replace with a file that exceeds `admin.max_upload_mb` or uses a disallowed MIME and assert that `ValidationException` is thrown and no file or metadata changes are made.

### 7. Extend UI-Level Tests for Replace
- In `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php`:
  - Verify the Livewire `FolderFileList` component converts serialized uploads:
    - Use a fake uploaded file and serialize it into a Livewire temporary upload key (as already done).
    - Mock `DocumentOperationsService::class` to expect `replace(Document $record, UploadedFile $file)` exactly once with a real `UploadedFile` instance.
    - Call the `replace` table action via `callTableAction('replace', $document, ['file' => ['livewire-file:'.$serializedFilename]])`.
    - Assert that the `documents-updated` event is dispatched and no type errors occur.
  - Optionally add a test that passes an empty `file` value and asserts:
    - `DocumentOperationsService::replace()` is not called.
    - Appropriate validation feedback is shown (or the modal closes without changes, depending on desired UX).

### 8. Manual Verification in the Lecturer Panel
- Using a local environment, log in as a lecturer with at least one assigned course offering and configured milestone with folders.
- Upload an initial document into a folder via the uploads dashboard.
- Use the **Replace** action to upload:
  - A different file with the same name.
  - A different file with a different name.
- After each replacement:
  - Confirm that the file visible in the UI corresponds to the new content.
  - Inspect the `documents` table row to confirm `stored_filename`, `original_filename`, `path_string`, `filesize`, and `mime` are updated.
  - Confirm that completeness indicators (✅/❌) continue to work as expected.

### 9. Validate and Clean Up
- Run targeted and full test suites:
  - `phpunit --filter DocumentOperationsServiceTest`
  - `phpunit --filter UploadsDashboardTest`
  - `phpunit` (or `php artisan test`) for the full suite if feasible.
- Review code to ensure:
  - No duplicated logic between `DocumentStorageService::store()` and `DocumentOperationsService::replace()` beyond what is necessary.
  - All new or modified methods have clear responsibilities and align with existing naming and architectural patterns.

## Testing Strategy
- **Unit/Feature Tests**
  - Extend `DocumentOperationsServiceTest` to fully assert behaviour of `replace()`:
    - Old file removed; new file stored under the expected folder path (using `FolderPathService`).
    - All relevant `documents` columns updated (filename, path, mime, size).
    - Validation errors when the file is too large or has a disallowed MIME.
  - Extend `UploadsDashboardTest` to verify Livewire/Filament integration:
    - Serialized file tokens are converted to `UploadedFile` instances.
    - `DocumentOperationsService::replace()` is invoked exactly once per successful action.
    - The `documents-updated` event is dispatched and the table reflects new metadata.
- **Manual Testing**
  - Smoke-test the lecturer uploads dashboard in a browser:
    - Verify replace works for multiple files and across different MIME types allowed by config.
    - Confirm error messages for invalid or oversized files are clear and mapped to the file field.
  - Optionally, inspect logs to ensure no unexpected exceptions occur during normal use.

## Acceptance Criteria
- The **Replace** action in `FolderFileList` always passes an `UploadedFile` (or subclass) to `DocumentOperationsService::replace()`; no type errors occur when replacing.
- After a successful replace:
  - The old media file for the `Document` no longer exists on disk.
  - The new media file exists at the expected path (based on `FolderPathService`/`DocumentPathGenerator`).
  - The corresponding `documents` row has updated `stored_filename`, `original_filename`, `path_string`, `filesize`, and `mime` values that match the new file.
- The lecturer uploads table refreshes after replacement, and the updated metadata is visible where relevant.
- Validation errors for disallowed MIME types or oversized files are correctly propagated to the UI and do not partially modify files or metadata.
- All relevant tests (`DocumentOperationsServiceTest`, `UploadsDashboardTest`, and the broader test suite) pass.

## Validation Commands
Execute these commands to validate the task is complete:

- `phpunit --filter DocumentOperationsServiceTest` - Run service-level tests for rename/move/replace/delete behaviour.
- `phpunit --filter UploadsDashboardTest` - Run lecturer uploads dashboard tests, including the replace action.
- `phpunit` - Run the full test suite for broader regression coverage.

## Notes
- No new libraries are required; the implementation should reuse:
  - Laravel’s `UploadedFile` and Spatie Media Library’s `TemporaryUploadedFile`.
  - Existing services: `DocumentOperationsService`, `DocumentStorageService`, `FolderPathService`, and `DocumentRenamer`.
- Ensure any changes remain backwards compatible with existing storage layout and path generation to avoid breaking previously uploaded documents.
- If changes to validation messages are needed, coordinate with any existing localization or UI copy conventions in the project.

