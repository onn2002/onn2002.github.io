# Feature: Database & Models (Domain Entities)

## Feature Description
Implement the core domain data model and Eloquent models to support programmes, academic sessions, courses, course offerings (with multi-lecturer assignment), folder templates by milestone, documents (as Medialibrary-owned binaries with first-class metadata), and reminder schedules. This enables enforced folder structures, server-side file renaming, per-lecturer completeness, admin reporting, and reminders as described in the PRD. The work adds migrations, enums, models, relationships, factories, and foundational validations with indexes for performance.

## User Story
As a system administrator
I want the application’s domain entities and relations defined in the database and Eloquent models
So that all higher-level features (uploads, completeness, reports, and reminders) are built on a robust, auditable schema.

## Problem Statement
The application lacks the concrete schema and Eloquent models for core domain concepts (Programme, AcademicSession, Course, CourseOffering, FolderTemplate, Document, ReminderSchedule). Without these, Filament resources, upload workflows, completeness calculations, auditing, and reminders cannot be implemented or tested.

## Solution Statement
Design and implement a normalized, indexed schema and corresponding Eloquent models that mirror the PRD’s entities and relationships. Use a native PHP enum for milestones, enforce uniqueness where appropriate (e.g., folder template scoping + slug), and integrate Spatie packages: Permission for roles, Medialibrary for file storage (with Document as the owning model), and Activitylog for audit trails. Provide factories and basic seeders to support tests and early UI scaffolding. Favor computed accessors instead of redundant stored fields (e.g., compute course_identifier from relations) while exposing first-class columns for file metadata on Document to satisfy reporting requirements.

## Relevant Files
Use these files to implement the feature:

- `composer.json` – Confirms dependencies (Laravel 12, Filament v4, Spatie packages) and provides existing Composer scripts.
- `config/app.php` – Timezone already set to Asia/Kuala_Lumpur; ensure model timestamps and scheduling align.
- `config/permission.php` – Spatie Permission configuration; roles/permissions seeding will rely on this.
- `config/media-library.php` – Medialibrary configuration; Document will implement InteractsWithMedia.
- `config/activitylog.php` – Activity log configuration; enable morph mapping and model logging.
- `database/migrations/0001_01_01_000000_create_users_table.php` – Users table is present; will be referenced by pivots/foreign keys.
- `database/migrations/2025_10_23_161958_create_permission_tables.php` – Spatie Permission tables; roles/permissions seeds will target these.
- `database/migrations/2025_10_23_162220_create_media_table.php` – Medialibrary media table; Document will own a single media item.
- `database/migrations/2025_10_23_162240_create_activity_log_table.php` (+ patches) – Activity log tables; audits for CRUD/file ops will persist here.
- `app/Models/User.php` – Add `HasRoles` and (optionally) `MustVerifyEmail` to satisfy PRD; link to offerings via pivot.
- `tests/*` – Add unit/integration tests around migrations, relations, accessors, factories, and Document + media integration.

### New Files
- `app/Enums/Milestone.php` – Backed enum: `BeginningOfSemester`, `MidTermExamination`, `FinalExamPackage`, `EndOfSemester`.
- `database/migrations/20xx_xx_xx_xxxxxx_create_programmes_table.php` – Programmes catalog.
- `database/migrations/20xx_xx_xx_xxxxxx_create_academic_sessions_table.php` – Academic sessions catalog.
- `database/migrations/20xx_xx_xx_xxxxxx_create_courses_table.php` – Courses catalog with `title_slug`.
- `database/migrations/20xx_xx_xx_xxxxxx_create_course_offerings_table.php` – Offering tying programme, session, course.
- `database/migrations/20xx_xx_xx_xxxxxx_create_course_offering_user_table.php` – Pivot for lecturers assigned to offerings.
- `database/migrations/20xx_xx_xx_xxxxxx_create_folder_templates_table.php` – Folder templates by milestone + optional scopes.
- `database/migrations/20xx_xx_xx_xxxxxx_create_documents_table.php` – Document metadata + FKs; one media per document via Medialibrary.
- `database/migrations/20xx_xx_xx_xxxxxx_create_reminder_schedules_table.php` – Admin-defined reminders.
- `app/Models/Programme.php`
- `app/Models/AcademicSession.php`
- `app/Models/Course.php`
- `app/Models/CourseOffering.php`
- `app/Models/FolderTemplate.php`
- `app/Models/Document.php` (implements `Spatie\MediaLibrary\HasMedia` and uses `InteractsWithMedia`)
- `app/Models/ReminderSchedule.php`
- `database/factories/*Factory.php` – Factories for all new models.
- `database/seeders/RolesAndPermissionsSeeder.php` – Seeds roles `admin`, `lecturer` and base permissions.

## Implementation Plan
### Phase 1: Foundation
- Create `Milestone` PHP enum and ensure it’s autoloaded.
- Write migrations for catalog entities (Programme, AcademicSession, Course) with necessary indexes and constraints.
- Add migrations for CourseOffering + pivot (course_offering_user), FolderTemplate, Document, ReminderSchedule.
- Ensure all FK relationships use `cascadeOnDelete` where safe (e.g., deleting an offering cascades documents), and `restrictOnDelete` where needed.
- Add unique constraints: `courses.course_code`, `folder_templates` composite unique on scope+slug+milestone; pivot unique on `(course_offering_id, user_id)`.
- Add hot-path indexes (e.g., `documents(offering_id, milestone, folder_slug, uploader_id)`).

### Phase 2: Core Implementation
- Implement Eloquent models with relationships, casts, and guarded/fillable fields.
- `Course` generates `title_slug` (mutator on set/save) and index it for searches.
- `CourseOffering` accessor `course_identifier` = `{course.course_code}_{course.title_slug}`; add helper accessors for `programme_code`, `session_code`.
- `Document` implements Medialibrary’s `InteractsWithMedia`; enforce single media item in collection `document`. Store first-class metadata columns on create/update; keep media’s own fields for binary handling.
- Add Activitylog traits/config to log CRUD changes for core models; set appropriate `logName` and `getActivitylogOptions` as needed.
- Update `User` to use `Spatie\Permission\Traits\HasRoles` and define `offerings()` relation via pivot; keep `MustVerifyEmail` as a follow-up if out-of-scope for this step.

### Phase 3: Integration
- Add model factories for all entities to support tests and seeders.
- Add `RolesAndPermissionsSeeder` for `admin` and `lecturer`, plus granular permissions from PRD; wire into `DatabaseSeeder`.
- Provide minimal seed data: one programme, session, course, offering; two lecturers and one admin; a couple of folder templates per milestone to support manual smoke tests and upcoming Filament resources.
- Validate migrations on fresh DB and run initial test suite (Pest).

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### Step 1 — Create Milestone enum
- Add `app/Enums/Milestone.php` with string-backed cases: `BeginningOfSemester`, `MidTermExamination`, `FinalExamPackage`, `EndOfSemester`.
- Provide helpers: `label()` for human label; `values()` for validation rules.
- Plan to cast `milestone` columns via `->casts = ['milestone' => Milestone::class]` on models.

### Step 2 — Programme, AcademicSession, Course migrations
- Create migrations with columns and indexes:
  - programmes: `code` (unique), `name`, `active` (bool, default true).
  - academic_sessions: `code` (unique), `starts_at`, `ends_at`.
  - courses: `course_code` (unique), `title`, `title_slug` (indexed).
- Add corresponding models with `HasFactory` and basic validation rules (to be used by Filament later).

### Step 3 — CourseOffering and pivot migrations
- Create `course_offerings` with FKs: `programme_id`, `session_id`, `course_id` (indexed), timestamps.
- Create pivot `course_offering_user` with FKs: `course_offering_id`, `user_id`; unique composite; timestamps optional.
- Model: `CourseOffering` with relations: `programme()`, `session()`, `course()`, `lecturers()` (belongsToMany `User`).
- Add accessor `course_identifier` and helper accessors `programme_code`, `session_code`.

### Step 4 — FolderTemplate migration and model
- Create `folder_templates` with: `slug` (ASCII safe), `label`, `milestone` (string backed by enum), nullable `programme_id`, nullable `course_id`.
- Add composite unique: `(milestone, slug, programme_id, course_id)` ensuring only one template per scope/slug/milestone.
- Model: `FolderTemplate` with casts for `milestone` and relations to Programme/Course.

### Step 5 — Document migration and model with Medialibrary
- Create `documents` with: `offering_id` (FK), `milestone` (enum), `folder_slug`, `uploader_id` (FK to users), `stored_filename`, `original_filename`, `path_string`, `filesize` (bigint), `mime`, timestamps.
- Add index: `(offering_id, milestone, folder_slug, uploader_id)`; and individual indexes on frequently filtered columns.
- Model: `Document` implements `Spatie\MediaLibrary\HasMedia` and uses `InteractsWithMedia`.
- Register a single collection `document`; ensure only one file per Document (document-per-file design).
- Hook into model events or media callbacks to populate column metadata (`stored_filename`, `original_filename`, `filesize`, `mime`, and `path_string` from future path service).

### Step 6 — ReminderSchedule migration and model
- Create `reminder_schedules` with nullable scope: `programme_id`, `session_id`, nullable `milestone` (enum), `send_at` (datetime in MYT), `channels` (json), `active` (bool), `sent_at` (nullable datetime).
- Model: `ReminderSchedule` with casts for `milestone` and `channels` (array), scopes to filter active, due, and by scope.

### Step 7 — Update User model for roles and relations
- In `app/Models/User.php`, add `use Spatie\Permission\Traits\HasRoles;` and trait usage.
- Add relation `offerings()` → belongsToMany via pivot `course_offering_user`.
- Optionally implement `Illuminate\Contracts\Auth\MustVerifyEmail` per PRD (email verification).

### Step 8 — Activity logging on core models
- Add `Spatie\Activitylog\Traits\LogsActivity` to key models (Programme, AcademicSession, Course, CourseOffering, FolderTemplate, Document, ReminderSchedule).
- Implement `getActivitylogOptions()` to log fillable/dirty attributes. Set `logName` appropriately (e.g., `documents`).
- Ensure morph map is configured if needed for cleaner subjects in logs.

### Step 9 — Factories and seeders
- Create factories for all models with sensible defaults.
- Seeder `RolesAndPermissionsSeeder`: create roles `admin`, `lecturer` and base permissions from PRD.
- Update `DatabaseSeeder` to call `RolesAndPermissionsSeeder` and seed a demo programme/session/course/offering, two lecturers, one admin, and a few folder templates.

### Step 10 — Tests (Pest) for schema, relations, and behaviors
- Unit tests for migrations/constraints using SQLite or MySQL test DB; assert unique and foreign key behaviors.
- Relation tests: course-offering-lecturers pivot, document belongsTo offering/uploader, folder template scoping.
- Behavior tests: `Course` slug generation, `CourseOffering` `course_identifier` accessor.
- Medialibrary integration: ensure a `Document` can accept one media item, and metadata columns match the stored media file.
- ReminderSchedule scopes: active and due filtering based on MYT.

### Step 11 — Validation & formatting
- Run lint, static analysis, and full test suite.
- Verify migrations on a fresh DB and inspect table/index presence.

## Testing Strategy
### Unit Tests
- Model relations: belongsTo, hasMany, belongsToMany (pivot uniqueness), and cascades.
- Attribute behavior: `Course` slug generation; `CourseOffering` computed `course_identifier`.
- Enum casts: Milestone stored/retrieved correctly across models.
- Document metadata synchronization with Medialibrary after upload.
- ReminderSchedule scope methods (`active`, `due`, `scopedTo(...)`).

### Integration Tests
- Migration/Schema: Apply fresh migrations and assert tables, columns, indexes, and constraints exist.
- Medialibrary flow: attach a fake file to `Document`, confirm `media` row exists and metadata columns match; deleting `Document` deletes its media.
- Seeders: roles exist; demo catalog and relations link correctly; a lecturer assigned to an offering is returned by `User->offerings`.

### Edge Cases
- Duplicate folder template slug in different scopes (allowed) vs same scope (rejected by unique constraint).
- Multiple lecturers on one offering; per-lecturer document rows do not block others.
- Deleting an offering cascades documents and media; foreign key restrict prevents orphaned rows where intended.
- Large filenames and unusual MIME types within whitelist handled and stored correctly.
- Timezone alignment: `send_at` interpreted as MYT; ensure `due` scope doesn’t drift around DST (MYT has no DST, but assert behavior).

## Acceptance Criteria
- All migrations run cleanly on a fresh database; tables, indexes, and constraints match the PRD entities.
- Eloquent models exist with relationships, casts, accessors, and factories.
- `Course` auto-generates `title_slug`; `CourseOffering` exposes `course_identifier` as specified.
- `Document` owns exactly one media item and persists first-class file metadata consistent with stored media.
- FolderTemplate uniqueness is enforced within its scope and per milestone.
- Pivot `course_offering_user` enforces unique `(offering, user)` with working relations from both sides.
- `User` uses `HasRoles` and can relate to `CourseOffering` via pivot.
- Activity logging captures CRUD for core models.
- Tests pass and demonstrate schema integrity, relations, and key behaviors.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `composer dump-autoload`
- `php artisan migrate:fresh --seed`
- `php artisan test` - Run tests to validate the feature works with zero regressions
- `vendor/bin/pint -v --test`
- `vendor/bin/phpstan analyse --memory-limit=1G`
- Manual smoke: `php artisan tinker` to create sample records and verify relations (optional)

## Notes
- No new Composer packages are required; Spatie Permission, Medialibrary, and Activitylog are already installed and configured.
- Medialibrary path generation for the enforced folder structure will be handled by an upload/path service in a subsequent feature; `documents.path_string` column is prepared for display/reporting.
- Store `send_at` and timestamps in MYT (app timezone set); use Carbon defaults and scheduler `->timezone('Asia/Kuala_Lumpur')` in reminder jobs later.
- Prefer computed accessors over redundant stored columns unless explicitly required for reporting/performance (we expose first-class Document metadata per PRD).
- Ensure policies and Filament resources are implemented in subsequent features, leveraging these models and relations.

