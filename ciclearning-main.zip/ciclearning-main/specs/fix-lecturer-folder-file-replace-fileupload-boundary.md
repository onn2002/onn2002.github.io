# Plan: Fix Lecturer Folder Replace Action FileUpload Boundary

## Task Description
The lecturer uploads dashboard exposes a **Replace** action in `FolderFileList` that should swap out the stored file for a `Document` record and ensure the `documents` table reflects the new file (including `stored_filename`, `original_filename`, `path_string`, `filesize`, and `mime`).  

Currently, when a user opens the **Replace document** modal and submits **Upload replacement**, nothing appears to happen: the existing file remains unchanged and table metadata does not update. The most likely root cause is a mismatch between how Filament’s `FileUpload` component stores its state and what `FolderFileList` expects. Filament 4, backed by Livewire 3, stores uploads to disk by default and dehydrates the field state to **stored paths**, while `FolderFileList`’s `normalizeUploadedFile()` helper assumes it will receive a Livewire `TemporaryUploadedFile` (or a serialized `livewire-file:` token), not an already-stored path string. As a result, the helper returns `null`, the action exits early, and `DocumentOperationsService::replace()` is never called.

This plan describes how to fix that boundary so the replace action reliably invokes the domain service with a valid `UploadedFile` and the UI refreshes to show the updated document metadata.

## Objective
When a lecturer uses the **Replace** table action to upload a new file:
- The Filament `FileUpload` field yields a usable `UploadedFile`/`TemporaryUploadedFile` instance to the Livewire component.
- `FolderFileList` successfully calls `DocumentOperationsService::replace($record, $file)` with a non-null file.
- The media file on disk is replaced (old file removed) and the new one stored under the correct folder path.
- The `documents` row for that record is updated so the table shows the new filename, path, mime type, and size.
- The `FolderFileList` table refreshes automatically, and any listening components (e.g. `FolderTileGrid`) see updated completeness status.

Task type: **fix**  
Complexity: **medium**

## Problem Statement
The current replace flow in `FolderFileList` fails silently from the user’s perspective:

- The table action `replace` defines a Filament `FileUpload` field:
  - `app/Livewire/Lecturer/FolderFileList.php:~96-138`
  - The field is configured with `->required()`, `->maxSize($this->maxUploadKilobytes())`, and `->acceptedFileTypes(...)` but **does not** change the default `storeFiles(true)` behavior.
- Filament’s `BaseFileUpload` stores temporary uploads to the configured filesystem disk during dehydration and replaces `TemporaryUploadedFile` objects in its internal `rawState` with **path strings** (e.g. `course-materials/CS101/.../file.pdf`).
  - See `vendor/filament/forms/src/Components/BaseFileUpload.php` (especially `saveUploadedFiles()` and its use of `TemporaryUploadedFile`).
  - State casting is handled by `Filament\Schemas\Components\StateCasts\FileUploadStateCast`, which dehydrates to arrays of file keys/paths and, for non-multiple fields, returns the first value.
- In `FolderFileList`, the `replace` action’s `->action()` closure calls:

  ```php
  $file = $this->normalizeUploadedFile($data['file'] ?? null);

  if (! $file) {
      return;
  }
  ```

  - `normalizeUploadedFile()` currently assumes:
    - `mixed $value` may be an array of values, a single serialized Livewire token (`livewire-file:` or `livewire-files:`), or an `UploadedFile` instance.
    - It only converts strings that `TemporaryUploadedFile::canUnserialize()` recognizes (i.e. prefixed tokens), then returns the result if it is an `UploadedFile`.
    - **Plain path strings** returned by Filament after storing the upload do not match this pattern, so the helper returns `null`.
- Because `$file` is `null`, the `replace` action short-circuits and never reaches:

  ```php
  app(DocumentOperationsService::class)->replace($record, $file);
  ```

  No exception is thrown, and UI notifications for success are never shown, giving the appearance that the action “does nothing”.

Domain-side, `DocumentOperationsService::replace()` is already tested and behaves correctly when called with a proper `UploadedFile`:
- `tests/Feature/Services/DocumentOperationsServiceTest.php` includes `it('replaces a document file and updates metadata', ...)`, asserting:
  - The old path is missing on the media disk.
  - The new path exists.
  - `stored_filename` changes and metadata refreshes.

Therefore, the primary defect lies at the **FileUpload → Livewire → service boundary** inside `FolderFileList`, not in `DocumentOperationsService` itself.

## Solution Approach
The solution focuses on making the `replace` action’s FileUpload integration compatible with the existing service layer while keeping behavior consistent with the **initial upload** flow in `UploadModal`.

1. **Stop Filament from pre-storing the replacement file, and pass the temporary upload directly**  
   - Update the `FileUpload` field in `FolderFileList::getTableActions()` to opt out of automatic file storage by calling `->storeFiles(false)`.  
   - With `storeFiles(false)`, `saveUploadedFiles()` in `BaseFileUpload` returns early, leaving the component’s `rawState` as `TemporaryUploadedFile` instances or Livewire serialization tokens, which `normalizeUploadedFile()` already knows how to handle.
   - This keeps the storage responsibility in the domain layer (`DocumentOperationsService::replace()` + Spatie Media Library), avoids extra files on a separate Filament disk, and mirrors how `UploadModal` passes `WithFileUploads`-managed files into `DocumentStorageService::store()`.

2. **Ensure `normalizeUploadedFile()` robustly handles Livewire 3 upload representations**  
   - Confirm that `normalizeUploadedFile()` covers:
     - Single `TemporaryUploadedFile` instances (which extend `Illuminate\Http\UploadedFile`).
     - Arrays of `TemporaryUploadedFile` or string tokens (as returned by `FileUploadStateCast` when `multiple()` is enabled in other contexts).
     - Serialized `livewire-file:` / `livewire-files:` strings used by Livewire 3.
   - If necessary, add a small type guard so that if `$value` is a `TemporaryUploadedFile` instance it is returned immediately (since it already extends `UploadedFile`), prior to string deserialization.

3. **Leverage existing domain logic for the actual replacement**  
   - Continue to call `DocumentOperationsService::replace($record, $file)` unchanged.
   - Rely on:
     - `DocumentOperationsService::validateFile()` to enforce MIME whitelist and size limits based on `config('admin.*')`.
     - `FolderPathService::buildPathFromSlug()` + `DocumentRenamer` to compute the target directory and collision-safe filename.
     - Spatie Media Library’s `singleFile()` collection configuration in `Document::registerMediaCollections()` to delete the previous media record and underlying stored file when adding the new one.
     - `Document::refreshMediaMetadata()` / `syncMediaMetadata()` to write updated path and metadata into the `documents` table.

4. **Refresh UI state and notifications**  
   - Keep the existing success notification and event dispatch:
     - `Notification::make()->title('Document replaced')->success()->body('The file was replaced successfully and metadata has been updated.')`.
     - `$this->dispatch('documents-updated', slug: $record->folder_slug);`
     - `$this->resetTable();`
   - Verify that `FolderTileGrid` and `FolderFileList` both respond correctly to the `documents-updated` event, ensuring the status grid and file list reflect the new document.

5. **Add targeted tests around the Livewire/Filament boundary**  
   - Implement a Livewire/Filament feature test that:
     - Creates a stored `Document` using `DocumentStorageService::store()` (reusing helpers from `DocumentOperationsServiceTest`).
     - Mounts `FolderFileList` with the correct `offeringId`, `milestone`, `userId`, and opens the relevant folder.
     - Uses Filament tables testing helpers (e.g. `callTableAction('replace', $document, ['file' => UploadedFile::fake()...])`) to simulate the replace action submission.
     - Asserts that:
       - `DocumentOperationsService::replace()` was effectively invoked (via storage / metadata side effects).
       - The document’s `stored_filename`, `path_string`, and `mime` changed.
       - Old media file is missing and new file exists on the media disk.
       - The table reloads and shows the updated path/filename.

Overall, this approach fixes the **input boundary** while preserving the already well-tested service behavior and keeping storage semantics consistent across uploads and replacements.

## Relevant Files
Use these files to complete the task:

- `app/Livewire/Lecturer/FolderFileList.php`
  - Defines the lecturer-facing Filament table and the `replace` and `delete` row actions.
  - Contains the `FileUpload` configuration for the replacement file and the `normalizeUploadedFile()` helper.
- `app/Services/DocumentOperationsService.php`
  - Implements `replace()`, `rename()`, `move()`, and `delete()` for `Document` media, including metadata refresh.
  - Already validated by `tests/Feature/Services/DocumentOperationsServiceTest.php`.
- `app/Models/Document.php`
  - Configures the Spatie media collection (`Document::MEDIA_COLLECTION`) as `singleFile()`.
  - Implements `refreshMediaMetadata()` and event hooks for cache invalidation.
- `app/Livewire/Lecturer/UploadModal.php`
  - Provides a working reference for the initial upload flow (`WithFileUploads` + `DocumentStorageService::store()`).
- `app/Services/DocumentStorageService.php`
  - Handles first-time document storage, filename generation, and metadata initialization.
- `resources/views/livewire/lecturer/folder-file-list.blade.php`
  - Renders the Filament table and actions modals (`<x-filament-actions::modals />`).
- `resources/views/livewire/lecturer/upload-modal.blade.php`
  - UI reference for how uploads are explained to users (naming conventions, size/mime constraints).
- `tests/Feature/Services/DocumentOperationsServiceTest.php`
  - Provides helpers (`setupDocumentEnvironment`, `createStoredDocument`, `documentPath`) and service-level expectations for rename/move/replace/delete.
- `tests/Feature/DocumentMediaTest.php` and related media tests
  - Validate media path consistency and metadata, useful for regression coverage.

### New Files
- `tests/Feature/Lecturer/FolderFileListReplaceActionTest.php`
  - New feature test (Pest) covering the end-to-end behavior of the `replace` table action, ensuring the UI → Livewire → service pipeline works as expected.

## Implementation Phases

### Phase 1: Foundation
- Verify the current runtime shape of `$data['file']` inside the `replace` action by temporarily dumping or logging the value in a dev environment to confirm it is a stored path string under the Filament disk.
- Review Filament 4 file upload behavior:
  - Confirm `storeFiles()` default is `true`, and that `saveUploadedFiles()` uses `TemporaryUploadedFile` to write files to disk and replace them with path strings.
  - Confirm `FileUploadStateCast` behavior for single vs multiple files.
- Confirm that `DocumentOperationsService::replace()` already:
  - Deletes the old media file via the `singleFile()` collection.
  - Refreshes document metadata (`stored_filename`, `path_string`, etc.).
  - Passes all existing tests in `DocumentOperationsServiceTest`.

### Phase 2: Core Implementation
- Update `FolderFileList::getTableActions()`:
  - Modify the `FileUpload::make('file')` configuration to explicitly disable automatic storage:

    ```php
    $upload = FileUpload::make('file')
        ->label('Replacement file')
        ->required()
        ->maxSize($this->maxUploadKilobytes())
        ->storeFiles(false);
    ```

  - Keep the `acceptedFileTypes()` configuration based on `allowedMimeTypes()` so client-side validation matches server-side expectations.
- Harden `normalizeUploadedFile()`:
  - Ensure the helper gracefully handles:
    - Arrays by taking the first non-empty entry.
    - `TemporaryUploadedFile` instances (which are `UploadedFile` subclasses) by returning them directly.
    - Serialized `livewire-file:` strings using `TemporaryUploadedFile::unserializeFromLivewireRequest()`.
  - Confirm that for non-null inputs coming from the updated `FileUpload` field, the helper always returns an `UploadedFile` instance.
- Keep the `replace` action’s core flow intact:
  - Only proceed when `$file` is non-null.
  - Call `DocumentOperationsService::replace($record, $file)` without further transformation.
  - After success, dispatch `documents-updated`, reset the table, and show existing success notification.

### Phase 3: Integration & Polish
- Implement `tests/Feature/Lecturer/FolderFileListReplaceActionTest.php`:
  - Reuse `setupDocumentEnvironment()` and `createStoredDocument()` helpers where possible.
  - Use `Livewire::test(FolderFileList::class)` (and Filament tables test helpers) to:
    - Mount the component with appropriate `offeringId`, `milestone`, and `userId`.
    - Ensure the relevant folder is selected (e.g. via `openFolder` or dispatching the `open-files` event).
    - Invoke the `replace` table action with a fake `UploadedFile` representing the replacement.
    - Assert that:
      - The old document path is missing on the media disk.
      - The new path exists and `stored_filename`, `path_string`, and `mime` changed.
      - The component’s table data reflects the new metadata (e.g. by checking rendered values or table records).
- Optionally add a negative-path test:
  - Simulate submitting the replace form without a file (or with an invalid mime type) and assert:
    - Appropriate validation errors are returned.
    - `DocumentOperationsService::replace()` is not invoked.
    - No changes occur to the document record.
- Manually test the lecturer UI:
  - Upload a new document via `UploadModal`.
  - Use the `Replace` action to upload a different file.
  - Confirm:
    - The displayed path and filename change.
    - Download/open actions show the new file.
    - The folder status grid updates (if completeness rules depend on this document).

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1. Confirm Current FileUpload Behavior
- Add temporary debugging (e.g. logging the type and value of `$data['file']`) in the `replace` action to verify it is currently a path string after form submission.
- Remove debugging after confirming the shape to keep the component clean.

### 2. Disable Automatic File Storage in FileUpload
- In `app/Livewire/Lecturer/FolderFileList.php`, update the `FileUpload::make('file')` configuration for the `replace` action to call `->storeFiles(false)`.
- Ensure other existing configuration (`->required()`, `->maxSize()`, `->acceptedFileTypes()`) remains intact so UX and validation behavior do not regress.

### 3. Harden normalizeUploadedFile() for Livewire 3
- In `FolderFileList::normalizeUploadedFile()`:
  - Ensure arrays are reduced to a single value using the existing `Arr::first()` logic.
  - If the value is a `TemporaryUploadedFile` (or any `UploadedFile` subclass), return it directly.
  - If the value is a serialized string recognized by `TemporaryUploadedFile::canUnserialize()`, convert it using `TemporaryUploadedFile::unserializeFromLivewireRequest()` and return the resulting `UploadedFile`.
- Confirm that for the new `FileUpload` configuration, submitting the replace form yields a non-null `UploadedFile` for valid files.

### 4. Verify Service-Level Replace Behavior
- Run the existing `DocumentOperationsServiceTest` to ensure `replace()` still:
  - Deletes the previous stored file.
  - Stores the new file under the expected path.
  - Refreshes document metadata (`stored_filename`, `original_filename`, `path_string`, `filesize`, `mime`).
- If any expectations change due to minor refactors, update tests to reflect the new, correct behavior while preserving guarantees about metadata consistency.

### 5. Add Livewire/Filament Feature Test for Replace Action
- Create `tests/Feature/Lecturer/FolderFileListReplaceActionTest.php`.
- Write a test that:
  - Sets up a real `Document` using `DocumentStorageService::store()` with a fake upload.
  - Mounts `FolderFileList` with proper `offeringId`, `milestone`, and `userId` values matching the document.
  - Ensures the folder slug is selected (via method call or event).
  - Calls the `replace` table action with a fake `UploadedFile` as the replacement file using Filament’s table testing helpers.
  - Asserts that:
    - The old file path no longer exists on the media disk.
    - The new file exists and metadata fields on the `Document` model changed accordingly.
    - The component’s table data reflects the new file.

### 6. Manual UI Regression Check
- In a local environment, navigate to the lecturer uploads UI.
- Upload an initial document to a folder, then use the **Replace** action to upload a different file.
- Confirm:
  - Success notifications appear.
  - The table shows the updated filename/path and uploader information.
  - The folder status grid (if visible) updates as expected.

### 7. Final Test Run and Cleanup
- Run the full test suite (or at least all feature tests related to documents and services) to ensure no regressions.
- Remove any leftover debugging, ensure type hints and imports align with the updated code, and re-run static analysis or linters if configured.

## Testing Strategy
- **Service-level tests**
  - Re-run `tests/Feature/Services/DocumentOperationsServiceTest.php` to confirm `replace()` continues to pass all existing scenarios (rename, move, replace, delete) after the UI boundary changes.
- **New Livewire/Filament feature test**
  - Implement `tests/Feature/Lecturer/FolderFileListReplaceActionTest.php` as described, focusing on:
    - Ensuring the `replace` action actually triggers a media replacement.
    - Verifying the table’s rendered data and the underlying document record both reflect the new file.
- **Validation and edge cases**
  - Add a test case to assert that missing or invalid uploads (e.g. wrong mime, too large) produce validation errors and do not modify the document.
- **Manual integration testing**
  - Perform end-to-end checks via the actual lecturer UI in a dev environment, focusing on:
    - Consecutive replacements on the same document.
    - Replacing with files of different sizes and mime types.
    - Behavior when `admin.mime_whitelist` and `admin.max_upload_mb` are set to restrictive values.

## Acceptance Criteria
- Submitting the **Replace document** modal with a valid file:
  - Calls `DocumentOperationsService::replace()` with a non-null `UploadedFile`.
  - Replaces the underlying media file and removes the old file from the media disk.
  - Updates the `documents` table so `stored_filename`, `original_filename`, `path_string`, `filesize`, and `mime` reflect the new file.
  - Triggers the existing success notification and refreshes the `FolderFileList` table, showing updated metadata.
- Submitting with an invalid file (disallowed mime or too large):
  - Shows a validation error and does **not** modify the underlying document or stored media.
- The new feature test `FolderFileListReplaceActionTest` passes and fails appropriately if the boundary between FileUpload and `DocumentOperationsService` breaks again.
- All existing document/service/media-related tests continue to pass.

## Validation Commands
Execute these commands to validate the task is complete:

- `composer pest -- tests/Feature/Services/DocumentOperationsServiceTest.php`  
  Run service-level tests for document operations, including replace behavior.
- `composer pest -- tests/Feature/Lecturer/FolderFileListReplaceActionTest.php`  
  Run the new feature test covering the `replace` table action end-to-end.
- `composer pest`  
  Run the full Pest test suite to ensure no regressions across the application.
- `composer stan`  
  Optional: Run PHPStan static analysis to catch any type or import issues introduced by the changes.

## Notes
- No new libraries are required; the fix relies on existing Livewire 3, Filament 4, and Spatie Media Library capabilities.
- Be mindful of configuration:
  - `config('media-library.disk_name')` controls where document media is stored.
  - `config('filament.default_filesystem_disk')` controls the default storage disk for Filament uploads; disabling `storeFiles()` in the `FileUpload` removes direct dependence on this disk for the replace flow.
  - `config('admin.mime_whitelist')` and `config('admin.max_upload_mb')` must remain in sync with UI messaging and validation rules.
- If other `FileUpload` fields are later added for similar workflows, consider centralizing Livewire/Filament upload normalization into a shared utility or trait to avoid duplicating boundary logic.

