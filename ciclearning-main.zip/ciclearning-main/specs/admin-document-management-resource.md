# Plan: Admin Document Management Resource

## Task Description
Implement a new Filament Admin resource that allows administrators to browse and manage all uploaded `Document` records. The resource will present a table-driven view with rich filters (lecturer/uploader, programme, academic session, course, milestone, and related attributes) and record-level actions to replace and delete documents, leveraging existing storage and operations services. The UI must be optimized for auditability, performance, and safety so that admins can quickly locate documents across offerings and correct issues without bypassing existing domain rules.

Task type: feature
Complexity: medium

## Objective
Provide an Admin-only Documents management screen under the existing Filament Admin panel where admins can:
- Search and filter documents by lecturer (uploader), programme, academic session, course, course offering, milestone, and folder.
- Inspect key metadata (stored filename, original filename, path, uploader, size, mime type, timestamps).
- Safely replace the underlying file using the existing `DocumentOperationsService::replace()` flow.
- Safely delete documents (soft delete + media cleanup) using `DocumentOperationsService::delete()`.

## Problem Statement
Currently, documents are primarily managed from the Lecturer panel (Uploads Dashboard + Folder file list). Admins have no dedicated global view to:
- See all documents across programmes/sessions/courses and lecturers.
- Filter and audit documents when investigating issues (e.g. wrong upload in a course, incorrect milestone, incorrect file type).
- Perform corrective operations (replace/delete) without directly impersonating lecturers or manipulating storage by hand.

This gap makes support and QA slow and error-prone, especially once the system is populated with many documents across multiple intakes. A central Admin-facing Documents management resource is needed to improve visibility and provide controlled corrective actions while still relying on the existing storage/operations domain services.

## Solution Approach
Add a new `DocumentResource` under `App\Filament\Admin\Resources` that is list-only (no create/edit pages) and backed by the `App\Models\Document` model. The resource will:
- Use a dedicated `DocumentsTable` configurator to define columns, filters, and actions, following existing patterns (`CoursesTable`, `CourseOfferingsTable`, `ActivitiesTable`).
- Eager-load related entities (`offering.programme`, `offering.session`, `offering.course`, `uploader`) for efficient filtering and display.
- Introduce filters for uploader (lecturer), programme, academic session, course, course offering, and milestone, using `SelectFilter` and relationship-aware options.
- Add record actions for “Replace” and “Delete” that delegate to `DocumentOperationsService` to enforce path rules, renaming, soft deletion, media cleanup, and validation.
- Restrict navigation and access to authenticated admins by reusing the existing `DocumentPolicy` (which already grants admins full access via `before()`) and the standard `shouldRegisterNavigation()` pattern.

The implementation will reuse existing code and services from the Lecturer uploads feature where possible to avoid duplication (e.g. MIME and size limits from `config('admin')`, `DocumentOperationsService` for mutating operations) and will add minimal glue code for Filament actions and filters.

## Relevant Files
Use these files to complete the task:

- `app/Models/Document.php` – Core document model; defines fillable attributes, milestone cast, relationships to `CourseOffering` (`offering`) and `User` (`uploader`), and media metadata sync. The Admin resource will be based on this model and its relationships.
- `app/Models/CourseOffering.php` – Provides links to `Programme`, `AcademicSession`, and `Course`, plus the `documents()` relation and derived attributes (`programmeCode`, `sessionCode`, `courseIdentifier`). Used for programme/session/course filters and display.
- `app/Enums/Milestone.php` – Enum for document milestones with human-readable labels; used to populate milestone filter options and to render milestone labels in the table.
- `app/Services/DocumentOperationsService.php` – Domain service providing `rename`, `move`, `replace`, and `delete` operations for documents, including validation, storage operations, and metadata refresh. The Admin actions will call `replace()` and `delete()` instead of touching storage directly.
- `app/Services/DocumentStorageService.php` – Used by uploads to create `Document` records and attach media; useful reference for path and naming conventions, but not directly called by the Admin resource.
- `app/Services/FolderPathService.php` – Computes storage paths for documents based on offering, milestone, and folder slug; used indirectly by `DocumentOperationsService`.
- `app/Filament/Admin/Resources/CourseOfferings/CourseOfferingResource.php` and `app/Filament/Admin/Resources/CourseOfferings/Tables/CourseOfferingsTable.php` – Patterns for table configuration, relationship-based filters (programme/session/course), and navigation grouping within the Admin panel.
- `app/Filament/Admin/Resources/Activities/ActivityResource.php` and `app/Filament/Admin/Resources/Activities/Tables/ActivitiesTable.php` – Example of a list-only Admin resource (no create/edit), including date range filtering and custom filters; useful for designing the Documents list-only behavior.
- `app/Filament/Lecturer/Pages/UploadsDashboard.php` – Lecturer-facing uploads UX; shows how programme/session/offering/milestone filters are built and which combinations are valid. Provides conceptual parity for Admin filters.
- `app/Livewire/Lecturer/FolderFileList.php` – Livewire component using Filament Tables to list documents for a specific folder and milestone, including actions (`rename`, `replace`, `move`, `delete`) that call `DocumentOperationsService`. This is the primary reference for implementing Admin replace/delete actions.
- `app/Policies/DocumentPolicy.php` – Authorization logic for documents. `before()` grants all abilities to admins, while lecturers are constrained to their own documents. The Admin resource will rely on this policy for gating.
- `app/Providers/AuthServiceProvider.php` – Registers `DocumentPolicy` with the `Document` model; ensures Gate checks used by Filament are wired correctly.
- `app/Providers/Filament/AdminPanelProvider.php` – Configures the Admin panel and sets up resource discovery under `app/Filament/Admin/Resources`; the new `DocumentResource` will be automatically discovered here.
- `config/admin.php` – Defines MIME whitelist and maximum upload size; the Admin replace action should honour these constraints using `FileUpload` configuration consistent with Lecturer flows.
- `tests/Feature/Services/DocumentOperationsServiceTest.php` – Existing coverage for `DocumentOperationsService` behaviors; confirms we can safely rely on the service from Filament actions.
- `tests/Feature/Filament/Admin/AuthorizationTest.php` – Verifies authorization for Admin resources and pages; can be extended to include expectations for `Document` access if needed.

### New Files
- `app/Filament/Admin/Resources/Documents/DocumentResource.php`
  - Defines the Admin resource for documents, navigation metadata (icon, group, sort, labels), and hooks into `DocumentsTable` for the table configuration.
  - Ensures `shouldRegisterNavigation()` restricts visibility to authenticated users who can `viewAny` `Document` (admins via `DocumentPolicy`).
- `app/Filament/Admin/Resources/Documents/Tables/DocumentsTable.php`
  - Encapsulates table configuration: columns (metadata and relationships), filters (uploader, programme, session, course, offering, milestone, folder, MIME, date range), and record actions (replace, delete).
  - Applies eager-loading and default sorting (e.g. by uploaded timestamp descending) via `modifyQueryUsing()`.
- `app/Filament/Admin/Resources/Documents/Pages/ListDocuments.php`
  - List-only Filament page extending `ListRecords` for `DocumentResource`.
  - Removes header create actions (no Admin-side document creation) and optionally adds a subtle description/help text.
- `tests/Feature/Filament/Admin/DocumentResourceTest.php`
  - Feature tests validating that admins can access the documents index, filters behave as expected, and replace/delete actions integrate correctly with `DocumentOperationsService`.

## Implementation Phases
### Phase 1: Foundation
Clarify the domain model, confirm relationships and policies, and prepare any small model-level helpers needed for clean filtering.

### Phase 2: Core Implementation
Create the Filament Admin `DocumentResource` and `DocumentsTable`, wire filters and actions to existing services, and implement the list-only page.

### Phase 3: Integration & Polish
Integrate the resource into the Admin panel navigation, add tests to cover core flows and edge cases, and perform final manual/automated validation.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1. Confirm domain model and relationships
- Review `app/Models/Document.php` to confirm attributes (offering, milestone, folder_slug, uploader, filenames, path, size, mime) and ensure casts and relationships (`offering`, `uploader`) are correct.
- Review `app/Models/CourseOffering.php`, `Programme`, `AcademicSession`, and `Course` to understand how programme/session/course data is linked to a document via `offering`.
- Verify that `DocumentPolicy` and `AuthServiceProvider` correctly grant admins full access (via `before()`) and that no changes are needed to authorize the Admin resource.
- Optionally add or document simple query scopes on `Document` (e.g. `scopeWithCatalogueContext()`, `scopeForFilters(...)`) if they will make the Filament table query cleaner and more reusable.

### 2. Decide navigation grouping and labels
- Choose an appropriate navigation group, e.g. reuse the existing `System` group (alongside Activity Log) or introduce a `Monitoring`/`Documents` group depending on UX preference.
- Define navigation icon using `Filament\Support\Icons\Heroicon`, e.g. `Heroicon::OutlinedDocumentText` or similar, consistent with other resources.
- Set `navigationSort` to position the Documents resource logically among existing Admin resources (for example, after Activity Log or near course offerings).
- Decide on `modelLabel` and `pluralModelLabel` (e.g. “Document” / “Documents”) and optionally a more descriptive `navigationLabel` like “Documents Management”.

### 3. Implement DocumentResource class
- Create `app/Filament/Admin/Resources/Documents/DocumentResource.php` extending `Filament\Resources\Resource`.
- Set `protected static ?string $model = Document::class;` and configure navigation metadata (icon, group, sort, labels) as decided in Step 2.
- Implement `public static function shouldRegisterNavigation(): bool` to return `auth()->check() && static::canViewAny();`, matching patterns used by existing Admin resources.
- Implement `public static function form(Schema $schema): Schema` returning a minimal schema (likely unused for now, e.g. a placeholder or read-only fields) to satisfy the Resource contract.
- Implement `public static function table(Table $table): Table` delegating to `DocumentsTable::configure($table)`.
- Override `public static function getRelations(): array` to return an empty array for the initial version.
- Implement `public static function getPages(): array` with only an `index` route mapped to `ListDocuments::route('/')`, following the list-only pattern from `ActivityResource`.
- Optionally override `public static function getEloquentQuery(): Builder` to customize the base query (e.g. eager-load relationships and handle soft deletes if desired) instead of relying solely on `DocumentsTable` to modify the query.

### 4. Implement DocumentsTable configuration
- Create `app/Filament/Admin/Resources/Documents/Tables/DocumentsTable.php` with a `configure(Table $table): Table` static method.
- In `configure()`, start from a base table instance and call `->modifyQueryUsing()` to:
  - Eager-load relationships: `offering.programme`, `offering.session`, `offering.course`, `uploader`.
  - Set a default sort order, e.g. `->defaultSort('created_at', 'desc')`.
- Define table columns to surface the key metadata:
  - Uploader and context:
    - `TextColumn::make('uploader.name')->label('Lecturer')->badge()->sortable()->searchable()`.
    - `TextColumn::make('offering.programme.code')->label('Programme')->sortable()->searchable()`.
    - `TextColumn::make('offering.session.code')->label('Session')->sortable()->searchable()`.
    - `TextColumn::make('offering.course.course_code')->label('Course Code')->sortable()->searchable()`.
    - Optionally, `TextColumn::make('offering.course.title')->label('Course Title')->limit(40)->searchable()`.
  - Document-specific fields:
    - `TextColumn::make('original_filename')->label('Original name')->wrap()->searchable()`.
    - `TextColumn::make('stored_filename')->label('Stored name')->copyable()->wrap()`.
    - `TextColumn::make('folder_slug')->label('Folder')->wrap()->toggleable(isToggledHiddenByDefault: true)`.
    - `TextColumn::make('path_string')->label('Storage path')->copyable()->wrap()->toggleable(isToggledHiddenByDefault: true)`.
    - `TextColumn::make('milestone')->label('Milestone')->formatStateUsing(fn (mixed $state) => $state instanceof Milestone ? $state->label() : ($state ? Milestone::tryFrom((string) $state)?->label() : null))->badge()`.
    - `TextColumn::make('mime')->label('MIME')->badge()->toggleable(isToggledHiddenByDefault: true)`.
    - `TextColumn::make('filesize')->label('Size')->formatStateUsing(/* simple KB/MB formatter */)` to show a human-readable size; keep logic simple or reuse a helper if available.
    - `TextColumn::make('created_at')->label('Uploaded at')->dateTime()->sortable()`.
- Add filters to enable targeted searching:
  - `SelectFilter::make('uploader_id')->label('Lecturer')->relationship('uploader', 'name')->searchable()`.
  - `SelectFilter::make('programme_id')->label('Programme')` with a `relationship('offering.programme', 'code')` or custom `query()` that uses `whereHas('offering.programme', ...)`, and options built from distinct `Programme` records (similar pattern to `CourseOfferingsTable`).
  - `SelectFilter::make('academic_session_id')->label('Session')` using `offering.session` and options from `AcademicSession`.
  - `SelectFilter::make('course_id')->label('Course')` using `offering.course` with options from `Course`.
  - Optionally, `SelectFilter::make('offering_id')->label('Course Offering')` using `relationship('offering', 'course_identifier')` (or equivalent accessor) or manually built options with combined code/title labels.
  - `SelectFilter::make('milestone')->label('Milestone')->options(collect(Milestone::cases())->mapWithKeys(fn (Milestone $m) => [$m->value => $m->label()])->toArray())`.
  - A generic `Filter` for uploaded date range (e.g. `created_between`) using two `DatePicker` components and a `query()` closure applying `whereDate` ranges (mirroring `ActivitiesTable`).
  - Optionally, a `SelectFilter` for MIME type using distinct `mime` values from `Document` to help narrow down file types when debugging.
- Wire record actions for replace and delete:
  - Define a `Replace` action (custom `Action` or `Tables\Actions\Action`) that:
    - Uses `FileUpload::make('file')->label('Replacement file')->required()`.
    - Reads MIME whitelist and max size from `config('admin.mime_whitelist')` and `config('admin.max_upload_mb')` (mirroring `FolderFileList::allowedMimeTypes()` / `maxUploadKilobytes()` logic) and applies them via `acceptedFileTypes()` and `maxSize()`.
    - In the `action()` closure, retrieves the uploaded `UploadedFile` instance and calls `app(DocumentOperationsService::class)->replace($record, $file)`, handling `ValidationException` so that error messages surface cleanly in the UI.
    - After success, refreshes the record and triggers a notification (e.g. `Notification::make()->success()->title('Document replaced')`).
  - Define a `Delete` action which:
    - Uses `DeleteAction::make('delete')` but overrides the `action()` to call `app(DocumentOperationsService::class)->delete($record);` so that media is also deleted and completeness caches are invalidated.
    - Shows a clear confirmation message explaining that the document record will be archived (soft deleted) and its stored media removed.
    - After deletion, ensures the table refreshes and shows a success notification.
- Ensure the actions respect `DocumentPolicy` by relying on Filament’s built-in `->authorize()` hooks if needed, although admins already have full access via `before()`.

### 5. Implement ListDocuments page
- Create `app/Filament/Admin/Resources/Documents/Pages/ListDocuments.php` extending `Filament\Resources\Pages\ListRecords`.
- Set `protected static string $resource = DocumentResource::class;`.
- Override `protected function getHeaderActions(): array` to return an empty array (`[]`), disabling the default “Create” button since admins should not create documents directly.
- Optionally override `protected function getHeading(): string` or view-related methods if you want a custom page heading, description, or helper text (e.g., “Search and manage documents uploaded by lecturers.”).

### 6. Add tests for the Admin Documents resource
- Create `tests/Feature/Filament/Admin/DocumentResourceTest.php` following patterns from `ProgrammeResourceTest.php` and `CourseResourcePageTest.php`.
- Write a test that an admin can access the documents index page:
  - Seed roles/permissions via `RolesAndPermissionsSeeder`.
  - Create an admin user and act as that user.
  - Hit the route (e.g. `route('filament.admin.resources.documents.index')` or `/admin/documents`) and assert `200 OK`.
- Write a test that a lecturer cannot access the documents index:
  - Create a lecturer user and act as that user.
  - Request the same route and assert `403` or redirect to `/admin/login` depending on Filament’s behavior for non-admins.
- Seed sample document data using factories and `DocumentStorageService::store()` to ensure realistic state, then test filters:
  - Assert that applying a programme filter only shows documents from that programme.
  - Assert that applying a milestone filter only shows documents with that milestone.
  - Assert that the uploader filter limits results to documents uploaded by a specific user.
- (Optional) Write an integration-style test for the replace and delete actions:
  - Use `Storage::fake()` to avoid touching real storage.
  - Create a document using `DocumentStorageService::store()` and then simulate the Filament action calls for replace/delete at the PHP level (e.g. by calling `DocumentOperationsService::replace()` / `delete()` as the page/action would).
  - Assert that media files and database records are updated or soft-deleted as expected; you can lean on existing `DocumentOperationsServiceTest` behaviors for coverage.

### 7. Manual verification and UX polish
- Run migrations and seeders (`php artisan migrate:fresh --seed`) to ensure you have a realistic dataset.
- Log in as an admin to the Admin panel and navigate to the new Documents resource via the sidebar.
- Verify that:
  - The table loads quickly even with multiple relationships; adjust eager loading if you observe N+1 queries.
  - Filters for lecturer, programme, session, course, offering, and milestone behave intuitively and can be combined.
  - Replace and delete actions work as expected and surface clear success or error notifications.
  - Edge cases (e.g. attempting to replace with disallowed MIME or oversize file) result in clear validation messages.
- Adjust column visibility defaults (using `toggleable`) to balance information density and readability, hiding less critical columns by default but making them available on demand.

## Testing Strategy
For this feature, prioritize integration tests around the Filament resource and rely on existing unit tests for the underlying domain services.

- Unit / Service-level (reused):
  - Rely on `tests/Feature/Services/DocumentOperationsServiceTest.php` for rename/move/replace/delete correctness and file-system behavior.
  - If any new Document-specific scopes or helpers are added, add small unit tests under `tests/Unit` to verify their query behavior (e.g. scopes applying filters).
- Feature / Integration:
  - `tests/Feature/Filament/Admin/DocumentResourceTest.php`:
    - Admin can access `/admin/documents` and see existing records.
    - Lecturer cannot access Admin documents; receives 403 or redirect.
    - Filters (programme, session, course, milestone, uploader) correctly narrow results.
    - Table displays expected columns for a seeded document.
  - Extend `AuthorizationTest` if needed to include `Document::class` Gate checks mirroring existing expectations for other admin-managed models.
- Edge cases to consider:
  - Documents with missing or partially missing relationships (e.g. offering soft-deleted) should not break the page; columns and filters should handle `null` gracefully.
  - Milestone stored as string vs enum instance should still render a valid label via `Milestone::tryFrom()`.
  - Large datasets: confirm that adding filters and eager loading keeps query counts reasonable (e.g. no obvious N+1 in debug toolbar).

## Acceptance Criteria
- A new `DocumentResource` appears in the Admin panel navigation under the configured group with an appropriate icon and label (e.g. “Documents”).
- Admin users can open the Documents index page and see a table listing documents with key metadata (uploader, programme, session, course, milestone, folder, filenames, storage path, MIME, size, created_at).
- The table supports filters by:
  - Lecturer (uploader).
  - Programme.
  - Academic Session.
  - Course.
  - Course Offering (optional but recommended).
  - Milestone.
  - Uploaded date range (from/until).
- Replace action on a document:
  - Enforces MIME whitelist and max upload size from `config('admin')`.
  - Calls `DocumentOperationsService::replace()` and updates stored filename/path and metadata.
  - Shows a clear success notification and the table reflects the new metadata.
- Delete action on a document:
  - Calls `DocumentOperationsService::delete()`.
  - Soft-deletes the `Document` record and removes its stored media.
  - Updates completeness calculations implicitly via existing `Document` hooks.
  - Shows a success notification and removes the record from the default table view (unless a trashed filter is later introduced).
- Lecturers and unauthenticated users cannot access the Admin Documents resource; they are either forbidden (403) or redirected to the Admin login.
- All existing tests continue to pass, and new tests for the Documents resource pass reliably.

## Validation Commands
Execute these commands to validate the task is complete:

- `php artisan config:clear` – Ensure configuration (including `config('admin')`) is up to date.
- `php artisan migrate:fresh --seed` – Rebuild database and seed demo data for manual verification.
- `php artisan test` – Run the full test suite, including new `DocumentResource` tests and existing service tests.
- `php artisan route:list | grep filament` – Confirm the new `filament.admin.resources.documents.index` route is registered.

## Notes
- Keep the Admin Documents resource read-only regarding creation and major metadata changes; all new uploads should continue to flow through the Lecturer-facing upload UX to ensure consistent path and naming rules.
- If demand arises for admin-driven document creation or reassignment (e.g. changing offering or milestone), consider a separate, carefully scoped feature to avoid accidentally breaking completeness calculations or folder-template invariants.
- Avoid duplicating MIME and size configuration logic; if both Lecturer and Admin UIs need the same constraints, consider extracting shared helpers (e.g. a small service or trait) in a follow-up refactor.
- Be mindful of performance on large datasets; if the Documents table becomes slow, consider adding database indexes on `offering_id`, `uploader_id`, `milestone`, and `created_at` (if not already present) and using pagination-friendly filters only.

