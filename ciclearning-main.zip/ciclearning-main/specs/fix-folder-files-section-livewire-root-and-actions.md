# Plan: Fix Folder Files Section Livewire Root Error & Simplify Actions

## Task Description
This task fixes a Livewire rendering error affecting the "Folder files" section on the Lecturer Uploads Dashboard and simplifies the available file management actions. Specifically, we need to resolve a `LivewireExceptionsRootTagMissingFromViewException` related to the folder files area and ensure that the per-folder file list only exposes "Replace" and "Delete" actions (removing "Rename" and "Move").  
Task type: fix.  
Complexity: medium.

## Objective
When a lecturer or admin opens the Uploads Dashboard and selects an offering/milestone:
- The folder tiles and folder files sections render without Livewire root tag errors.
- The "Folder files" table lists documents correctly for the selected folder.
- Row actions on the file list are limited to "Replace" and "Delete" and work end‑to‑end (UI + backend).

## Problem Statement
The Lecturer uploads experience currently suffers from two issues:

1. **Livewire root tag error in the folder section**
   - The user observes `LivewireExceptionsRootTagMissingFromViewException` with the message "Livewire encountered a missing root tag when trying to render a component" in the Folder files section.
   - Investigation of the lecturer uploads feature shows that:
     - `App\Livewire\Lecturer\FolderFileList` renders `resources/views/livewire/lecturer/folder-file-list.blade.php`, which already uses a single `<div>` root wrapping a Filament section.
     - `resources/views/livewire/lecturer/folder-tile-grid.blade.php` currently contains **two sibling `<div>` roots** (the tile grid and an inline upload modal) plus Blade directives, which violates Livewire’s requirement for a single root element per component view.
     - There is also a dedicated `App\Livewire\Lecturer\UploadModal` component with its own `resources/views/livewire/lecturer/upload-modal.blade.php` view, and the main page view (`resources/views/filament/lecturer/pages/uploads-dashboard.blade.php`) already includes `<livewire:lecturer.upload-modal ... />`.
   - The error surfaces when Livewire tries to render composite components on the uploads page; even if the message names the folder files area, the underlying root violation is in the tile grid + modal composition.

2. **Actions not aligned with updated requirements**
   - `App\Livewire\Lecturer\FolderFileList::getTableActions()` currently returns four Filament table actions: **Rename**, **Replace**, **Move**, and **Delete**.
   - The updated requirement is that the file list actions should be **limited to Replace and Delete only**:
     - **Replace**: upload a new file version while keeping the same logical Document record (uses `DocumentOperationsService::replace`).
     - **Delete**: remove the stored file and archive/delete the Document record (uses `DocumentOperationsService::delete`).
   - Keeping Rename and Move available in the UI can:
     - Complicate the lecturer experience and increase support burden.
     - Allow unintended re-organization of files that’s no longer desired at this stage.

## Solution Approach
### Livewire root error
- Normalize the Livewire component view structure so each component view has exactly one root HTML element:
  - **Folder tiles grid**:
    - Remove the inline upload modal markup from `resources/views/livewire/lecturer/folder-tile-grid.blade.php`, leaving only the tiles grid UI under a single root `<div>`.
    - Rely solely on the dedicated `UploadModal` Livewire component and its `upload-modal` view for the modal UI.
    - Keep using the existing `openUpload` event dispatcher in `FolderTileGrid` to trigger the modal component (`#[On('open-upload')]` in `UploadModal`).
  - **Folder files list**:
    - Verify and, if needed, minimally adjust `resources/views/livewire/lecturer/folder-file-list.blade.php` to maintain a single root wrapper around its Filament section and table (`{{ $this->table }}`).
  - Confirm that `resources/views/filament/lecturer/pages/uploads-dashboard.blade.php` remains responsible for composing the three Livewire components:
    - `<livewire:lecturer.folder-tile-grid ... />`
    - `<livewire:lecturer.folder-file-list ... />`
    - `<livewire:lecturer.upload-modal ... />`
  - After these changes, each Livewire component will render from a single-root Blade view, eliminating the root tag exception.

### Simplify file list actions
- Update `App\Livewire\Lecturer\FolderFileList`:
  - Modify `getTableActions()` to **only** return:
    - A **Replace** `Action` that:
      - Shows a FileUpload field.
      - Validates allowed MIME types and size (delegated to existing helpers).
      - Calls `DocumentOperationsService::replace($record, $file)` and dispatches `documents-updated` + resets the table.
    - A **Delete** `DeleteAction` that:
      - Calls `DocumentOperationsService::delete($record)`.
      - Dispatches `documents-updated` and resets the table.
  - Remove the **Rename** and **Move** actions from the table definition:
    - Delete or inline-remove the associated authorization, forms, and callbacks.
    - Remove the unused private `leafOptions()` helper if nothing else references it, to keep the class tidy.
- Leave backend services intact:
  - Keep `DocumentOperationsService::rename()` and `DocumentOperationsService::move()` and their tests unchanged; other parts of the system may still rely on them.
- Review and adjust copy:
  - Ensure the `Folder files` section description and any related UI text do not promise rename/move capabilities that are no longer exposed.

### Testing and safety
- Use existing Feature tests and Pest setup to validate:
  - Upload modal behavior (`UploadsDashboardTest` already covers storing a file through `UploadModal`).
  - Rendering of the uploads dashboard and Livewire components without exceptions.
  - Presence/absence of file list actions via Filament testing helpers (e.g., `assertTableActionExists` / `assertTableActionDoesNotExist`) or fallback assertions on rendered HTML.
- Ensure authorization remains correct:
  - Replace/delete actions should still respect `DocumentPolicy` (lecturers manage their own documents; admins may manage all).

## Relevant Files
Use these files to complete the task:

- `app/Filament/Lecturer/Pages/UploadsDashboard.php`
  - Page class that hosts the uploads dashboard and defines computed properties and filters. Its view composes the relevant Livewire components via Blade.
- `resources/views/filament/lecturer/pages/uploads-dashboard.blade.php`
  - Blade view that renders filters, folder tiles, folder files, and the upload modal components. Key place to confirm component composition and event wiring.
- `app/Livewire/Lecturer/FolderTileGrid.php`
  - Livewire component for the folder tiles. Emits `open-files` and `open-upload` events to coordinate with the file list and upload modal. Its view currently mixes tile UI and modal markup.
- `resources/views/livewire/lecturer/folder-tile-grid.blade.php`
  - Blade view that renders the folder tiles grid. Must be refactored to have a single root element and no inline modal markup (the modal will be handled by `UploadModal`).
- `app/Livewire/Lecturer/FolderFileList.php`
  - Livewire component implementing a Filament Table listing folder documents. Responsible for defining `getTableQuery()`, table columns, and table actions (to be restricted to Replace/Delete).
- `resources/views/livewire/lecturer/folder-file-list.blade.php`
  - Blade view for the "Folder files" section. Wraps the Filament section and `{{ $this->table }}` in a root `<div>`. Needs verification but likely only minor/no structural changes.
- `app/Livewire/Lecturer/UploadModal.php`
  - Livewire component that opens/closes the upload modal in response to events and handles submission via `DocumentStorageService`.
- `resources/views/livewire/lecturer/upload-modal.blade.php`
  - Blade view for the upload modal. Should retain a single root element (`<div>`) and can keep its leading `@php` block since it does not output additional HTML nodes.
- `app/Services/DocumentOperationsService.php`
  - Service used by the file list actions for replace/delete (and also rename/move). The replace/delete methods are central to this task and must remain untouched behaviorally.
- `app/Policies/DocumentPolicy.php`
  - Governs which users can update/delete a `Document`. Used by Filament table action authorization closures.
- `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php`
  - Existing Feature tests for the Lecturer uploads page, including a test for storing files through the upload modal. Extend or add assertions to cover the absence of rename/move UI and basic rendering of the folder files section.

## Implementation Phases
### Phase 1: Foundation
- Reproduce the Livewire exception on `/lecturer/uploads` to confirm current behavior and capture the full stack trace.
- Review existing specs (e.g., `specs/lecturer-panel-m2-uploads-status.md`) to understand the original design expectations for the lecturer uploads feature.
- Map out event flows between `FolderTileGrid`, `FolderFileList`, and `UploadModal` to ensure changes to views do not break the event-based coordination.

### Phase 2: Core Implementation
- Refactor the `folder-tile-grid` view to use a single root element and delegate modal rendering purely to the `UploadModal` component.
- Verify and adjust the `folder-file-list` view to ensure it has a clean single-root structure with no extraneous content before/after the root.
- Simplify `FolderFileList::getTableActions()` to only expose Replace and Delete; remove Rename and Move actions and any now-unused helper logic.
- Update any section descriptions and labels that reference the removed actions so that UI copy matches actual capabilities.

### Phase 3: Integration & Polish
- Run the relevant Feature test(s) and, if helpful, add Livewire component tests to confirm the dashboard renders without exceptions.
- Manually verify the lecturer and admin flows through the UI, including error handling and notifications for replace/delete.
- Perform a quick regression pass over upload modal behavior, completeness status updates, and document policy checks to ensure no unintended side effects.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1. Reproduce and inspect the Livewire root error
- Start the local dev server (`php artisan serve`) and navigate to `/lecturer/uploads` as a lecturer with at least one assigned offering and folder template.
- Confirm the `LivewireExceptionsRootTagMissingFromViewException` occurs when the folder tiles/files section loads, and capture the stack trace to verify which Livewire component/view it implicates.
- Note any console/network errors in the browser that might indicate Livewire hydration issues.

### 2. Audit Livewire component views for single-root compliance
- Open `resources/views/livewire/lecturer/folder-file-list.blade.php` and verify that all content is wrapped in a single root `<div>` with no additional sibling HTML elements or Blade directives that output tags outside this root.
- Open `resources/views/livewire/lecturer/folder-tile-grid.blade.php` and confirm that it currently renders multiple top-level `<div>` elements (tile grid + inline modal), which violates Livewire’s single-root requirement.
- Confirm that `resources/views/livewire/lecturer/upload-modal.blade.php` has a single `<div>` root and that the leading `@php` block does not generate any markup.

### 3. Refactor `folder-tile-grid` view to remove inline modal
- In `resources/views/livewire/lecturer/folder-tile-grid.blade.php`, remove the inline upload modal markup block so that the component renders only the tile grid UI under one root `<div>`.
- Ensure that all upload-related UI is handled exclusively by the `UploadModal` component and its view.
- Do a quick visual review to confirm that the removed markup matches the markup present in `resources/views/livewire/lecturer/upload-modal.blade.php`, avoiding duplicated modal implementations.

### 4. Verify dashboard composition of Livewire components
- In `resources/views/filament/lecturer/pages/uploads-dashboard.blade.php`, confirm that three Livewire components are included:
  - `<livewire:lecturer.folder-tile-grid ... />`
  - `<livewire:lecturer.folder-file-list ... />`
  - `<livewire:lecturer.upload-modal ... />`
- Ensure the props passed (`offering-id`, `milestone`, `user-id`) are consistent with the public properties in the corresponding Livewire classes.
- Validate that `FolderTileGrid` still dispatches `open-upload` and `open-files` events and that `UploadModal` listens for `open-upload`, while `FolderFileList` listens for `open-files` and `documents-updated`.

### 5. Simplify `FolderFileList` table actions to Replace/Delete only
- In `app/Livewire/Lecturer/FolderFileList.php`, locate `getTableActions()` and remove the **Rename** and **Move** actions from the returned array.
- Keep and, if needed, tighten the **Replace** action:
  - Ensure the FileUpload field uses `maxUploadKilobytes()` and `allowedMimeTypes()` helpers.
  - Confirm the action calls `DocumentOperationsService::replace($record, $file)`, shows a success notification, dispatches `documents-updated`, and resets the table.
- Keep the **Delete** action as the only other action:
  - Confirm it calls `DocumentOperationsService::delete($record)`, dispatches `documents-updated`, resets the table, and respects authorization via `DocumentPolicy`.
- Remove the now-unused `leafOptions()` helper method if it is no longer referenced anywhere in the class or codebase.

### 6. Align UI copy and documentation with new actions
- Update the description text in `resources/views/livewire/lecturer/folder-file-list.blade.php` (and any other relevant copy) to reflect that lecturers can **replace** or **delete** documents, rather than the broader rename/move capabilities mentioned in the original spec.
- Review `specs/lecturer-panel-m2-uploads-status.md` and internal documentation to:
  - Note the change in capabilities (from replace/rename/move/delete to replace/delete).
  - Optionally add a short note in that spec (or a new changelog entry) documenting the rationale for simplifying the actions.

### 7. Extend or add tests for file list actions and rendering
- In `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php`, add or extend a test that:
  - Bootstraps an offering with folders and at least one uploaded document.
  - Uses `Livewire::test(App\Livewire\Lecturer\FolderFileList::class, [...])` with appropriate props to render the component.
  - Asserts that Replace and Delete actions are present and that Rename/Move are not (e.g., using Filament table testing helpers or HTML-based assertions).
- Optionally add a test that hits `/lecturer/uploads` via HTTP and asserts:
  - The page loads successfully without Livewire exceptions.
  - The rendered HTML includes the `Folder files` section and its table container.
- Ensure existing tests around `DocumentOperationsService`, `DocumentPolicy`, and `UploadModal` continue to pass without modifications to their expectations.

### 8. Manual QA and regression checks
- Log in as a lecturer with assigned offerings and:
  - Verify folder tiles render correctly and clicking a tile updates the folder files table.
  - Open the upload modal via the tiles and ensure it appears and behaves as before.
  - Upload a file, then use the Replace action to upload a new version and confirm metadata updates.
  - Use Delete to remove a document and verify it disappears from the table and completeness indicators update as expected.
- Log in as an admin and confirm:
  - Admin can see and use Replace/Delete on any document, respecting policy expectations.
  - No additional actions (Rename/Move) are visible.

### 9. Final validation
- Run the targeted Feature tests related to the uploads dashboard and document operations.
- Run the full test suite to catch regressions.
- Check application logs for any lingering Livewire or Filament errors related to the uploads dashboard.

## Testing Strategy
- **Automated tests**
  - Extend `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php` to:
    - Verify that the uploads dashboard page (`/lecturer/uploads`) renders successfully for authorized users.
    - Confirm that at least one folder tile and the `Folder files` section render when data is present.
    - Assert that only Replace and Delete actions appear in the folder files table, and that Rename/Move actions are absent.
  - Add a Livewire component-level test for `FolderFileList` (if needed) that:
    - Mounts the component with a pre-populated Document and folder context.
    - Calls the Replace action with a fake `UploadedFile` and asserts that `documents-updated` is dispatched and that media is updated.
    - Calls the Delete action and asserts that the Document is soft/hard deleted as expected and that `documents-updated` is dispatched.
- **Manual tests**
  - Perform end-to-end checks as described in Step 8, covering lecturer and admin flows, including error paths (e.g., trying to replace with an invalid MIME type or oversized file).
  - Verify that no Livewire root tag errors appear in browser dev tools during navigation or component updates.
- **Edge cases**
  - Attempt to open the folder files section when no folder is selected and confirm the empty state messaging is correct.
  - Attempt Replace/Delete on documents where the underlying media is missing or policies deny access, ensuring appropriate notifications/errors and no fatal exceptions.

## Acceptance Criteria
- Loading `/lecturer/uploads` as an authorized user no longer triggers `LivewireExceptionsRootTagMissingFromViewException` or any other Livewire root-tag-related errors.
- `resources/views/livewire/lecturer/folder-tile-grid.blade.php` and `resources/views/livewire/lecturer/folder-file-list.blade.php` each render exactly one root HTML element.
- The "Folder files" table shows **only** Replace and Delete actions for each document; Rename and Move actions are not present in the UI or table definition.
- Replace action successfully uploads a new version of a document, updates its stored filename and metadata, and leaves completeness indicators consistent.
- Delete action removes the document (and its media) while maintaining completeness and path invariants.
- All relevant Feature and Unit tests pass, including updated tests around the uploads dashboard and document operations.

## Validation Commands
Execute these commands to validate the task is complete:

- `php artisan test tests/Feature/Filament/Lecturer/UploadsDashboardTest.php` - Run focused Feature tests for the Lecturer uploads dashboard and related Livewire components.
- `php artisan test` - Run the full test suite (Pest + PHPUnit) to ensure there are no regressions.

## Notes
- No new dependencies are required for this change; it builds on existing Livewire, Filament, and Pest setups.
- Keep `DocumentOperationsService::rename()` and `::move()` and their tests intact for possible future use, even though the UI no longer exposes those operations in the lecturer uploads dashboard.
- When refactoring views, be careful not to introduce extraneous Blade directives or comments outside the root element that could, in future Livewire versions, be treated as additional root nodes.

