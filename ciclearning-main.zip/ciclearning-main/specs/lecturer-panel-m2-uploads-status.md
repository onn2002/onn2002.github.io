# Feature: Lecturer Panel (M2 — Uploads & Status)

## Feature Description
This feature delivers the Lecturer-facing uploads experience and real-time status tracking. It provides a focused Filament page in the Lecturer panel where lecturers filter to an assigned Course Offering and Milestone, see a grid of required folders with ✅/❌ indicators, upload files with server-side path enforcement and renaming, and view per-folder file lists including “You / Total” counts. Lecturers can manage their own files (UI currently exposes Replace/Delete; Move/Rename remain available via backend tooling). All operations use the shared services and are fully auditable.

> **2024-XX Action Simplification**: The lecturer UI now limits file management to Replace and Delete. Rename and Move remain implemented inside `DocumentOperationsService` for future use and support tooling but are hidden in the lecturer dashboard.

## User Story
As a Lecturer
I want to upload course documents into the required folders for my offerings and milestones
So that I can complete my obligations and track my progress clearly

## Problem Statement
Lecturers currently lack a dedicated, constrained UI for uploads. Without enforced folder structures and server-side renaming, files diverge in naming and location, creating confusion and breaking auditability. There is no single place to see per-folder status, nor an easy way to correct mistakes (rename/move/replace/delete own uploads). We need a guided UI that only exposes valid combinations and clearly presents progress.

## Solution Statement
Implement a Lecturer Uploads Dashboard page (Filament) that:
- Filters by Programme, Academic Session, Course Offering (limited to offerings assigned to the user), and Milestone.
- Displays folder tiles (leaf nodes from FolderTemplate) with ✅/❌ status for the current lecturer and a “You / Total” count.
- Provides an upload modal with drag-and-drop; on submit calls the shared DocumentStorageService to enforce path and rename.
- Shows a file list per selected folder, with uploader chips and metadata; lecturers can manage their own files (Replace/Delete in the UI; Rename/Move reserved for admin tooling) via a shared DocumentOperationsService.
- Enforces RBAC and policies: lecturers only see assigned offerings and only manage their own documents; admins retain global access.

## Relevant Files
Use these files to implement the feature:

- `app/Providers/Filament/LecturerPanelProvider.php`
  - Registers Lecturer panel pages/widgets; add the new page to navigation.
- `app/Services/DocumentStorageService.php`
  - Central storage path/rename/validation logic used on upload; call from UI actions.
- `app/Services/FolderPathService.php`
  - Builds enforced directory path from offering + milestone + leaf node.
- `app/Services/DocumentRenamer.php`
  - Computes server-side stored filename (with collision handling) for uploads.
- `app/Services/CompletenessService.php`
  - Computes per-folder ✅/❌ and “You / Total”; used to render the tile grid.
- `app/Models/Document.php`
  - Owner model for medialibrary; events already invalidate completeness cache and sync metadata.
- `app/Models/CourseOffering.php`
  - Provides `course_identifier`, relationships to programme/session/course; query with `lecturers()` to scope to current user.
- `app/Models/FolderTemplate.php`, `app/Models/FolderTemplateNode.php`
  - Source of milestone templates and leaf nodes for folder tiles.
- `app/Enums/Milestone.php`
  - Milestone enumeration; drives filter options and path segment.
- `config/admin.php`
  - MIME whitelist and max upload size constraints enforced by storage service.
- `tests/Feature/DocumentPathAndMediaTest.php`, `tests/Feature/CompletenessServiceTest.php`
  - Existing coverage for storage rules and completeness; extend with M2 tests.

### New Files
- `app/Filament/Lecturer/Pages/UploadsDashboard.php`
  - Custom page registered in the Lecturer panel; hosts filters, tile grid, and per-folder file list with actions.
- `resources/views/filament/lecturer/pages/uploads-dashboard.blade.php`
  - Blade view for the page; composes Filament components and Livewire widgets.
- `app/Livewire/Lecturer/FolderTileGrid.php`
  - Livewire component rendering folder tiles and per-folder status; emits events to open upload/file list.
- `app/Livewire/Lecturer/FolderFileList.php`
  - Livewire component with a Filament Table listing files in the selected folder; lecturer-facing actions are Replace/Delete (Rename/Move remain available in services for admin tooling).
- `app/Livewire/Lecturer/UploadModal.php`
  - Livewire component (modal) to select file(s) and invoke `DocumentStorageService::store()`; shows post-upload metadata.
- `app/Policies/DocumentPolicy.php`
  - Authorizes view/manage own `Document` for lecturers; admins can manage any; wired in `AuthServiceProvider`.
- `app/Services/DocumentOperationsService.php`
  - Shared operations for rename, move (within same offering), replace, delete; updates `Document` + media; logs activity; invalidates completeness.
- `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php`
  - HTTP tests for access control and filters (assigned offerings only) and tile rendering basics.
- `tests/Feature/Policies/DocumentPolicyTest.php`
  - Verifies lecturers can only manage own documents; admins can manage all.
- `tests/Feature/Services/DocumentOperationsServiceTest.php`
  - Validates rename/move/replace/delete behaviors, metadata sync, and completeness invalidation.

## Implementation Plan
### Phase 1: Foundation
- Add `DocumentPolicy` with rules: view/list own; manage own; admin manage any. Register in `AuthServiceProvider`.
- Add query helpers/scopes:
  - `CourseOffering` scope to filter offerings assigned to the current user (via `lecturers()` pivot). Use in page filters.
- Implement `DocumentOperationsService` for file management operations used by both panels:
  - `rename(Document $doc, string $newBaseName): Document`
  - `move(Document $doc, FolderTemplateNode $toLeaf): Document`
  - `replace(Document $doc, UploadedFile $file): Document`
  - `delete(Document $doc): void`
  - Ensure: atomic operations, path + filename recomputation when needed, media move, activitylog, and completeness cache invalidation.

### Phase 2: Core Implementation
- Build `UploadsDashboard` page:
  - Filters: Programme, Academic Session, Course Offering (scoped to current user), Milestone (from enum).
  - Load leaf nodes for selected milestone and compute status via `CompletenessService`.
  - Render via `FolderTileGrid` with ✅/❌ and “You / Total” chips.
- Upload flow (`UploadModal`):
  - Drag-and-drop input; validate via `DocumentStorageService` constraints.
  - On submit: call `store($offering, $milestone, $leaf, $file, $user)`; update grid and file list; success notifications.
- File list (`FolderFileList`):
  - Filament Table scoped by offering + milestone + `folder_slug`.
  - Columns: stored filename, original filename, full `path_string`, uploaded at, uploader.
  - Row actions (owner only): Replace (file), Rename (text), Move (leaf select within same offering/milestone), Delete.

### Phase 3: Integration
- Navigation & access: register page in `LecturerPanelProvider`; ensure only lecturers/admins see it.
- Activity logging: ensure all operations create audit entries (spatie/activitylog) with actor and diffs.
- Completeness cache: rely on `Document` model events and service invalidation after operations.
- UX polish: empty states for no offerings/templates; error toasts for invalid leaf; confirm dialogs for destructive actions.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1) Add DocumentPolicy
- Create `app/Policies/DocumentPolicy.php` with rules: `viewAny`, `view`, `create`, `update`, `delete`.
- Lecturers: can act only on `Document` where `uploader_id === auth()->id()`.
- Admins: can act on any document.
- Register in `app/Providers/AuthServiceProvider.php` and write `tests/Feature/Policies/DocumentPolicyTest.php`.

### 2) Add CourseOffering scope helpers
- Add a local scope `scopeAssignedTo(Builder $q, User $user)` on `CourseOffering` to filter via `lecturers()`.
- Use this scope to populate filter options in the page (Programme, Session, Offering).

### 3) Implement DocumentOperationsService
- Add `app/Services/DocumentOperationsService.php` with methods for rename/move/replace/delete.
- For move: validate destination is a leaf; recompute path using `FolderPathService`; move media and update `folder_slug` and `path_string`.
- For rename: compute a safe new stored filename using `DocumentRenamer` (preserve ext; collision-safe within folder) and rename media on disk; update `stored_filename` and medialibrary `file_name`.
- For replace: store the new file into the same folder with a new stored filename and replace the media record; update `filesize`/`mime` and metadata.
- For delete: delete media + `Document` (soft delete); rely on model hooks to invalidate completeness.
- Add `tests/Feature/Services/DocumentOperationsServiceTest.php` covering each method and edge cases (collisions, invalid leaf, cross-offering moves rejected).

### 4) Build UploadsDashboard page
- Create `app/Filament/Lecturer/Pages/UploadsDashboard.php` with slug `uploads` and navigation label “Uploads & Status”.
- Page state: selected Programme, Session, Offering, Milestone; derive available options server-side using `scopeAssignedTo` and eager loading.
- Render child components: `FolderTileGrid`, `FolderFileList`, `UploadModal`.
- Limit access with `->canAccess()` to lecturers/admin (panel gating also applies).

### 5) FolderTileGrid component
- Input props: offering id, milestone, current user id.
- Query leaf nodes for milestone; compute status via `CompletenessService::statusFor($user, $offering, $milestone)`.
- Render tiles with folder label, ✅/❌, and “You / Total”.
- Emit events: `open-upload(folderSlug)` and `open-files(folderSlug)`.
- Add basic tests in `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php` asserting tiles render for seeded leaves and reflect status.

### 6) UploadModal component
- Accept selected folder (slug or node id) and selected file(s).
- Resolve leaf node (guard leaf-only) and call `DocumentStorageService::store()` with current user.
- Show success notification with stored filename and display path; refresh tile grid and file list.
- Enforce MIME and size constraints from `config/admin.php`; surface validation errors in the modal.
- Extend `tests/Feature/Filament/Lecturer/UploadsDashboardTest.php` with fake storage upload assertions.

### 7) FolderFileList component
- Build a Filament Table querying `Document` by offering + milestone + `folder_slug`.
- Columns: stored filename, original filename, `path_string`, uploader (badge), created_at.
- Actions (owner only via `DocumentPolicy`): Replace (file upload → `DocumentOperationsService::replace()`) and Delete (`delete()`). Rename/Move remain supported by the service for future admin tooling but are intentionally hidden in the lecturer UI.
- After actions: refresh completeness (model hooks) and UI; log activity.

### 8) Wire navigation and visibility
- Add page to the Lecturer panel navigation in `LecturerPanelProvider` (below Dashboard).
- Ensure only lecturers/admins see the page; guests redirected to `/lecturer/login`.

### 9) Tests and fixtures
- Seed a programme, session, course, offering assigned to the lecturer; seed a FolderTemplate with a root + leaf.
- Write `UploadsDashboardTest` to cover:
  - Access control (lecturer allowed; unverified denied; guest redirected).
  - Filters show only assigned offerings; milestones from enum.
  - Tiles render and reflect status before/after upload.
  - Upload succeeds to enforced path with server-side rename (fake storage) and updates counts.
  - Owner-only actions enforce policy.

### 10) Docs and UX polish
- Add help text explaining path structure and renaming rules.
- Show storage location path preview on upload modal.
- Friendly empty states (no offerings; no templates for milestone).

### 11) Validation Commands
- Run the commands listed in “Validation Commands” to ensure all tests pass, style checks succeed, and the UI boots locally.

## Testing Strategy
### Unit Tests
- DocumentOperationsService: rename, move (leaf-only, within same offering), replace, delete; collision handling; metadata sync; completeness invalidation.
- DocumentPolicy: lecturer can manage own only; admin can manage any.

### Integration Tests
- UploadsDashboard page access and filters (assigned offerings only) using Filament routes.
- Upload flow with `Storage::fake('local')`: ensure on-disk path equals PRD format; stored filename follows renamer rules; metadata synced.
- Folder tile status transitions from ❌ → ✅ for required leaves; “You / Total” updates with other users’ uploads.

### Edge Cases
- Upload to non-leaf or unknown folder slug rejected with validation errors.
- MIME and max-size validation errors surfaced in modal.
- Filename collisions within a folder append `_{n}`.
- Multi-lecturer offerings: ensure status is per uploader but file list shows all with uploader chips.
- Deleting the only file in a required folder flips ✅ → ❌ for that user.

## Acceptance Criteria
- Lecturer panel exposes an “Uploads & Status” page with filters: Programme, Session, Course Offering (assigned only), Milestone.
- Folder tiles show required leaves for the selected milestone with ✅/❌ per lecturer and “You / Total” counts.
- Uploading a file stores it under `{programme_code}/{session_code}/{course_identifier}/{milestone}/{folder}/` with server-side rename `{base}_{course_code}_{YYYYMMDD}.{ext}` (MYT) and updates the UI.
- File list displays stored filename, original filename, full path, uploader, and timestamp.
- Lecturer UI surfaces Replace/Delete for their own files (backend services still support Rename/Move for admin/support usage); actions are authorized and audited.
- Completeness recalculates automatically on create/update/delete and reflects immediately in the grid.
- All tests pass and code style/linting succeed.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `php artisan migrate:fresh --seed`
- `php artisan test` - Run tests to validate the feature works with zero regressions
- `composer run lint` - Ensure Pint style passes in test mode
- `composer run stan` - Run PHPStan static analysis
- `php artisan serve` - Boot locally to verify Lecturer `/lecturer/uploads` page loads
- `php artisan storage:link` - If public assets are needed (not for private uploads; optional)

## Notes
- No new libraries required; Filament v4 and Livewire are already present. All upload constraints come from `config/admin.php`.
- `DocumentOperationsService` is designed for reuse by Admin (M3) file operations to avoid duplication.
- Use `Asia/Kuala_Lumpur` timezone for date-based rename; rely on Carbon’s `now('Asia/Kuala_Lumpur')` as in existing services.
- Keep queries eager-loaded (`programme`, `session`, `course`) for the offering filter and file tables to reduce N+1.
- Activitylog categories: use a dedicated log name for documents; include actor, subject, and diffs.
