# Plan: Lecturer Missing Uploads Reminder System

## Task Description
Implement an automated reminder system that notifies lecturers about folders where they have not yet uploaded required files. The system must:
- Let an admin configure recurring reminder schedules (days of week + time) from the existing Admin Settings page.
- Use SMTP configuration stored in a persistent `settings` table (with graceful fallback to env-based overrides) to send email reminders.
- Send both email and in-app (database) notifications to lecturers, linking them to the Lecturer uploads dashboard.
- Use the `reminder_schedules` table as the scheduling backbone for dispatching reminders, and respect the configured recurrence.

## Objective
Deliver a robust, scheduler-driven reminders pipeline that:
- Computes missing uploads per lecturer, per course offering, and milestone using existing completeness logic and folder templates.
- Periodically generates `reminder_schedules` rows according to Settings-based recurrence, scoped by programme/session/milestone as needed.
- Dispatches email + database notifications for each due schedule, targeting only lecturers with missing required uploads, and avoids double-sending.

## Problem Statement
The system currently tracks document completeness per lecturer, course offering, and milestone and exposes a Lecturer uploads dashboard. However, there is no automated reminder workflow:
- Admins cannot configure recurring reminders for lecturers.
- There is no persistent configuration for reminder timing beyond env-backed overrides, and SMTP overrides are not wired into mail sending.
- The `reminder_schedules` table and model exist but are not yet used to drive notifications.
- Lecturers receive no proactive reminders when they have missing uploads, reducing compliance and increasing manual follow-up.

We need a configurable, reliable reminder system that fits the existing architecture (Laravel, Filament, Spatie packages, PRD expectations) and leverages `ReminderSchedule` for time-based dispatch.

## Solution Approach
- **Classify task**: `task_type = feature`, `complexity = complex`.
- **Persistent settings**:
  - Introduce a simple `settings` table and `Setting` model for key/value system settings, including SMTP overrides and reminder recurrence configuration.
  - Keep the existing env-backed `config/admin.php` + `EnvManager` as primary for non-reminder settings but introduce a bridge so reminder-related configuration is managed in the database.
- **Reminder configuration UI**:
  - Extend `App\Filament\Admin\Pages\Settings` to include a new "Reminders" section with:
    - Multi-select days of week.
    - Time of day (HH:MM, MYT).
    - Optional scope (all programmes/sessions, or specific programme/session/milestone) if required in MVP.
  - Persist this configuration via the new `settings` table, following patterns similar to current env-backed state (normalization, validation).
- **SMTP configuration usage**:
  - Move SMTP override data into `settings` while still reflecting it into env/config (`ADMIN_SMTP_*`) so existing behaviors continue to work.
  - Introduce a small SMTP configuration service that, for reminder sends, reads SMTP settings from the `settings` table (with fallback to `config('admin.smtp')` / `MAIL_*`) and applies them to `config('mail.mailers.smtp')` at runtime, only for the reminder dispatch execution path.
- **Targeting missing uploads**:
  - Implement a `ReminderTargetingService` that:
    - For a given scope (programme/session/milestone from `ReminderSchedule`), enumerates relevant course offerings and lecturers.
    - Uses `CompletenessService::statusFor($user, $offering, $milestone)` plus folder templates to discover required folders where `done === false`.
    - Returns a structured set of reminder targets: lecturer + per-offering + per-milestone + list of folder slugs/labels.
- **Leveraging `reminder_schedules`**:
  - Use `reminder_schedules` as **schedule instances**, not per-lecturer rows:
    - Each row represents a one-off reminder run with (optional) scope: `programme_id`, `academic_session_id`, `milestone`, `send_at`, `channels`, `active`, `sent_at`.
  - Implement **Command A** to generate upcoming schedule rows based on recurrence configuration stored in Settings.
  - Implement **Command B** to dispatch notifications for due schedules using the `ReminderSchedule::due()` scope and mark them as sent.
- **Notifications**:
  - Create a dedicated `MissingUploadsReminderNotification` (Laravel notification) that:
    - Sends via `mail` and `database` channels.
    - Renders an email and DB message consistent with the provided sample and PRD, including programme, session, course, milestone, and folder list.
    - Includes a link to `/lecturer/uploads` (Lecturer uploads dashboard).
- **Scheduling & idempotency**:
  - Wire both commands into `app/Console/Kernel.php` with `schedule()` using MYT (Asia/Kuala_Lumpur).
  - Make commands idempotent:
    - Command A only creates new `ReminderSchedule` rows when a matching send slot does not already exist.
    - Command B only processes active schedules with `sent_at` null, and ensures each lecturer is notified once per schedule.
- **Testing & observability**:
  - Add feature tests around reminder configuration, schedule generation, targeting, and dispatch.
  - Log reminder dispatches via activity log (`reminder_schedule` subject) and ensure failures are visible via logs and test assertions.

## Relevant Files
Use these files to complete the task:

- `app/Filament/Admin/Pages/Settings.php`
  - Existing admin Settings page, currently env-backed via `EnvManager`.
  - Extend with a "Reminders" section for day-of-week and time-of-day configuration and, if needed, scope configuration for reminders.
- `config/admin.php`
  - Centralizes admin-related configuration (MIME whitelist, SMTP/WhatsApp overrides).
  - Extend to surface reminder-related config derived from env or `settings` table (e.g., `admin.reminders.days`, `admin.reminders.time`, `admin.reminders.channels`).
- `app/Support/EnvManager.php`
  - Persists env overrides for existing settings; decide how much of SMTP config continues to be env-based vs moved fully into `settings`.
  - Optionally updated or complemented by a new settings service to bridge between env and DB for SMTP/reminders.
- `config/mail.php`
  - Global mailer configuration.
  - Update to respect admin SMTP overrides and/or reminder-specific SMTP settings via a helper service invoked in reminder dispatch.
- `app/Models/ReminderSchedule.php`
  - Existing Eloquent model mapping `reminder_schedules`.
  - Provide helper methods/scopes for common queries (`active()`, `due()`, `scopedTo(...)`) and convenience builders for schedule generation.
- `database/migrations/2025_10_24_022746_create_reminder_schedules_table.php`
  - Defines the `reminder_schedules` schema; confirm indices and fields align with intended usage.
- `app/Enums/Milestone.php`
  - Milestone enum; used to scope schedules and to build human-readable milestone labels and path segments for emails.
- `app/Models/Programme.php`, `app/Models/AcademicSession.php`, `app/Models/CourseOffering.php`, `app/Models/Document.php`
  - Core entities for programme/session/offering and uploaded documents.
  - Required to scope reminder targets and to build contextual information (programme code, session code, course code/title).
- `app/Services/CompletenessService.php`
  - Computes per-lecturer folder completeness (`required`, `you`, `total`, `done`).
  - Use this service to find missing required folders per lecturer/offerings/milestones when constructing reminders.
- `app/Services/FolderPathService.php`
  - Builds the canonical folder path (`{programme}/{session}/{course_identifier}/{milestone}/{folder}/`).
  - Used to generate folder paths in reminder emails/notifications for clarity.
- `app/Models/User.php`
  - Lecturer model, including `courseOfferings()` relation and notification capabilities (via `Notifiable`).
  - Used to identify and notify lecturers with pending uploads.
- `app/Providers/Filament/LecturerPanelProvider.php`, `app/Filament/Lecturer/Pages/UploadsDashboard.php`
  - Define the Lecturer uploads dashboard path and access control.
  - Use for constructing URLs in notifications (`/lecturer/uploads`) and ensuring only lecturers receive reminders.
- `database/migrations/2025_10_23_162631_create_notifications_table.php`
  - Notifications table used by Laravel’s database channel.
  - Ensure it is used for storing reminder database notifications.
- `tests/Feature/DatabaseSchemaTest.php`, `tests/Feature/*Completeness*Test.php`
  - Existing tests for `reminder_schedules` schema and completeness behavior; extend with reminder-specific tests.
- `docs/prd.md`, `docs/TODO.md`
  - Source-of-truth specs for reminders (M4, ReminderSchedule) and scheduling behavior; confirm plan alignment.

### New Files
- `database/migrations/xxxx_xx_xx_xxxxxx_create_settings_table.php`
  - New migration for the `settings` table (system-level key/value configuration).
- `app/Models/Setting.php`
  - Eloquent model wrapping `settings` rows, with helpers for typed retrieval of SMTP and reminder configuration.
- `app/Services/SettingsService.php`
  - Small domain service providing high-level getters/setters for system settings (SMTP override, reminder recurrence).
- `app/Services/ReminderTargetingService.php`
  - Computes the set of lecturers with missing uploads for a given schedule scope (programme/session/milestone) and returns structured reminder payloads.
- `app/Services/ReminderMailConfigService.php`
  - Applies SMTP overrides from `settings` / `config('admin.smtp')` to `config('mail.mailers.smtp')` for the duration of a reminder dispatch operation.
- `app/Console/Commands/GenerateReminderSchedules.php`
  - Artisan command (“Command A”) that reads recurrence configuration and creates upcoming `reminder_schedules` rows.
- `app/Console/Commands/DispatchDueReminders.php`
  - Artisan command (“Command B”) that picks up due schedules, computes targets, sends notifications, and marks schedules sent.
- `app/Notifications/MissingUploadsReminderNotification.php`
  - Laravel notification for email + database reminders, encapsulating message templates and link generation.
- `tests/Feature/Reminders/ReminderSettingsTest.php`
  - Tests for saving/retrieving reminder configuration via the Settings page and `settings` table.
- `tests/Feature/Reminders/GenerateReminderSchedulesCommandTest.php`
  - Tests for schedule generation logic.
- `tests/Feature/Reminders/DispatchDueRemindersCommandTest.php`
  - Tests for dispatch behavior, ensuring correct targeting and idempotency.

## Implementation Phases

### Phase 1: Foundation
- Introduce persistent settings infrastructure and reminders configuration model.
- Design and implement a reusable targeting service that maps completeness gaps to reminder payloads.
- Wire SMTP overrides into mail configuration via a dedicated service, without breaking existing mail behavior.

### Phase 2: Core Implementation
- Extend the Admin Settings page with reminder configuration UI and persistence.
- Implement Command A to generate `ReminderSchedule` rows based on recurrence and scope.
- Implement Command B to dispatch reminders using `ReminderSchedule::due()`, targeting lecturers with missing uploads.
- Implement the `MissingUploadsReminderNotification` with email/database channels and proper message templates.

### Phase 3: Integration & Polish
- Wire both commands into the Laravel scheduler (`schedule()` in `Console\Kernel`) with MYT timezone.
- Ensure logging and activity recording for reminder sends.
- Add and refine tests to cover configuration, commands, targeting, notifications, and key edge cases.
- Update docs/readme snippets if needed to describe the new reminder behavior and scheduler requirements.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1. Add persistent settings infrastructure
- Create `settings` table migration with columns:
  - `id`, `key` (string, unique), `value` (json or text), timestamps.
- Add `app/Models/Setting.php` model with:
  - `$fillable = ['key', 'value']`, cast `value` to array.
  - Static helpers to `get(string $key, mixed $default = null)` and `set(string $key, mixed $value)`.
- Implement `app/Services/SettingsService.php` with typed accessors for:
  - `smtpOverride()` (host, port, username, password, encryption, enabled flag).
  - `reminderRecurrence()` (days of week, time of day, scopes).
- Seed or migrate existing SMTP override data into `settings` on first use if needed (fallback from `config('admin.smtp')` / env).

### 2. Extend admin Settings page with Reminder configuration
- Update `app/Filament/Admin/Pages/Settings.php`:
  - Add a new `Section::make('Reminders')` with:
    - A multi-select or checkbox group `reminders.days` for days of week (`['monday', 'tuesday', ...]`).
    - A `TimePicker` or text input `reminders.time` for HH:MM (MYT).
    - Optional controls for default channels (email/db) if relevant.
    - Clear helper text explaining that this controls when lecturers receive reminders for missing uploads.
- In `submit()`:
  - Normalize days and time, validate:
    - At least one day selected.
    - Time is a valid HH:MM, within 00:00–23:59.
  - Save reminder settings via `SettingsService` (and, if necessary, synchronize env variables using `EnvManager` for backward compatibility).
- In `getCurrentSettings()` / `normaliseConfig()`:
  - Load existing reminder configuration from `SettingsService`, apply sane defaults if not set (e.g., weekdays at 09:00 MYT).

### 3. Bridge SMTP overrides from settings to mail configuration
- Extend `SettingsService` with methods for reading/writing SMTP overrides that mirror the current `config('admin.smtp')` shape.
- Implement `app/Services/ReminderMailConfigService.php` with:
  - A method `applyOverrideForReminders(callable $callback): void` that:
    - Reads SMTP override settings from `SettingsService`.
    - Clones current `config('mail.mailers.smtp')`.
    - If overrides are enabled and host/port are present, temporarily adjusts `config('mail.mailers.smtp')` (and possibly `mail.from`) for the duration of `$callback`.
    - Restores the original configuration afterward, even if exceptions occur.
- Optionally, adjust `config/mail.php` or bootstrapping code to prefer admin overrides globally (outside reminders) when enabled, so the system is consistent.

### 4. Implement ReminderTargetingService to find missing uploads
- Create `app/Services/ReminderTargetingService.php` with method(s) like:
  - `public function buildTargets(?int $programmeId, ?int $sessionId, ?Milestone $milestone): Collection`
    - Resolve the relevant `CourseOffering` records in scope, eager-loading `programme`, `session`, `course`, and `lecturers`.
    - For each offering/lecturer/milestone combination in scope:
      - Use `CompletenessService::statusFor($lecturer, $offering, $milestone)` to get per-folder status.
      - Identify folders where `required === true` and `done === false`.
      - Use `FolderTemplateNode` / `FolderPathService` to gather human-readable folder paths (e.g., `/BeginningOfSemester/LessonPlan`).
      - If at least one required folder is missing for a lecturer, add a target record with:
        - `lecturer` (`User`), `offering`, `programme`, `session`, `milestone`, `missing_folders` (list of paths).
    - Return a collection keyed or grouped by lecturer so multiple offerings can be aggregated if desired.
- Ensure this service is careful about performance:
  - Use eager loading for relations.
  - Use the cache-friendly `CompletenessService` so repeated calls do not cause excessive DB churn.

### 5. Implement `GenerateReminderSchedules` command (Command A)
- Create `app/Console/Commands/GenerateReminderSchedules.php` extending `Command`:
  - Signature: `reminders:generate-schedules {--force}` or similar.
  - Behavior:
    - Read recurrence configuration from `SettingsService::reminderRecurrence()`.
    - Compute the next few scheduled `send_at` timestamps (e.g., for the next 7–14 days) in MYT.
    - For each computed slot:
      - Optionally derive scope from configuration (e.g., global vs programme/session-specific).
      - Check if a `ReminderSchedule` row already exists with the same `send_at` (rounded to minute) and scope and still `active`.
      - If not, create a new `ReminderSchedule` row with:
        - `programme_id`, `academic_session_id`, `milestone` (if scoped).
        - `send_at` set to the scheduled MYT timestamp.
        - `channels` defaulting to `['mail', 'database']`.
        - `active = true`, `sent_at = null`.
    - Optionally, support a `--dry-run` option to log what would be created without writing to DB.
- Ensure the command uses `ReminderSchedule` scopes/constructors consistently and respects application timezone (config `app.timezone`).

### 6. Implement `DispatchDueReminders` command (Command B)
- Create `app/Console/Commands/DispatchDueReminders.php`:
  - Signature: `reminders:dispatch-due {--schedule-id=*}` (allow optional filtering to specific schedule IDs for debugging).
  - Behavior:
    - Resolve the current reference time as `now(config('app.timezone'))`.
    - Query `ReminderSchedule::due($reference)`:
      - `active = true`, `sent_at IS NULL`, `send_at <= $reference`.
    - For each due schedule:
      - Resolve its scope (`programme_id`, `academic_session_id`, `milestone`).
      - Use `ReminderTargetingService` to build targets (lecturers + missing folders).
      - If no lecturers have missing uploads:
        - Mark the schedule as sent (`sent_at = $reference`, `active = false` or keep active if recurrence semantics require reuse).
        - Optionally log that there were no targets.
      - If there are targets:
        - Use `ReminderMailConfigService::applyOverrideForReminders()` to wrap the notification send block so SMTP overrides apply.
        - For each lecturer target:
          - Instantiate `MissingUploadsReminderNotification` with details (programme/session/course/milestone/folder list).
          - Call `$lecturer->notify($notification)`.
        - After successful sends (or best-effort with partial failures logged), mark the schedule as processed:
          - Set `sent_at`, optionally set `active = false`.
    - Add idempotency:
      - Respect `sent_at` so already-processed schedules are skipped.
      - Ensure that even if the command is re-run within the same minute, duplicate notifications are not sent (e.g., by using `sent_at` and not reusing schedule records).
- Add logging:
  - Log the number of schedules processed and the number of lecturers notified per run.
  - Hook into Spatie Activitylog using `activity()->performedOn($schedule)->log('reminder_dispatched');` for auditability.

### 7. Implement `MissingUploadsReminderNotification`
- Create `app/Notifications/MissingUploadsReminderNotification.php` extending `Illuminate\Notifications\Notification`:
  - Constructor accepts a structured payload, e.g.:
    - Lecturer `User`.
    - Collection of affected offerings (programme/session/course/milestone).
    - Map of offering → list of missing folder paths.
    - The schedule `ReminderSchedule` instance.
  - `via($notifiable)` returns `['mail', 'database']` for now (WhatsApp/Vonage can be added later).
  - `toMail($notifiable)`:
    - Use `MailMessage` with subject `Reminder: Pending documents for {course_identifier} ({milestone})` or a sensible aggregate if multiple offerings.
    - Body similar to prompt:
      - Greeting `Hello {User Name},`
      - For each affected course, render:
        - `The folder in {Programme Name} {Academic session} {Course Name} requires your attention.`
        - `This is a friendly reminder that you have not yet uploaded files to the following folders:`
        - List bullet points for each missing folder path (e.g., `/BeginningOfSemester/LessonPlan`).
      - Include a call-to-action with a link to `url('/lecturer/uploads')`.
  - `toArray($notifiable)`:
    - Store a short message and context data in `notifications.data`, including:
      - Text similar to the email’s first lines.
      - URL: `url('/lecturer/uploads')`.
      - Optional metadata (`programme_code`, `session_code`, `course_identifier`, `milestone`, folder count).
- Ensure the notification leverages existing Laravel Notifications configuration and works with the `notifications` table migration.

### 8. Wire commands into Laravel scheduler
- Create or update `app/Console/Kernel.php` if missing:
  - Register the two new commands in `$commands` or via auto-discovery as appropriate.
  - In `schedule(Schedule $schedule)`:
    - Schedule Command A:
      - E.g., `$schedule->command('reminders:generate-schedules')->hourly()->timezone('Asia/Kuala_Lumpur');`
      - Frequency can be relatively frequent (e.g., hourly) since the command itself checks recurrence and avoids duplicate schedule rows.
    - Schedule Command B:
      - `$schedule->command('reminders:dispatch-due')->everyMinute()->timezone('Asia/Kuala_Lumpur');`
    - Ensure scheduler is documented in README (already hints at `php artisan schedule:work`).
- Confirm that `config/app.php` timezone is `Asia/Kuala_Lumpur` so `now()` aligns with PRD.

### 9. Add tests for settings, schedule generation, and dispatch
- `tests/Feature/Reminders/ReminderSettingsTest.php`:
  - Verify the Settings page:
    - Shows the Reminders section.
    - Validates missing days/time.
    - Persists reminder configuration into `settings` and can retrieve it.
  - Assert that invalid configurations (no days, invalid time format) show validation errors.
- `tests/Feature/Reminders/GenerateReminderSchedulesCommandTest.php`:
  - Seed a reasonable reminder configuration (e.g., Mondays at 09:00).
  - Run `artisan reminders:generate-schedules`:
    - Assert expected `ReminderSchedule` rows exist with correct `send_at` (MYT) and channels.
    - Assert re-running the command does not create duplicates for the same slot.
- `tests/Feature/Reminders/DispatchDueRemindersCommandTest.php`:
  - Seed programmes, sessions, courses, offerings, lecturers, folder templates, and documents such that some lecturers have missing uploads.
  - Create due `ReminderSchedule` rows.
  - Fake mail and notifications using Laravel’s `Notification::fake()` / `Mail::fake()` (or just Notifications if using the notification system exclusively).
  - Run `artisan reminders:dispatch-due`:
    - Assert that lecturers with missing uploads receive `MissingUploadsReminderNotification`.
    - Assert that lecturers with no missing uploads do not receive notifications.
    - Assert `ReminderSchedule.sent_at` is populated and `active` is updated appropriately.
  - Re-run the command and assert no duplicate notifications are sent (idempotency).
- Add edge case tests:
  - When SMTP settings are missing/invalid (e.g., host null), ensure dispatch handles the error gracefully (logs, but does not crash entire command).
  - When schedule scope targets a programme/session with no active offerings or lecturers, ensure the command completes cleanly.

### 10. Manual validation and documentation updates
- Update `README.md`:
  - Document the new reminder behavior, including:
    - How to configure reminders via the Settings page.
    - The names of the two commands and their scheduler configuration.
  - Clarify that SMTP overrides are now managed via Settings and consumed during reminder dispatch.
- Optionally add a short admin-facing help note in the Settings page or elsewhere to explain how reminders are computed (based on missing uploads per lecturer).

### 11. Final verification
- Run migrations and seeders:
  - `php artisan migrate --force` (or `php artisan migrate:fresh --seed` in dev).
- Run the full test suite and static analysis tools.
- Run the scheduler manually in a dev environment:
  - Use `php artisan reminders:generate-schedules` and `php artisan reminders:dispatch-due` to verify behavior.
  - Use fake mail/notification drivers during development to inspect messages.

## Testing Strategy
For this complex feature, prioritize integration tests that exercise the full path from configuration to dispatch, supplemented by targeted unit tests.

### Unit Tests
- `SettingsService`:
  - Correctly stores and retrieves SMTP override and reminder recurrence data from `settings`.
  - Handles defaults and fallback to env/config when values are absent.
- `ReminderMailConfigService`:
  - Applies and restores SMTP override configuration around a callback.
  - Does not leak overridden mail configuration outside of the callback, even on exceptions.
- `ReminderTargetingService`:
  - Given controlled fixtures, returns expected lecturer targets and missing folder lists.
  - Handles edge cases where there are no folder templates or all folders are complete.
- `ReminderSchedule` model:
  - `active()` and `due()` scopes behave as expected with different `send_at`/`sent_at` combinations and timezones.

### Integration / Feature Tests
- Settings page:
  - End-to-end configuration flow via Filament Settings page updates `settings` and surfaces saved values accurately.
- Commands:
  - `reminders:generate-schedules` creates schedules for configured days/times and is idempotent.
  - `reminders:dispatch-due`:
    - Sends notifications only for due schedules.
    - Only targets lecturers with missing required uploads.
    - Marks schedules as processed.
- Notification content:
  - Snapshot-style tests (or string contains) to assert that generated mails include:
    - Lecturer name.
    - Programme name/code, session code, course name.
    - Milestone label and folder paths.
    - Link to `/lecturer/uploads`.

### Edge Cases
- Multiple days per week configured:
  - Verify that schedule generation covers each day correctly and does not duplicate.
- Multiple courses/folders needing reminders for the same lecturer:
  - Verify that email and DB notifications present multiple items clearly (grouped per course).
- Missing or invalid SMTP settings:
  - Reminder dispatch logs an error and either:
    - Skips sending emails but still creates database notifications.
    - Or marks the schedule as failed with clear logging (implementation decision documented).
- Concurrent command execution:
  - Two overlapping `reminders:dispatch-due` runs do not double-send due to `sent_at` checks and transactional updates.

## Acceptance Criteria
- Admin can configure reminder schedules on the Settings page:
  - Select one or more days of the week.
  - Select a time of day (MYT).
  - Configuration is persisted in a `settings` table and reflected back in the UI.
- SMTP overrides for reminders are sourced from persistent settings and applied during reminder dispatch, with safe fallback to env-based configuration when needed.
- `reminder_schedules` table is used as the backbone for reminders:
  - Command A (`reminders:generate-schedules`) creates new rows for upcoming send times based on configured recurrence, without duplicates.
  - Command B (`reminders:dispatch-due`) reads due rows using `ReminderSchedule::due()`, sends notifications, and marks rows processed.
- For each due schedule:
  - Only lecturers with missing required uploads in the schedule’s scope receive reminders.
  - Emails contain the specified content (including programme, session, course, milestone, and folder paths).
  - Database notifications are created with similar content and link lecturers to `/lecturer/uploads`.
- Commands are idempotent and safe to run on their respective cadences (e.g., every minute for dispatch).
- All new and existing tests pass; static analysis and style checks succeed.

## Validation Commands
Execute these commands to validate the task is complete:

- `php artisan migrate` – Apply new `settings` table migration and ensure schema is up to date.
- `php artisan migrate:fresh --seed` – Optional in development to verify schema and seeders including reminder-related tables.
- `php artisan test` – Run the full test suite, including new reminder-related tests.
- `php artisan reminders:generate-schedules --dry-run` – Confirm schedule generation behavior without persisting.
- `php artisan reminders:generate-schedules` – Generate actual upcoming reminder schedules.
- `php artisan reminders:dispatch-due` – Manually trigger dispatch for due schedules in a controlled environment.
- `php artisan schedule:run` – Verify that scheduler hooks for the two commands execute without errors.

## Notes
- This feature builds on existing completeness and folder template infrastructure; do not duplicate logic for determining missing uploads—always go through `CompletenessService` and template models.
- Timezone consistency is critical:
  - Use `now(config('app.timezone'))` and store `send_at` in MYT (per PRD).
  - Laravel scheduler should specify `->timezone('Asia/Kuala_Lumpur')`.
- Avoid introducing new external dependencies unless absolutely necessary; leverage Laravel’s notifications, scheduler, and existing Spatie packages.
- Consider future extension:
  - WhatsApp/Vonage channel can be added later by extending `MissingUploadsReminderNotification::via()` and adding a `toVonage()` implementation that uses settings stored in `settings` / `config('admin.whatsapp')`.
- If, during implementation, it becomes preferable to migrate all admin settings from `.env` to `settings`, ensure the transition is backward compatible and well-documented, but that migration is beyond the strict scope of this reminder feature and can be staged separately.

