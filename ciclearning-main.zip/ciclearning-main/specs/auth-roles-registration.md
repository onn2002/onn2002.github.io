# Feature: Auth, Roles & Registration

## Feature Description
Introduce end-to-end authentication with registration, email verification, and role assignment using Spatie Permission. Add a minimal approval flow for admin registrations, enforce access via roles and verification status (including Filament panel access rules), and seed base roles/permissions. This unlocks secure access to both Admin and Lecturer experiences, ensures unverified users and unapproved admins cannot access protected features, and aligns with PRD FR-9 and the permissions matrix.

## User Story
As a new user (lecturer or admin)
I want to register, verify my email, and receive the correct role-based access
So that I can securely use the system according to my responsibilities

## Problem Statement
The project lacks a registration flow, email verification, and role enforcement. Without this, users cannot onboard, lecturers cannot access their dashboard, and admin access cannot be safely controlled. An admin approval step is required to prevent unauthorized elevation to admin.

## Solution Statement
Use Laravel Breeze to scaffold authentication (Blade) with email verification and customize registration to include a role selection (lecturer or admin). Integrate Spatie Permission to assign roles. If a user selects admin, create the account as admin but mark it as requiring approval, and gate Admin Panel access until approved. Implement Filament user gating (canAccessPanel) to enforce verified email + role + admin approval checks. Seed roles and base permissions per PRD and add tests to validate the flows.

## Relevant Files
Use these files to implement the feature:

- `README.md` – Documents getting started and behavior expectations (timezone, panels, RBAC mention).
- `docs/TODO.md` – Defines Auth scope, email verification, admin approval, and policies.
- `docs/prd.md` – FR-9 Registration requirements; roles and permissions matrix.
- `docs/filament/**` – Reference for Filament panel access control and multi-panel patterns.
- `app/Models/User.php` – Add `HasRoles`, optional `MustVerifyEmail`, and panel access methods.
- `app/Providers/AuthServiceProvider.php` – Register global gates (e.g., Gate::before for approved admins).
- `config/permission.php` – Spatie Permission configuration; used by seeders and authorization checks.
- `routes/web.php` & `routes/auth.php` – Hook up auth routes (Breeze) and verification routes/middleware.
- `resources/views/auth/register.blade.php` – Extend Breeze form to include role selection.
- `database/migrations/0001_01_01_000000_create_users_table.php` – Base users schema; will be amended for admin approval flags.
- `database/migrations/2025_10_23_161958_create_permission_tables.php` – Existing Spatie Permission tables.
- `composer.json` – Add `laravel/breeze` for auth scaffolding; scripts already include test/lint.
- `tests/**` – Add tests for registration, verification, role assignment, and gating.

### New Files
- `database/migrations/20xx_xx_xx_xxxxxx_add_admin_approval_columns_to_users_table.php` – Adds `requires_admin_approval` (bool, default false) and `admin_approved_at` (nullable datetime).
- `database/seeders/RolesAndPermissionsSeeder.php` – Seeds roles `admin`, `lecturer` and base permissions per PRD.
- `app/Console/Commands/ApproveAdmin.php` – Artisan command to approve a pending admin account.
- `routes/auth.php` – Breeze-generated auth routes (login, register, verify, password, etc.).
- `app/Http/Controllers/Auth/RegisteredUserController.php` – Breeze controller override to handle role selection + admin approval flag.

## Implementation Plan
### Phase 1: Foundation
- Install Laravel Breeze (Blade) for auth scaffolding with email verification.
- Add user columns for admin approval and ensure casts/attributes in `User` model.
- Integrate Spatie Permission on `User` with `HasRoles` trait.

### Phase 2: Core Implementation
- Customize registration to include role selection; assign roles and set approval flags accordingly.
- Implement Filament `FilamentUser::canAccessPanel` to enforce verified email, role membership, and admin approval for admin panel.
- Seed roles and base permissions per PRD.

### Phase 3: Integration
- Add Gate::before to grant all permissions to approved admins only.
- Provide an artisan command to approve pending admins; later replaced/supplemented by Filament approval UI.
- Add comprehensive tests that cover registration, verification, role assignment, and access gating.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### Step 1 — Install Breeze and scaffold auth (Blade)
- `composer require laravel/breeze --dev`
- `php artisan breeze:install blade`
- `npm install && npm run build`
- Confirm `routes/auth.php` exists and `email/verify` routes are available.

### Step 2 — Add admin approval columns to users
- Create migration: add `requires_admin_approval` (boolean, default false) and `admin_approved_at` (nullable datetime) to `users`.
- Run `php artisan migrate`.

### Step 3 — Update User model
- Implement `Illuminate\Contracts\Auth\MustVerifyEmail` and ensure email verification middleware is enforced where needed.
- Add `use Spatie\Permission\Traits\HasRoles;` and include the trait.
- Add casts: `requires_admin_approval` (bool), `admin_approved_at` (datetime).
- Add relation stubs for future features (e.g., `offerings()` belongsToMany) only if required by tests.

### Step 4 — Seed roles and permissions
- Create `database/seeders/RolesAndPermissionsSeeder.php`:
  - Roles: `admin`, `lecturer`.
  - Permissions (from PRD): `programme.manage`, `session.manage`, `course.manage`, `offering.manage`, `foldertemplate.manage`, `reminders.manage`, `document.upload`, `document.edit.any`, `document.delete.any`, `report.view`.
  - Attach all permissions to `admin`; attach `document.upload` to `lecturer`.
- Wire seeder in `DatabaseSeeder`.

### Step 5 — Extend registration form and controller
- Update `resources/views/auth/register.blade.php` to include a required radio/select for `role` with options `lecturer` (default) and `admin` (note: admin requires approval).
- Override Breeze `RegisteredUserController@store` to:
  - Validate `role` in [`admin`, `lecturer`].
  - Create user, send email verification notification.
  - If `role === 'admin'`: assign `admin` role and set `requires_admin_approval = true`; else assign `lecturer`.
- Add flash messaging explaining verification required; admin requests will be reviewed.

### Step 6 — Filament user gating
- In `App\Models\User` implement `Filament\Models\Contracts\FilamentUser` and `canAccessPanel(\Filament\Panels\Panel $panel)`:
  - Deny if email is not verified.
  - If `$panel->getId() === 'admin'`: require role `admin` and `requires_admin_approval === false`.
  - If `$panel->getId() === 'lecturer'`: require role `lecturer` (optionally allow admin for parity, per TODO).

### Step 7 — Global gate for approved admins
- In `AuthServiceProvider`, register a `Gate::before` that returns true only when the user has role `admin` AND `requires_admin_approval === false`.
- Keep all other permission checks via Spatie Permission.

### Step 8 — Admin approval command (temporary workflow)
- Add `app/Console/Commands/ApproveAdmin.php`:
  - Signature: `users:approve {user}` (accept ID or email).
  - Sets `requires_admin_approval=false` and `admin_approved_at=now()`. Idempotent.
  - Optionally dispatches a notification to the approved user.

### Step 9 — Tests for registration, roles, and gating
- Registration: role `lecturer` assigns role immediately; role `admin` sets approval required.
- Verification: unverified users cannot access Filament panels via `canAccessPanel`.
- Admin gating: pending admin cannot access admin panel; approved admin can.
- Seeding: roles and permissions exist and attach as expected.
- Gate::before: approved admin bypasses granular checks; pending admin does not.

### Step 10 — Run Validation Commands
- Execute all commands in the Validation Commands section and ensure zero errors.

## Testing Strategy
### Unit Tests
- User model: HasRoles present; casts for approval flags; `canAccessPanel` logic for both panels.
- Seeder: roles and permissions created and attached as expected.
- Approval command: flips flags correctly and is idempotent.

### Integration Tests
- Registration flow (Breeze):
  - Registers lecturer → role assigned, no approval required, verification required for protected access.
  - Registers admin → role assigned, approval required, denied admin access until approved.
- Email verification: accessing a protected route/panel while unverified is denied; after verification, allowed if role/approval criteria met.
- Gate::before behavior with Spatie Permission.

### Edge Cases
- Attempt to register with invalid role value (rejected).
- Attempt to access admin panel as lecturer (denied).
- Admin approval command run on already approved or non-admin user (no-op with clear messaging).
- Duplicate email registration (standard unique error).
- Ensure pending admin cannot circumvent via direct route access (middleware + gating cover).

## Acceptance Criteria
- Breeze auth scaffolding installed with email verification enabled.
- Registration includes role selection; lecturer role immediate, admin role pending approval flag set.
- `users` table contains `requires_admin_approval` and `admin_approved_at` as specified.
- `User` uses `HasRoles` and, if configured, `MustVerifyEmail`.
- Roles `admin` and `lecturer` and base permissions are seeded; approved admin has effective full access via Gate::before.
- `canAccessPanel` enforces: verified email + role membership + admin approval for `admin` panel; lecturer access enforced.
- Artisan command `users:approve` approves pending admin accounts.
- Test suite passes with new unit/integration tests validating all flows.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `composer require laravel/breeze --dev`
- `php artisan breeze:install blade`
- `npm install && npm run build`
- `php artisan migrate:fresh --seed`
- `php artisan route:list | rg -n "login|register|verify"`
- `php artisan tinker` (optional: sanity-check user creation and role assignment)
- `vendor/bin/pint -v --test`
- `vendor/bin/phpstan analyse --memory-limit=1G`
- `php artisan test` - Run tests to validate the feature works with zero regressions

## Notes
- New library: `laravel/breeze` (dev) for lightweight auth scaffolding with Blade; aligns with Laravel 12 and keeps UI simple.
- Email delivery uses current mailer; defaults to log driver unless SMTP configured.
- Filament panels will be implemented/expanded separately; `canAccessPanel` is ready for when panels are added.
- Future: replace the approval command with a Filament “Admin Users approval” page and notifications to existing admins on new admin requests.

