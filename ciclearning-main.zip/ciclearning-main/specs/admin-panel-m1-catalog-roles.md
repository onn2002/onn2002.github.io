# Feature: Admin Panel (M1 — Catalog & Roles)

## Feature Description
Deliver the Admin Panel foundation for managing the application catalog and access control. Admins can CRUD Programmes, Academic Sessions, Courses, Course Offerings (with lecturer assignment), and Folder Templates; manage Roles/Permissions and assign roles to Users; view the Activity Log; and adjust core settings (MIME whitelist, max upload size, and comms overrides). This enables admins to configure the system end-to-end so lecturers can upload against a well-defined catalog with proper RBAC enforcement.

## User Story
As an Administrator
I want to manage catalog entities and roles in a dedicated Admin Panel
So that lecturers can upload to the correct structure and access is enforced

## Problem Statement
Without an administrative UI, catalog setup (programmes, sessions, courses, offerings, folder templates) and role assignment require manual database changes, slowing onboarding and risking configuration errors. The system needs role-based access enforcement and visibility (activity log) to meet MVP goals.

## Solution Statement
Implement Filament Admin Resources and Pages for the catalog and access control, gated by Spatie roles. Provide relationship managers for lecturer assignment to offerings and permission assignment to roles. Add a simple Settings page for operational constraints and comms overrides. Expose an Activity Log list powered by spatie/laravel-activitylog. Seed a minimal demo catalog and users. Authorize all admin resources by `admin` role and granular permissions.

## Relevant Files
Use these files to implement the feature:

- `README.md` – Documents Admin Panel purpose and access; update as needed.
- `docs/TODO.md` – Source for M1 scope; drives resource list and deliverables.
- `docs/prd.md` – PRD acceptance and behaviors for catalog, RBAC, and logging.
- `docs/filament/**` – Filament resource conventions, table/form patterns, panel config.
- `docs/laravel-activitylog/**` – Reference for listing, morph maps, and auditing.
- `docs/laravel-medialibrary/**` – Context for future file-related settings and constraints.
- `app/Providers/Filament/AdminPanelProvider.php` – Registers Admin panel, discovery namespaces, widgets, and middleware.
- `app/Models/*` – Domain models used by resources: `Programme`, `AcademicSession`, `Course`, `CourseOffering`, `FolderTemplate`, `User`, `ReminderSchedule`, and `Document`.
- `app/Enums/Milestone.php` – Enum for milestone select options.
- `config/permission.php` – Spatie Permission configuration (guard `web`).
- `config/activitylog.php` – Morph map and defaults; required by Activity Log resource.
- `database/migrations/**` – Existing schema for catalog and RBAC tables; ensure unique rules align.
- `database/seeders/DatabaseSeeder.php` – Seeds demo program/session/course/offering and users; extend if needed.
- `database/seeders/RolesAndPermissionsSeeder.php` – Seeds roles/permissions used by authorization in Filament.
- `routes/web.php` – Baseline web routes; Filament registers panel routes independently.
- `tests/**` – Add feature tests for Admin resources authorization and basic CRUD flows.

### New Files
- `app/Filament/Admin/Resources/UserResource.php`
  - `app/Filament/Admin/Resources/UserResource/Pages/{ListUsers,CreateUser,EditUser}.php`
  - `app/Filament/Admin/Resources/UserResource/RelationManagers/RolesRelationManager.php` – Assign roles to users.
- `app/Filament/Admin/Resources/RoleResource.php`
  - `app/Filament/Admin/Resources/RoleResource/Pages/{ListRoles,CreateRole,EditRole}.php`
  - `app/Filament/Admin/Resources/RoleResource/RelationManagers/PermissionsRelationManager.php`
- `app/Filament/Admin/Resources/PermissionResource.php`
  - `app/Filament/Admin/Resources/PermissionResource/Pages/ListPermissions.php` – List-only.
- `app/Filament/Admin/Resources/ProgrammeResource.php`
  - `app/Filament/Admin/Resources/ProgrammeResource/Pages/{ListProgrammes,CreateProgramme,EditProgramme}.php`
- `app/Filament/Admin/Resources/AcademicSessionResource.php`
  - `app/Filament/Admin/Resources/AcademicSessionResource/Pages/{ListAcademicSessions,CreateAcademicSession,EditAcademicSession}.php`
- `app/Filament/Admin/Resources/CourseResource.php`
  - `app/Filament/Admin/Resources/CourseResource/Pages/{ListCourses,CreateCourse,EditCourse}.php`
- `app/Filament/Admin/Resources/CourseOfferingResource.php`
  - `app/Filament/Admin/Resources/CourseOfferingResource/Pages/{ListCourseOfferings,CreateCourseOffering,EditCourseOffering}.php`
  - `app/Filament/Admin/Resources/CourseOfferingResource/RelationManagers/LecturersRelationManager.php` – Assign lecturers.
- `app/Filament/Admin/Resources/FolderTemplateResource.php`
  - `app/Filament/Admin/Resources/FolderTemplateResource/Pages/{ListFolderTemplates,CreateFolderTemplate,EditFolderTemplate}.php`
- `app/Filament/Admin/Resources/ActivityLogResource.php`
  - `app/Filament/Admin/Resources/ActivityLogResource/Pages/ListActivityLogs.php`
- `app/Filament/Admin/Pages/Settings.php` – Settings form page (MIME whitelist, max upload size, comms overrides).
- Tests (examples):
  - `tests/Feature/Filament/Admin/AuthorizationTest.php`
  - `tests/Feature/Filament/Admin/ProgrammeResourceTest.php`
  - `tests/Feature/Filament/Admin/CourseOfferingResourceTest.php`

## Implementation Plan
### Phase 1: Foundation
- Authorization & Navigation
  - Gate Admin resources by role and permissions; default to `admin` role only.
  - Group navigation: “Access Control” (Users/Roles/Permissions), “Catalog” (Programmes/Sessions/Courses/Offerings/Templates), “System” (Activity Log, Settings).
- Validation Rules & Constraints
  - Programme: unique `code` (case-insensitive), boolean `active`.
  - AcademicSession: unique `code`; valid `starts_at <= ends_at`.
  - Course: unique `course_code`; `title_slug` auto (disabled field in form).
  - CourseOffering: unique combination `(programme_id, academic_session_id, course_id)`; prevent duplicate lecturers in pivot.
  - FolderTemplate: unique per scope and milestone: `(milestone, programme_id, course_id, slug)`; slug ASCII-only; label required.
- Settings Strategy
  - Provide form inputs backed by config or a settings store. Persist minimally in `.env`/config now; plan migration to a settings table or `spatie/laravel-settings` for production resiliency.

### Phase 2: Core Implementation
- Access Control Resources
  - `UserResource` with basic fields (name, email, verified status read-only) and `RolesRelationManager` (BelongsToMany via Spatie) or a MultiSelect tied to `roles`.
  - `RoleResource` with name, guard fields; `PermissionsRelationManager` to assign permissions.
  - `PermissionResource` list-only with search and filters.
- Catalog Resources
  - `ProgrammeResource` with `code`, `name`, `active`; searchable table; soft-delete support.
  - `AcademicSessionResource` with `code`, `starts_at`, `ends_at`; validate date order.
  - `CourseResource` with `course_code`, `title`, read-only `title_slug` preview; searchable table.
  - `CourseOfferingResource` with Selects for Programme, Session, Course; info panel showing computed `course_identifier`, `programme_code`, `session_code`; `LecturersRelationManager` for assigning users with `lecturer` role.
  - `FolderTemplateResource` with `slug`, `label`, `milestone` (EnumSelect), optional `programme` and `course`; explain scoping in helper text.
- System
  - `ActivityLogResource` list: columns for `log_name`, `description`, `subject_type`, `subject_id`, `causer_type`, `causer_id`, `event`, `properties`, `created_at`; searchable JSON `properties` with truncated preview; filters by `log_name` and date.
  - `Settings` page: inputs for MIME whitelist (array), max upload size (int MB), and optional SMTP/Vonage override toggles with credential fields. Persist minimally in config/env for MVP; store in cache and document restart requirements.

### Phase 3: Integration
- Seed and Wire-Up
  - Ensure `RolesAndPermissionsSeeder` aligns with resource authorization checks.
  - Confirm `DatabaseSeeder` demo data surfaces correctly in resources (demo admin + lecturers, one programme/session/course/offering, templates for each milestone).
- Policies & Permissions
  - Add resource-level `can()` checks mapping to permissions (e.g., `programme.manage`, `course.manage`, `course-offering.assign-lecturer`).
- UX Polish
  - Add nav groups, icons, and sort order; show computed identifiers as badges; add table filters by Programme/Session/Course for offerings.
  - Enable soft-delete filters where applicable.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### Step 1 — Scaffold Access Control Resources
- Create `UserResource` with fields: name, email (unique), email_verified_at (view-only), roles (MultiSelect or RelationManager).
- Create `RolesRelationManager` on `UserResource` using Spatie `roles` relation.
- Create `RoleResource` with name, guard_name; attach `PermissionsRelationManager` for assigning permissions.
- Create `PermissionResource` list-only with search; hide create/edit/delete.
- Add `can()` authorization on each resource to allow only `admin` role (and/or specific permissions).

### Step 2 — Scaffold Catalog Resources
- `ProgrammeResource`: form (code: required|alpha_num|unique; name: required; active: toggle), table with search and soft-delete filter.
- `AcademicSessionResource`: form (code: required|unique; starts_at, ends_at with validation `starts_at <= ends_at`).
- `CourseResource`: form (course_code: required|unique; title: required; title_slug: disabled display), table search on code/title.
- `CourseOfferingResource`: form selects for Programme, Session, Course with validation to enforce unique triplet; show computed `course_identifier` preview; add `LecturersRelationManager` with MultiSelect for lecturers (users having `lecturer` role only); prevent duplicate pivot attaches.
- `FolderTemplateResource`: form with `milestone` EnumSelect (from `Milestone::cases()`), slug (ASCII, unique per scope+milestone), label (required), optional programme/course; server-side validation to enforce composite uniqueness (ignore soft-deleted rows).

### Step 3 — System Pages
- `ActivityLogResource`: list Spatie Activity entries; add filters for date range and `log_name`; searchable `description` and `properties`.
- `Settings` page: fields
  - MIME whitelist: array of strings (e.g., application/pdf, image/png, image/jpeg, application/vnd.openxmlformats-officedocument.wordprocessingml.document).
  - Max upload size (MB): integer min 1.
  - Optional override toggles for SMTP and Vonage WhatsApp keys; fields only when toggled.
  - Persist to config/env for MVP; add TODO to migrate to db-backed settings.

### Step 4 — Authorization Policies & Navigation
- Add per-resource authorization via `->can()` callbacks or policy methods mapping to seeded permissions.
- Configure Filament navigation groups: “Access Control”, “Catalog”, “System”; set sensible icons and order.
- Ensure only admins see Access Control and System groups.

### Step 5 — Seeders and Demo Data
- Verify `RolesAndPermissionsSeeder` includes all permission names used by resources.
- Confirm `DatabaseSeeder` demo records appear in Admin resources; adjust if necessary (e.g., mark demo admin as verified during local development tests).

### Step 6 — Tests
- Add `tests/Feature/Filament/Admin/AuthorizationTest.php`:
  - Admin can list/create/edit each Admin resource route.
  - Lecturer and guests cannot access Admin resources (403/redirect to `/admin/login`).
- Add `tests/Feature/Filament/Admin/ProgrammeResourceTest.php`:
  - Create Programme via model factory; assert unique `code` rule enforced (duplicate rejected).
- Add `tests/Feature/Filament/Admin/CourseOfferingResourceTest.php`:
  - Assert unique triplet `(programme_id, academic_session_id, course_id)`; duplicate offering creation fails.
  - Assign lecturers; duplicate attach throws or is prevented.
- Optionally add `FolderTemplate` uniqueness test for composite key with soft deletes.

### Step 7 — Validation & Docs
- Update `README.md` Filament Panels section to mention Admin resources and their purpose.
- Ensure PRD references are met for M1 deliverables.
- Run full validation commands below.

## Testing Strategy
### Unit Tests
- `Course` model slugging: ensure `title_slug` is generated/updated (already covered, retain).
- Uniqueness rules utilities (if extracted): validate composite uniqueness logic for `FolderTemplate` and `CourseOffering` via model validation/services.

### Integration Tests
- Panel authorization tests: admin vs lecturer vs guest for Admin resource routes.
- CRUD smoke tests on key resources (Programme, Course, Offering) succeeding as admin and failing as lecturer.
- Relation manager tests: assign/remove lecturers to offerings; no duplicate attaches.
- ActivityLog list page loads for admin and includes entries after CRUD actions.

### Edge Cases
- Soft-deleted records do not block unique validations (use `deleted_at IS NULL` constraints in rules).
- CourseOffering cannot be created without all three foreign keys; foreign keys must exist.
- Lecturers relation manager only lists users with `lecturer` role; admins excluded by default.
- FolderTemplate slug normalization (ASCII) and milestone correctness; scoped uniqueness when programme/course are null.
- Guard `web` consistency for Spatie models and Filament auth.

## Acceptance Criteria
- Admin Panel exposes the following under correct nav groups with proper authorization:
  - Access Control: Users (with role assignment), Roles (with permission assignment), Permissions (list-only).
  - Catalog: Programmes, Academic Sessions, Courses, Course Offerings (with lecturers assignment), Folder Templates.
  - System: Activity Log, Settings.
- All CRUD operations persist correctly with validation and soft deletes where applicable.
- CourseOffering uniqueness enforced; lecturer assignment prevents duplicates.
- FolderTemplate uniqueness enforced per scope+milestone; slug ASCII-only.
- Only `admin` users can access Admin resources; lecturers/guests cannot.
- Activity Log lists entries for admin CRUD actions across catalog entities.
- Test suite passes and seeders create demo catalog and users.

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `php artisan config:clear`
- `php artisan migrate:fresh --seed`
- `php artisan route:list | grep filament` – Confirm Admin resource routes are registered
- `composer lint` – Code style must pass
- `composer stan` – Static analysis must pass
- `php artisan test` – Run tests to validate the feature works with zero regressions
- Optional manual: `php artisan serve` and navigate to `/admin` to verify UX

## Notes
- Consider using `spatie/laravel-settings` to persist Settings cleanly; if adopted: `composer require spatie/laravel-settings` and add a Settings class + migration. For MVP, environment/config-backed persistence is acceptable with documentation.
- Follow Filament v4 best practices for resource/manager organization and authorization; avoid custom controllers—keep logic in Resources.
- Ensure activity morph map entries in `config/activitylog.php` stay in sync with new/renamed models.
- Use `Rule::unique(...)->whereNull('deleted_at')` for unique validations on soft-deletable models.

