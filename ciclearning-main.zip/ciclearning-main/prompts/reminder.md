Complete the reminder feature that notifies lecturers about folders where they have not yet uploaded files.

## Goal
Implement and wire up a reminder system that:
- Lets a user configure reminder schedules on the Settings page.
- Uses SMTP settings stored in the `settings` table to send emails.
- Sends both email notifications and database notifications to lecturers.
- Ensures the reminders are sent according to the schedule configured by the user on the Settings page.
- Uses the `reminder_schedules` table as the basis for actual reminder dispatching.

## Context & Scope
- There is an existing Settings page in the application.
- There is a `settings` table that stores SMTP configuration (exact fields and structure should be discovered from the codebase/schema).
- There is a `reminder_schedules` table already present or to be used for storing scheduled reminder records.
- The system has the concept of lecturers and course/folder structures where lecturers upload files.
- Do not change any existing file paths or table names unless already incorrect in the codebase and clearly fixable; if something must change, follow existing patterns and conventions.

The plan should:
- Inspect the existing Settings page implementation to integrate the new UI and backend logic for reminder configuration.
- Inspect existing notification/email infrastructure (if any) to reuse patterns for sending emails and database notifications.
- Inspect how lecturers, programmes, academic sessions, courses, and upload folders are currently modelled and how “uploaded/not uploaded” is currently determined, and build on that.

## Functional Requirements

### 1. Settings Page – Reminder Schedule Configuration
- Extend the Settings page to allow a user to configure reminder schedules for lecturers.
- The configuration must allow:
  - Selecting one or more days of the week (e.g., Monday, Wednesday, Friday).
  - Selecting a time of day (e.g., 9:00 AM).
  - The resulting configuration should express schedules such as: “Every Monday at 9:00 AM”.
- Decide, based on the existing data model, where the reminder configuration is stored:
  - Either in the `settings` table or a related table(s) intended for per-system or per-user settings.
  - Follow existing patterns for saving and retrieving such configuration.
- Validate the input (e.g., at least one day is selected, time is valid).
- Ensure the Settings UI clearly indicates that these settings control when reminders are sent to lecturers about missing uploads.

### 2. SMTP Settings & Email Sending
- Use SMTP configuration from the `settings` table to send reminder emails.
  - Discover the actual fields (e.g., host, port, username, password, encryption, from-address) from the schema or existing email-sending code.
  - Reuse any centralized mail/email service in the application if one exists.
- Ensure that email sending:
  - Fails gracefully if SMTP settings are missing or invalid (e.g., log error, skip sending, or mark as failed in a way that can be retried).
  - Uses appropriate “from” address defined/configured in the system.

### 3. Reminder Logic – What Needs Attention
- Define the logic for determining which folders “still not yet uploaded files” by a lecturer:
  - Reuse existing models/queries, if any, that identify missing uploads or required folders per course.
  - For each lecturer, identify the specific programme, academic session, course, and folders where no files have been uploaded yet.
- This computation will be used both:
  - When deciding which lecturers need reminders.
  - When populating the detailed list of folders in the email notification.

### 4. Command A – Generate Reminder Schedules
- Implement a command (e.g., a console/CLI/cron-invoked command) that:
  - Reads the reminder schedule configuration from the Settings page storage.
  - Determines which lecturers currently need reminders based on missing uploads.
  - Creates records in the `reminder_schedules` table that represent “pending reminders” to be sent for each lecturer.
- Behavioral expectations:
  - The command itself should be triggered according to the recurrence (days of week + time) configured in Settings.
    - For example, an external cron or scheduler may call this command frequently, but the command must check the configured schedule and only populate `reminder_schedules` when it matches the configured day/time.
  - For each lecturer who has at least one folder requiring attention:
    - Create a record (or records, consistent with the existing schema) in `reminder_schedules` that associate:
      - The lecturer.
      - Any necessary context (programme, academic session, course, etc.).
      - The next run time or due time for sending the reminder (if applicable).
  - Avoid creating duplicate pending reminders for the same lecturer and same context; follow a clear strategy:
    - Either check for existing unsent/unprocessed entries in `reminder_schedules` before inserting new ones.
    - Or mark processed entries in such a way that new ones can be distinguished.

### 5. Command B – Dispatch Reminders Every Minute
- Implement another command that is intended to be run every minute by a scheduler.
- This command should:
  - Query the `reminder_schedules` table for all reminder entries that are due to be sent (e.g., based on time/status fields).
  - For each due reminder:
    - Send an email notification to the associated lecturer.
    - Create a database notification for the lecturer.
    - Mark the reminder entry as processed/sent (e.g., update a status/timestamp so it is not resent).
- This command must be idempotent and safe to run every minute:
  - Ensure reminders are not sent multiple times unintentionally.
  - Handle partial failures (e.g., email succeeds but DB notification fails, or vice versa) as gracefully as possible, following existing patterns for error handling and logging.

### 6. Email Notification – Content & Template
- Implement or update an email template for the reminder notification.
- The email body should follow this sample (with dynamic values substituted):

  Hello [User Name],

  The folder in [Programme Name] [Academic session] [Course Name] requires your attention.

  This is a friendly reminder that you have not yet uploaded files to the following folders:
  - /BeginningOfSemester/LessonPlan
  - [Folder 2]
  - [Folder 3]

- Replace placeholders with:
  - [User Name]: The lecturer’s name.
  - [Programme Name]: The relevant programme name.
  - [Academic session]: The academic session tied to the course/folders.
  - [Course Name]: The course in question.
  - Folder list: The list of folder paths where uploads are still missing.
- If multiple courses or folders apply:
  - Follow existing design patterns for aggregating or looping through them (e.g., multiple lines, or multiple sections per course), keeping the email readable.

### 7. Database Notification – Content & Link
- Implement creation of a database notification to the lecturer with content similar to:

  Hello [User Name],

  The folder in [Programme Name] [Academic session] [Course Name] requires your attention.

- The notification must include a link to the page `lecturer/uploads`.
  - Use the existing notification system and models in the codebase (if any) to create this record.
  - Ensure the URL/path `lecturer/uploads` is correctly linked according to routing conventions of the app.
- Ensure that when the lecturer clicks this notification, they are taken to the intended uploads page where they can address the missing folders.

## Non-Functional Requirements & Constraints
- Follow existing project conventions for:
  - Command naming and registration.
  - Timezone handling and date/time persistence (e.g., if the project already uses a specific timezone or UTC).
  - Logging and error handling.
  - Internationalization/localization if present (use existing translation mechanisms where applicable).
- Avoid introducing new dependencies or libraries unless strictly necessary; if unavoidable, they must be justified and consistent with the project’s stack.
- Ensure the feature behaves correctly if:
  - No SMTP settings are configured.
  - No lecturers currently need reminders (commands should exit cleanly).
  - A reminder is due but the lecturer or course/folder has been removed or deactivated.

## Testing Expectations
The plan produced by `plan.md` should include:
- Unit or feature tests that cover:
  - Saving and retrieving reminder schedules from the Settings page.
  - Command A correctly creating entries in `reminder_schedules` at the configured schedule time and only for lecturers with missing uploads.
  - Command B correctly sending email and database notifications based on `reminder_schedules`, and not double-sending.
- Edge cases:
  - Multiple days per week configured.
  - Multiple courses/folders needing reminders for the same lecturer.
  - Missing or invalid SMTP settings.
- Any existing automated test frameworks and patterns in the project should be followed.

## Outcome
When the implementation following this plan is complete:
- An admin/user can configure on the Settings page which days of the week and what time reminders should be sent.
- At the configured schedule, the first command will identify lecturers with missing uploads and create appropriate entries in `reminder_schedules`.
- The second command, running every minute, will:
  - Read due entries from `reminder_schedules`.
  - Send the specified email reminder to each lecturer.
  - Create a database notification that links to `lecturer/uploads`.
  - Mark the schedule entries as processed.
- Lecturers will reliably receive reminders about folders where they have not yet uploaded required files.