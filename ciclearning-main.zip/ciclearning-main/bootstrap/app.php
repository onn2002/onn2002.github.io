<?php

use App\Console\Commands\DispatchDueReminders;
use App\Console\Commands\GenerateReminderSchedules;
use App\Providers\AuthServiceProvider;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withProviders([
        AuthServiceProvider::class,
    ])
    ->withCommands([
        GenerateReminderSchedules::class,
        DispatchDueReminders::class,
    ])
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        //
    })
    ->withSchedule(function (Schedule $schedule): void {
        $schedule->command('reminders:generate-schedules')
            ->hourly()
            ->timezone('Asia/Kuala_Lumpur');

        $schedule->command('reminders:dispatch-due')
            ->everyMinute()
            ->timezone('Asia/Kuala_Lumpur');
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
