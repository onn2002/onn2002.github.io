# ciclearning — Implementation TODO (ordered)

This TODO follows the MVP rollout (M1→M5) and the PRD’s scope, data model, and UX. Two distinct Filament panels—Admin and Lecturer—are created and both authenticate the same `User` model with role‑based access via `spatie/laravel-permission`.

---

## Foundations (M1 — Catalog & Roles)

### Project bootstrap & environment

- [x] Create Laravel app (PHP 8.4) and install core packages:
  - [x] Filament Admin v4 (multi‑panel).
  - [x] `spatie/laravel-permission`, `spatie/laravel-medialibrary`, `spatie/laravel-activitylog`.
  - [x] Configure Laravel Notifications (mail/SMTP, Vonage WhatsApp, database channel).
- [x] `.env` and config:
  - [x] `APP_TIMEZONE=Asia/Kuala_Lumpur`, set app timezone in `config/app.php`; ensure DB, scheduler, and Carbon default to MYT.
  - [x] Mail transport.
  - [x] Vonage credentials for WhatsApp (even if WhatsApp is secondary).
  - [x] Queue connection (e.g., Redis) + Horizon (optional) and storage disk `local`.
- [x] Composer scripts for Pint, PHPStan, Pest/PhpUnit.

### Database & models (domain entities)

- [x] Users
  - [x] Single `users` table + email verification.
  - [x] Seed roles `admin`, `lecturer`; attach granular permissions noted in PRD.
- [x] Programme: `code`, `name`, `active` + indexes.
- [x] AcademicSession: `code`, `starts_at`, `ends_at`.
- [x] Course: `course_code`, `title`, `title_slug` (generated on save).
- [x] CourseOffering: `programme_id`, `session_id`, `course_id` + derived `course_identifier = {course_code}_{title_slug}` (accessor).
  - [x] Pivot `course_offering_user` for many‑to‑many lecturers; unique(user, offering).
- [x] Milestone: PHP `enum` with `BeginningOfSemester | MidTermExamination | FinalExamPackage | EndOfSemester`.
- [x] FolderTemplate: `slug`, `label`, `milestone`, optional `programme_id`, optional `course_id`; unique constraints on scoping + slug.
- [x] ReminderSchedule: scope columns (`programme_id` nullable, `session_id` nullable, `milestone` nullable), `send_at` (MYT), `channels` JSON, `active`, `sent_at` nullable.
- [x] Document (our owner model for Medialibrary) with metadata:
  - [x] Columns: `offering_id`, `milestone`, `folder_slug`, `uploader_id`, `stored_filename`, `original_filename`, `path_string`, `filesize`, `mime`.
  - [x] Integrate Medialibrary so each `Document` holds a single media item (the binary); store our metadata in first‑class columns (not just `custom_properties`).
  - [x] Index `(offering_id, milestone, folder_slug, uploader_id)` for fast completeness.
- [x] Activity Log: install & configure spatie/activitylog with morph mapping; log CRUD + file ops + reminders.
- [x] Soft deletes on catalog, template, document, and reminder tables/models for recoverability.

### Auth, roles & registration

- [ ] Public registration with role self‑selection (radio: `lecturer` or `admin`).
  - [ ] Email verification required (FR‑9).
  - [ ] If `admin` selected: create user as `admin` but flagged `requires_admin_approval`; existing admin approves.
- [ ] Policies & gates:
  - [ ] Enforce permissions in controllers/Filament resources per matrix.

### Filament Panels (single User model; two distinct panels)

- [x] Admin Panel
  - [x] Create `AdminPanelProvider` with slug `admin`, guard `web`, color Blue.
  - [x] In `User implements FilamentUser`, gate `canAccessPanel($panel)` to allow only verified `admin` users.
- [x] Lecturer Panel
  - [x] Create `LecturerPanelProvider` with slug `lecturer`, guard `web`, color Green.
  - [x] `canAccessPanel($panel)` allows verified `lecturer` users; also allow `admin` for parity with permissions matrix (“view own dashboard & uploads”).

---

## Admin Panel (M1 — Catalog & Roles)

- [x] Filament Resources:
  - [x] Roles (CRUD via Spatie package).
  - [x] Permissions (List only).
  - [x] Users (assign roles via relation manager with multi-select).
  - [x] Programmes (CRUD).
  - [x] Academic Sessions (CRUD).
  - [x] Courses (CRUD; auto `title_slug`).
  - [x] Course Offerings (CRUD; computed `course_identifier`; assign lecturers via relation manager with multi-select).
  - [x] Folder Templates (tree management page per milestone with drag-and-drop reordering and nesting).
  - [x] Settings page: MIME whitelist, max upload size (MB), Whatsapp Vonage Configuration (Override), SMTP Mail Configuration (Override).
  - [x] Activity Log (List via Spatie package).
- [x] Seeders: a demo programme/session/course/offering, two lecturers, one admin.

Deliverable: Admin can set up catalog and templates; roles are enforced. (PRD §7 Catalog CRUD, §8 Admin: Catalog).

---

## Shared — Documents, Paths & Services (start in M2, used by both panels)

- [x] Path service: build `{programme_code}/{semester_code}/{course_code_title}/{milestone}/{folder}/`. Example: `DCS/202509/DCS1103_ComputerProgramming/EndOfSemester/AssignmentQuestions/`.
- [x] Renamer service: `{original_base_name_sanitized}_{course_code}_{YYYYMMDD}.{ext}` using MYT date; collision handler appends `_{n}`. Example: `thislsASampleFile_DCS1103_20251113.docx`.
- [x] Sanitizer: strip `\/:*?"<>|`, control chars; collapse whitespace; preserve casing.
- [x] Completeness service:
  - [x] For each `(offering, milestone, folder_slug)`, return ✅ if current user has ≥1 `Document`; ❌ otherwise; also compute aggregate counts (total across all uploaders).
  - [x] Cache by (user, offering, milestone) and bust on upload/move/delete.

---

## Lecturer Panel (M2 — Uploads & Status)

- [ ] Dashboard page with filters: Programme, Session, Course Offering (limited to offerings assigned to the current user), Milestone.
- [ ] Grid of folder tiles from `FolderTemplate` and `FolderTemplateNode` for the selected milestone:
  - [ ] Show ✅/❌ per folder for current lecturer, plus `(You / Total)` counts.
- [ ] Upload UI:
  - [ ] Drag‑and‑drop; validate MIME whitelist (`pdf, doc, docx, xls, xlsx, ppt, pptx, zip`) and max size.
  - [ ] On upload: enforce path structure + server‑side rename via services above; atomic write to disk `local`.
  - [ ] After upload: show stored filename, original filename, full path, upload time, uploader name.
- [ ] File list per folder (for visibility in shared folders): show uploader chips; lecturers can manage their own files (rename/move within offering, replace, delete).
- [ ] Policies ensure lecturers see only offerings assigned to them and only CRUD their own `Document` rows.

Deliverable: Uploads land under enforced folder structure with friendly status UI and per‑lecturer completeness. (PRD §5.1, §6 FR‑2/3/4/10/11).

---

## Admin Ops & Reports (M3)

- [ ] File operations in Admin Panel:
  - [ ] Browse offering → milestone → folder; list all files with uploader and metadata.
  - [ ] Actions: rename, move (change milestone/folder within same offering), replace, delete; all actions log to activitylog and update completeness.
- [ ] Reports → Missing by Lecturer:
  - [ ] Query: for each lecturer, compute ❌ slots grouped by offering → milestone → folder slug; include totals.
  - [ ] Filters (programme, session, course, milestone) and CSV export.

Deliverable: Admin can monitor gaps and edit any upload; CSV export available. (PRD §5.3, §6 FR‑6/12, §12).

---

## Reminders & Notifications (M4)

- [ ] ReminderSchedule resource (Admin Panel):
  - [ ] Create schedule with scope (programme/session and optional milestone), channels (email/whatsapp/db), `send_at` (MYT), `active`.
  - [ ] Preview message with template variables.
- [ ] Scheduler & jobs:
  - [ ] Laravel scheduler every minute in MYT; find schedules where `active = true` and `send_at <= now()` and not yet sent.
  - [ ] Build target set: lecturers with at least one ❌ in scope at send time. Idempotency: `sent_at` or “sent per lecturer per schedule” log.
  - [ ] Dispatch notifications to channels with templates and placeholders:
    `{lecturer_name}`, `{programme_code}`, `{session_code}`, `{course_identifier}`, `{milestone}`, `{missing_folders_list}`, `{dashboard_link}`, `{send_datetime_myt}`.
  - [ ] Email + DB always; WhatsApp via Vonage if configured (keep email primary per risk notes).
- [ ] Optional manual trigger button per schedule (stretch per PRD).

Deliverable: Time‑boxed, one‑off reminders reach only lecturers with ❌. (PRD §6 FR‑5/8, §10, §13).

---

## Polish, Hardening & NFRs (M5)

- [ ] Performance:
  - [ ] Add/confirm indexes on hot paths (completeness, reports).
  - [ ] Eager load relations; paginate heavy lists; cache completeness summaries.
- [ ] Reliability & security:
  - [ ] Atomic writes; collision‑safe renamer; retryable notifications.
  - [ ] CSRF protection, MIME whitelist, max upload size, RBAC at controllers and policies.
- [ ] Accessibility & UX:
  - [ ] Keyboard‑navigable Filament tables; semantic labels; localized dates to MYT.
- [ ] Internationalization: EN only for MVP; ensure date/time formatting aligns with MYT.
- [ ] Activitylog audits validated for create/upload, rename, move, replace, delete, reminder dispatch.
- [ ] Edge cases:
  - [ ] Multiple lecturers per offering (status is per uploader; show You/Total).
  - [ ] Reassignment mid‑semester resets that lecturer’s status.
  - [ ] Moves/renames/deletions update completeness correctly.

---

## Definition of Done — Checklist mapped to PRD (§15)

- [ ] Users register as admin/lecturer; RBAC enforced across pages and actions.
- [ ] Uploads land in enforced path with server‑side rename; invalid combos rejected.
- [ ] Lecturer dashboard shows ❌ until ≥1 file by that lecturer exists; ✅ thereafter.
- [ ] Reminders send at configured MYT, targeting only lecturers with ❌ in scope.
- [ ] Admin report lists missing folders with filters and CSV export.
- [ ] Admin can CRUD catalog (sessions, programmes, courses, offerings).
- [ ] File rows display full path and stored filename.
- [ ] Admin file edits (rename/move/replace/delete) work and are fully audited.

---

## Notes on the two‑panel architecture (single `User` model)

- One `users` table, two Filament panels (`admin`, `lecturer`), guarded by `User::canAccessPanel($panel)` using `spatie/permission` roles. This cleanly satisfies “two distinct panels that both inherit from a single User model.” The Admin Panel focuses on catalog, templates, reminders, reports, and file operations; the Lecturer Panel focuses on uploads and personal progress. Permissions ensure both roles can upload to offerings assigned to them, keeping behavior consistent with the matrix.
