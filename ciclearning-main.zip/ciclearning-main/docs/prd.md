PRD — Course Document Submission System (MVP)

**Application Name:** ciclearning
**Owner:** Product/Engineering
**Tech stack:** Laravel (PHP 8.4), Filament Admin, spatie/laravel‑permission, spatie/laravel‑medialibrary (disk: `local`), spatie/laravel‑activitylog, Laravel Notifications (Email/SMTP, WhatsApp via Vonage, Database)\
**Timezone:** Asia/Kuala_Lumpur (MYT) — all scheduling/UX uses MYT; store timestamps in `Asia/Kuala_Lumpur`

---

## 1) Problem Statement & Goals

Lecturers must submit course documents across fixed folder structures for every programme, semester, course, and milestone. Administrators need visibility into missing uploads and control over reminders.

**Primary goals (MVP):**

- Provide a simple, enforced folder structure and server‑side file renaming.
- Give lecturers a clear checklist with ✅/❌ per required folder.
- Let admins configure sessions, programmes, courses, and reminder times.
- Notify lecturers (email/WhatsApp + in‑app) when items are missing.
- Allow admins to review per‑lecturer gaps and edit/modify uploaded files.
- Ensure complete auditability.

**Non‑goals (MVP):**

- SSO/LDAP, external cloud storage (only local disk).
- Rich file preview/annotation, plagiarism checks, and version diffing.
- Complex workflow approvals.

---

## 2) Users & Roles

- **Lecturer**
  Upload documents into required folders; see personal progress; receive reminders.
- **Administrator**
  Manage catalog (programmes, sessions, courses), define folder templates, schedule reminders, review per‑lecturer status, edit/modify any upload, and audit activity.

RBAC via **spatie/laravel‑permission**:

- Roles: `admin`, `lecturer`
- Example permissions (granular):
  `programme.manage`, `session.manage`, `course.manage`, `offering.manage`, `foldertemplate.manage`, `reminders.manage`, `document.upload`, `document.edit.any`, `document.delete.any`, `report.view`

---

## 3) Scope (MVP)

### In scope

- Registration/login with self‑selection of role (admin/lecturer) and admin approval for `admin`.
- Entity management: Academic Sessions (e.g., 202504, 202509), Programmes (e.g., DCS, DIB), Courses, Course Offerings.
- Folder templates & milestones; ✅/❌ completeness per lecturer.
- Upload UI with enforced **path structure** and **server‑side renaming**.
- Notifications: Email, WhatsApp (Vonage), and in‑app (database).
- Reminder scheduling (admin‑defined send datetime in MYT).
- Admin file operations (rename/move/replace/delete) with audit log.
- Basic reporting: per‑lecturer missing folders.

### Out of scope (MVP)

- Multi‑tenancy, complex recurrence rules, bulk CSV imports, file preview for exotic formats, storage beyond local disk.

---

## 4) Information Architecture & Data Model

### 4.1 Entities

- **Programme**
  - `id`, `code` (e.g., DCS), `name`, `active`
- **AcademicSession**
  - `id`, `code` (e.g., 202509), `starts_at`, `ends_at`
- **Course (catalog)**
  - `id`, `course_code` (e.g., DCS1103), `title`, `title_slug`
- **CourseOffering** (ties everything for a semester)
  - `id`, `programme_id`, `session_id`, `course_id`
  - many‑to‑many **Lecturers** (multiple lecturers per offering)
  - Derived `course_identifier` = `{course_code}_{title_slug}`
- **Milestone** (enum)
  - `BeginningOfSemester` | `MidTermExamination` | `FinalExamPackage` | `EndOfSemester`
- **FolderTemplate**
  - `id`, `slug` (ASCII safe; e.g., `AssignmentQuestions`), `label`
  - assignment table linking **(programme|optional), course|optional, milestone**\
    *MVP simplification*: templates can be global by milestone or scoped by programme/course if needed.
- **Document** (via **spatie/medialibrary** plus our metadata)
  - `id`, `offering_id`, `milestone`, `folder_slug`, `uploader_id`
  - `stored_filename`, `original_filename`, `path_string`, `filesize`, `mime`, timestamps
- **ReminderSchedule**
  - `id`, scope (by `programme_id` and/or `session_id` and optionally `milestone`), `send_at` (stored in `Asia/Kuala_Lumpur`), `channels` (email/whatsapp/db), `active`
- **Activity Log** (spatie/activitylog)
  - actor, action, subject, changes, timestamp

### 4.2 Derived / Display Fields

- **Upload File Path Structure (enforced)**
  ```
  {programme_code}/{semester_code}/{course_identifier}/{milestone}/{folder}/
  ```
  - `course_identifier` = `{course_code}_{course_title_slug}`
  - Sample: `DCS/202509/DCS1103_ComputerProgramming/EndOfSemester/AssignmentQuestions/`

- **Server‑side file naming**
  ```
  {original_base_name_sanitized}_{course_code}_{YYYYMMDD}.{ext}
  ```
  - `YYYYMMDD` uses **MYT** at upload time.
  - Collision in same folder → append `_{n}` before extension.

- **Folder completeness (per lecturer)**
  For each `(offering, milestone, folder_slug)`, ✅ if **that lecturer** has ≥1 `Document` in that slot; otherwise ❌.\
  *Note:* Multiple lecturers can upload to the same underlying folder; status is computed per uploader for fairness and transparency. Admin views can also show **aggregate** counts.

---

## 5) Core User Flows

### 5.1 Lecturer — Upload & Progress

1. Select **Programme → Session → Course Offering** assigned to you.
2. Choose **Milestone** and see required **FolderTemplate** list with ✅/❌.
3. Click a folder → upload files (drag‑and‑drop). Server renames and stores using path rules.
4. See: stored filename, original filename, file path, upload time, and your name as uploader.
5. Dashboard shows overall progress % for the selected offering + milestone.

### 5.2 Admin — Setup

1. Create **Academic Sessions** and **Programmes**.
2. Create **Courses** and **Course Offerings**; assign lecturers.
3. Define **FolderTemplates** by milestone (optionally scoped).
4. Configure **ReminderSchedule**: choose scope, channels, and **send_at** (MYT).
   System dispatches only for lecturers missing items at that moment.

### 5.3 Admin — Monitoring & Editing

1. For each lecturer, open a **Missing Items** report: list of `(offering, milestone, folder_slug)` where ❌.
2. Open any folder: view all files (who uploaded), download, rename/move to another folder, **replace**, or **delete**. All actions audited.

---

## 6) Functional Requirements

**FR‑1 Roles & Auth**

- Registration page allows selecting `lecturer` or `admin`; admin role requires existing admin approval.
- RBAC guards every route/action.

**FR‑2 Folder Structure Enforcement**

- Upload UI only exposes valid combinations for the current lecturer’s offerings.
- Backend validates path components and folder slugs against templates.

**FR‑3 / FR‑4 Folder Status Indicators**

- For the **current lecturer**, list folders with ✅ if ≥1 document uploaded by them, otherwise ❌.
- Hover/expand shows counts per uploader and aggregate totals to reduce confusion in multi‑lecturer scenarios.

**FR‑5 Reminders**

- Admin defines ReminderSchedule with scope and send datetime (MYT).
- System sends notifications via Email, WhatsApp (Vonage), and/or in‑app, using templates with placeholders.
- Only lecturers with ❌ in the targeted scope receive reminders.

**FR‑6 Admin Per‑Lecturer Gap View**

- Report shows missing folders grouped by offering → milestone → folder; export CSV.

**FR‑7 Sessions & Programmes Management**

- CRUD for Academic Sessions (code, dates) and Programmes (code, name).
- CRUD for Courses and Course Offerings; assign lecturers to offerings.

**FR‑8 Reminder Timing Control**

- Each ReminderSchedule includes a single `send_at`.
  *MVP*: one‑time sends; can create multiple schedules for multiple dates.

**FR‑9 Registration**

- Public registration page for both roles; email verification required.
- Admin promotion flow for admin accounts.

**FR‑10 Show File Path**

- For every uploaded file, display the exact path string and stored filename.

**FR‑11 Multiple Lecturers per Course Folder**

- A CourseOffering can have multiple lecturers; both can upload to the same path.
- Status is **per lecturer**; UI also shows aggregate files (by others).

**FR‑12 Admin File Editing**

- Admin can rename, move (change folder slug/milestone within same offering), replace (new binary), or delete.
- All actions recorded in activity log.

---

## 7) Non‑Functional Requirements

- **Performance:** Dashboard and reports remain responsive with 10k+ files and 200+ lecturers (use indexed queries; eager loading).
- **Reliability:** File writes atomic; collision‑safe renaming; retriable notifications.
- **Security:** RBAC on controllers and policies; max upload size & MIME whitelist; server‑side validation; CSRF.
- **Auditability:** All CRUD + file ops logged with actor, subject, diffs, timestamp.
- **Time:** All UI scheduling uses MYT; store in `Asia/Kuala_Lumpur`; Laravel scheduler configured with `->timezone('Asia/Kuala_Lumpur')`.
- **Accessibility:** Keyboard‑navigable Filament tables; semantic labels.
- **Internationalization:** MVP EN; dates localized to MYT.

---

## 8) UI/UX Notes (Filament)

- **Lecturer Dashboard**
  - Filters: Programme, Session, Course Offering, Milestone.
  - Grid of folder tiles: **✅** / **❌**, folder label, uploaded count (you / total).
  - Upload modal: drag‑and‑drop, file list with progress; post‑upload shows stored filename + original filename + path.
- **Admin: Catalog**
  - Filament Resources for Programmes, Sessions, Courses, Offerings (with lecturer assignment).
  - FolderTemplates: table by milestone with slug+label; optional scoping.
- **Admin: Reports**
  - “Missing by Lecturer” table: Lecturer → Offering → Milestone → Folder (❌). Export.
- **Admin: Reminders**
  - Create ReminderSchedule: scope picker, channels, `send_at` (MYT datetime), preview message.

---

## 9) Validation, Renaming & Collisions

**Sanitization rules**

- Remove `\/:*?"<>|` and control chars; trim; collapse whitespace. Preserve original casing.

**Collision handling**

- If `thisIsASampleFile_DCS1103_20251113.docx` exists in the target folder, create `thisIsASampleFile_DCS1103_20251113_2.docx`, then `_3`, etc.

**Example**
Uploaded on 2025‑11‑13 (MYT) to DCS1103:
`thisIsASampleFile.docx` → `thisIsASampleFile_DCS1103_20251113.docx`

---

## 10) Notifications (Email / WhatsApp / In‑App)

**Trigger:** ReminderSchedule at `send_at` or manual admin trigger (optional MVP stretch).

**Target set:** Lecturers with at least one ❌ in the schedule’s scope at send time.

**Template variables:**

- `{lecturer_name}`, `{programme_code}`, `{session_code}`, `{course_identifier}`, `{milestone}`, `{missing_folders_list}`, `{dashboard_link}`, `{send_datetime_myt}`

**Sample (Email & WhatsApp):**

- Subject: `Reminder: Pending documents for {course_identifier} ({milestone})`
- Body:\
  “You still have uploads pending for {milestone}: {missing_folders_list}.
  Path: {programme_code}/{session_code}/{course_identifier}/{milestone}/
  Upload here: {dashboard_link}”

**Vonage constraints:** Use pre‑approved templates where required; handle SMS fallback not included in MVP.

---

## 11) Permissions Matrix (summary)

| Action                                                 | Lecturer | Admin   |
| ------------------------------------------------------ | -------- | ------- |
| View own dashboard & uploads                           | ✅        | ✅       |
| Upload to assigned offerings                           | ✅        | ✅       |
| Edit/rename/move/delete own files                      | ✅ (own)  | ✅ (any) |
| Edit/rename/move/delete any file                       | ❌        | ✅       |
| Manage catalog (programmes/sessions/courses/offerings) | ❌        | ✅       |
| Manage folder templates                                | ❌        | ✅       |
| View per‑lecturer missing report                       | ❌        | ✅       |
| Manage reminders & send                                | ❌        | ✅       |

---

## 12) Reporting

- **Missing by Lecturer**: lecturer → offering → milestone → folder slugs with ❌; totals. CSV export.
- **Upload Summary**: counts per offering/milestone/folder; breakdown by uploader.

---

## 13) Scheduling & Jobs

- **Laravel Scheduler** runs every minute in MYT to scan **ReminderSchedule** where `send_at <= now` and `active = true`.
- A job computes target lecturers (with ❌) and dispatches notifications asynchronously via queues.
- Idempotency: store a `sent_at` per schedule to avoid duplicate sends (or create a “send once per lecturer per schedule” log).

---

## 14) Edge Cases & Constraints

- **Multiple lecturers**: Files from other lecturers appear in the folder file list (tagged by uploader). Status badge for the current lecturer is computed from their own uploads.
- **Reassignment**: If a lecturer is added to an offering mid‑semester, their status starts fresh (even if others uploaded).
- **Moves/Renames**: Moving a file between folders updates completeness for both source and destination.
- **Deletion**: Deleting the only file in a folder can flip ✅ → ❌ for affected lecturers.
- **Large files**: Enforce max file size (configurable); graceful errors with retry.
- **MIME whitelist**: e.g., `pdf, doc, docx, xls, xlsx, ppt, pptx, zip`.

---

## 15) Acceptance Criteria (mapped to requirements)

1. **Multi‑user roles**: Users can register as admin/lecturer; RBAC enforced on pages and actions.
2. **Upload structure**: On upload, system writes to the exact path format; backend rejects invalid combos.
3. **❌ indicator**: Lecturer dashboard shows ❌ for each required folder with zero uploads by that lecturer.
4. **✅ indicator**: Lecturer dashboard shows ✅ when ≥1 file by that lecturer exists in the folder.
5. **Reminders**: At the configured MYT datetime, lecturers with any ❌ receive Email/WhatsApp/DB notifications.
6. **Admin gap view**: Admin report lists missing folders per lecturer with filters and CSV export.
7. **Catalog CRUD**: Admin can create sessions (`202504`, `202509`, …), programmes (`DCS`, `DIB`, …), courses, and offerings.
8. **Reminder timing**: Admin sets a specific date/time (MYT) per schedule; job runs and sends at/after that time.
9. **Registration**: Public registration page supports both roles; admin approval for admin role; email verification.
10. **Show path**: Each file row shows the full path string and stored filename.
11. **Multi‑lecturer uploads**: Both lecturers can upload to the same course folder; per‑lecturer status stays independent.
12. **Admin file edits**: Admin can rename/move/replace/delete any file; all actions audited.

---

## 16) Implementation Notes

- **Medialibrary**: Use a dedicated `Document` model as the “mediaable” owner; store `offering_id`, `milestone`, `folder_slug`, `uploader_id` in custom properties or a first‑class table keyed to media `id`.
- **Stored path**: Configure disk `local` with a base directory; compute subdirectory from the 5‑segment path; ensure directories exist.
- **Renamer**: Build a small service: `(original, course_code, myt_date)` → `stored_filename`; loop to resolve collisions.
- **Policies**:
  - Lecturer can CRUD only their own documents (except move/rename may be limited to own uploads).
  - Admin can CRUD any document.
- **Filtering**: Add DB indexes on `(offering_id, milestone, folder_slug, uploader_id)` to speed completeness queries.
- **Activitylog**: Log create/upload, rename, move, replace, delete, reminder dispatch.

---

## 17) Risks & Mitigations

- **WhatsApp deliverability**: Template approvals and regional constraints — keep email as primary, WhatsApp as secondary.
- **Confusion in shared folders**: Show “uploaded by” chips and split counts (You / Total).
- **Clock drift**: Enforce server timezone and explicit conversion to/from MYT; show absolute datetimes.

---

## 18) Open Questions / Assumptions

- **Folder templates governance**: MVP assumes admin manages templates; if departments vary widely, we may add per‑programme scoping.
- **Lecturer self‑edit**: MVP allows lecturers to edit/rename/move their own uploads within the same offering; confirm if this should be restricted.
- **Reminder recurrence**: MVP is one‑time schedules; recurring rules can be a V2.

---

## 19) Rollout Plan & Milestones

- **M1 (Catalog & Roles)**: RBAC, Programmes, Sessions, Courses, Offerings, Lecturer assignment, FolderTemplates (2 weeks).
- **M2 (Uploads & Status)**: Upload UI, path/rename enforcement, ✅/❌ computation, file list with path (2 weeks).
- **M3 (Admin Ops & Reports)**: Admin edit/move/delete with audit, Missing‑by‑Lecturer report with export (1 week).
- **M4 (Notifications)**: ReminderSchedule + dispatcher, email/WhatsApp/db templates, queueing (1 week).
- **M5 (Polish & Hardening)**: Perf, validation, access controls, UX refinements (1 week).

---

## 20) Appendices

### A) Milestones (enum)

- `BeginningOfSemester`, `MidTermExamination`, `FinalExamPackage`, `EndOfSemester`

### B) Path & Naming (authoritative)

- **Path:** `{programme_code}/{semester_code}/{course_identifier}/{milestone}/{folder}/`
- **Stored filename:** `{original_base_name_sanitized}_{course_code}_{YYYYMMDD}.{ext}`
- **Collision:** append `_{n}`

### C) Minimal API Endpoints (internal, for Filament/DataTables)

- `GET /offerings/{id}/folders?milestone=...` → required folders + status for current user
- `POST /upload` → validates, stores, renames; returns file metadata
- `GET /reports/missing` → per‑lecturer missing list (admin)
- `POST /admin/reminders` → create schedule; job picks up via scheduler

---

### Definition of Done (MVP)

- All acceptance criteria in §15 pass in staging.
- A lecturer can complete an offering’s milestone folders and see 100% ✅.
- An admin can identify gaps for any lecturer and trigger a reminder that is delivered to at least one channel and logged.
- Audit log records all file operations and reminder sends with actor and timestamp.