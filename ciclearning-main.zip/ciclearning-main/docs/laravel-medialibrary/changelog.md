---
title: Changelog
weight: 6
---

All notable changes to laravel-medialibrary are documented [on GitHub](https://github.com/spatie/laravel-medialibrary/blob/master/CHANGELOG.md)
