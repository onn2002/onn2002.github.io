---
title: Upgrading
weight: 5
---

To upgrade Media Library from one major version to the next, read [UPGRADING.md in the laravel-medialibrary repo](https://github.com/spatie/laravel-medialibrary/blob/master/UPGRADING.md).
