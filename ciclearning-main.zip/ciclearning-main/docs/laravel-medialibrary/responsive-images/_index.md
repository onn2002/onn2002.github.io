---
title: Responsive images
weight: 5
---
