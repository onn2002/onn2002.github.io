---
title: Changelog
weight: 6
---

All notable changes to laravel-activitylog are documented [on GitHub](https://github.com/spatie/laravel-activitylog/blob/master/CHANGELOG.md).
