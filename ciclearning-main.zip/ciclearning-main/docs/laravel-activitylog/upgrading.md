---
title: Upgrading
weight: 7
---

Instructions on how to upgrade from an earlier major version of `laravel-activitylog` are available [on GitHub](https://github.com/spatie/laravel-activitylog/blob/master/UPGRADING.md)
