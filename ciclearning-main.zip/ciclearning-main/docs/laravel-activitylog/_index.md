---
title: v4
slogan: Log the activities of your users
githubUrl: https://github.com/spatie/laravel-activitylog
branch: main
---
