---
title: Requirements
weight: 3
---

The activitylog package requires **PHP 7.1+** and **Laravel 5.2 or higher**.

The latest version requires **PHP 8.0+** and **Laravel 8 or higher**.

If you're stuck on older version of the framework take a look at [v3](https://docs.spatie.be/laravel-activitylog/v3), [v2](https://docs.spatie.be/laravel-activitylog/v2) or [v1](https://docs.spatie.be/laravel-activitylog/v2) of this package.
