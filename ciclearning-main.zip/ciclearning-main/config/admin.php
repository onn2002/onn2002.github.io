<?php

return [
    'mime_whitelist' => array_values(array_filter(array_map(
        static fn (string $value): string => trim($value),
        explode(',', (string) env('ADMIN_MIME_WHITELIST', 'application/pdf,image/png,image/jpeg,application/vnd.openxmlformats-officedocument.wordprocessingml.document')),
    ))),

    'max_upload_mb' => (int) env('ADMIN_MAX_UPLOAD_MB', 25),

    'smtp' => [
        'override_enabled' => filter_var(env('ADMIN_SMTP_OVERRIDE_ENABLED', false), FILTER_VALIDATE_BOOL),
        'host' => env('ADMIN_SMTP_HOST'),
        'port' => env('ADMIN_SMTP_PORT'),
        'username' => env('ADMIN_SMTP_USERNAME'),
        'password' => env('ADMIN_SMTP_PASSWORD'),
        'encryption' => env('ADMIN_SMTP_ENCRYPTION', 'tls'),
    ],

    'whatsapp' => [
        'override_enabled' => filter_var(env('ADMIN_WHATSAPP_OVERRIDE_ENABLED', false), FILTER_VALIDATE_BOOL),
        'api_key' => env('ADMIN_WHATSAPP_API_KEY'),
        'api_secret' => env('ADMIN_WHATSAPP_API_SECRET'),
        'from' => env('ADMIN_WHATSAPP_FROM'),
    ],

    'reminders' => [
        'days' => array_values(array_filter(array_map(
            static fn (string $value): string => strtolower(trim($value)),
            explode(',', (string) env('ADMIN_REMINDER_DAYS', 'monday,tuesday,wednesday,thursday,friday')),
        ))),
        'time' => (string) env('ADMIN_REMINDER_TIME', '09:00'),
        'channels' => array_values(array_filter(array_map(
            static fn (string $value): string => strtolower(trim($value)),
            explode(',', (string) env('ADMIN_REMINDER_CHANNELS', 'mail,database')),
        ))),
    ],
];
