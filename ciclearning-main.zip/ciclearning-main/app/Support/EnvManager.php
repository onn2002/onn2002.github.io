<?php

namespace App\Support;

use Illuminate\Filesystem\Filesystem;

class EnvManager
{
    public function __construct(
        protected Filesystem $files,
    ) {}

    /**
     * @param  array<string, mixed>  $values
     */
    public function set(array $values): void
    {
        $path = base_path('.env');

        if (! $this->files->exists($path)) {
            $this->files->put($path, '');
        }

        $lines = preg_split('/\r?\n/', (string) $this->files->get($path));

        if ($lines === false) {
            $lines = [];
        }

        $indexByKey = [];

        foreach ($lines as $index => $line) {
            if (str_starts_with((string) $line, '#')) {
                continue;
            }

            if (! str_contains((string) $line, '=')) {
                continue;
            }

            [$key] = explode('=', (string) $line, 2);
            $indexByKey[$key] = $index;
        }

        foreach ($values as $key => $value) {
            $formattedValue = $this->formatValue($value);
            $line = sprintf('%s=%s', $key, $formattedValue);

            if (array_key_exists($key, $indexByKey)) {
                $lines[$indexByKey[$key]] = $line;
            } else {
                $lines[] = $line;
            }
        }

        $contents = implode(PHP_EOL, array_filter($lines, fn ($line) => $line !== null));

        if (! str_ends_with($contents, PHP_EOL)) {
            $contents .= PHP_EOL;
        }

        $this->files->put($path, $contents);
    }

    protected function formatValue(mixed $value): string
    {
        if ($value === null) {
            return 'null';
        }

        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }

        if (is_array($value)) {
            $value = implode(',', array_map(static fn (mixed $item): string => (string) $item, $value));
        }

        $value = (string) $value;

        if ($value === '') {
            return "''";
        }

        $needsQuotes = strpbrk($value, " #=\r\n\t") !== false;

        if ($needsQuotes) {
            $escaped = str_replace('"', '\"', $value);

            return "\"{$escaped}\"";
        }

        return $value;
    }
}
