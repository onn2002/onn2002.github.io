<?php

namespace App\Support;

class FilenameSanitizer
{
    private const DEFAULT_NAME = 'file';

    public function sanitize(string $name): string
    {
        $withoutControls = preg_replace('/[\x00-\x1F\x7F]+/u', '', $name) ?? '';

        $stripped = str_replace(
            ['\\', '/', ':', '*', '?', '"', '<', '>', '|'],
            '',
            $withoutControls
        );

        $collapsed = preg_replace('/\s+/u', ' ', $stripped) ?? '';
        $clean = trim($collapsed);

        if ($clean === '') {
            return self::DEFAULT_NAME;
        }

        return $clean;
    }
}
