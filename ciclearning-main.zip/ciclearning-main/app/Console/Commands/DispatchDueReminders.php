<?php

namespace App\Console\Commands;

use App\Models\ReminderSchedule;
use App\Notifications\MissingUploadsReminderNotification;
use App\Services\ReminderMailConfigService;
use App\Services\ReminderTargetingService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Throwable;

class DispatchDueReminders extends Command
{
    protected $signature = 'reminders:dispatch-due {--schedule-id=* : Limit dispatch to specific schedule IDs}';

    protected $description = 'Dispatch reminders for due reminder schedules.';

    public function handle(
        ReminderTargetingService $targetingService,
        ReminderMailConfigService $mailConfigService,
    ): int {
        $reference = now(config('app.timezone'));
        $scheduleIds = array_filter((array) $this->option('schedule-id'));

        $query = ReminderSchedule::due($reference);

        if ($scheduleIds !== []) {
            $query->whereIn('id', $scheduleIds);
        }

        $schedules = $query->get();

        if ($schedules->isEmpty()) {
            $this->info('No due reminder schedules found.');

            return self::SUCCESS;
        }

        foreach ($schedules as $schedule) {
            $this->line(sprintf(
                'Processing schedule #%d for %s',
                $schedule->getKey(),
                $schedule->send_at?->toDateTimeString() ?? 'unknown'
            ));

            $targets = $targetingService->buildTargets(
                $schedule->programme_id,
                $schedule->academic_session_id,
                $schedule->milestone
            );

            if ($targets->isEmpty()) {
                $this->line('No lecturers with missing uploads. Marking schedule as sent.');
                $this->markScheduleSent($schedule, $reference);
                continue;
            }

            try {
                $mailConfigService->applyOverrideForReminders(function () use ($targets, $schedule): void {
                    foreach ($targets as $target) {
                        $target['lecturer']->notify(
                            new MissingUploadsReminderNotification($schedule, $target['items'], $schedule->channels ?? [])
                        );
                    }
                });
            } catch (Throwable $exception) {
                $this->error(sprintf(
                    'Failed to dispatch reminders for schedule #%d: %s',
                    $schedule->getKey(),
                    $exception->getMessage()
                ));

                report($exception);

                continue;
            }

            activity()
                ->performedOn($schedule)
                ->withProperties([
                    'lecturers' => $targets->count(),
                    'schedule_id' => $schedule->getKey(),
                ])
                ->log('reminder_dispatched');

            $this->line(sprintf('Notified %d lecturer(s).', $targets->count()));
            $this->markScheduleSent($schedule, $reference);
        }

        return self::SUCCESS;
    }

    protected function markScheduleSent(ReminderSchedule $schedule, Carbon $reference): void
    {
        $schedule->forceFill([
            'sent_at' => $reference,
            'active' => false,
        ])->save();
    }
}
