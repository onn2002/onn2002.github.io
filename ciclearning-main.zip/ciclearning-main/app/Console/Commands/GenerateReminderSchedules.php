<?php

namespace App\Console\Commands;

use App\Models\ReminderSchedule;
use App\Services\SettingsService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class GenerateReminderSchedules extends Command
{
    protected $signature = 'reminders:generate-schedules
        {--dry-run : Show which schedules would be created without persisting}
        {--days=14 : Number of days ahead to generate schedules for}';

    protected $description = 'Generate reminder schedule entries based on configured recurrence.';

    public function handle(SettingsService $settingsService): int
    {
        $recurrence = $settingsService->reminderRecurrence();
        $daysOfWeek = array_map('strtolower', $recurrence['days']);
        $timeOfDay = $recurrence['time'];
        $channels = $recurrence['channels'] ?? ['mail', 'database'];
        $dryRun = (bool) $this->option('dry-run');
        $lookaheadDays = max(1, (int) $this->option('days'));

        $now = now(config('app.timezone'));
        $cursor = $now->copy()->startOfDay();
        $limitDate = $cursor->copy()->addDays($lookaheadDays);

        $created = 0;

        while ($cursor->lte($limitDate)) {
            $dayName = strtolower($cursor->englishDayOfWeek);

            if (! in_array($dayName, $daysOfWeek, true)) {
                $cursor->addDay();
                continue;
            }

            $sendAt = $this->buildSendAt($cursor, $timeOfDay);

            if ($sendAt->lt($now)) {
                $cursor->addDay();
                continue;
            }

            $exists = ReminderSchedule::query()
                ->scopedTo(null, null, null)
                ->whereBetween('send_at', [
                    $sendAt->copy()->startOfMinute(),
                    $sendAt->copy()->endOfMinute(),
                ])
                ->exists();

            if ($exists) {
                $cursor->addDay();
                continue;
            }

            if ($dryRun) {
                $this->line(sprintf('[DRY RUN] Would create schedule for %s', $sendAt->toDateTimeString()));
            } else {
                ReminderSchedule::query()->create([
                    'programme_id' => null,
                    'academic_session_id' => null,
                    'milestone' => null,
                    'send_at' => $sendAt,
                    'channels' => $channels,
                    'active' => true,
                    'sent_at' => null,
                ]);
            }

            $created++;
            $cursor->addDay();
        }

        $this->info(
            $dryRun
                ? sprintf('Dry run complete. %d schedule(s) would be created.', $created)
                : sprintf('%d schedule(s) created for configured reminder slots.', $created)
        );

        return self::SUCCESS;
    }

    protected function buildSendAt(Carbon $day, string $timeOfDay): Carbon
    {
        [$hour, $minute] = explode(':', $timeOfDay) + [0, 0];

        return $day->copy()->setTime((int) $hour, (int) $minute, 0);
    }
}
