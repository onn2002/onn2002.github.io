<?php

namespace App\Providers;

use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplate;
use App\Models\Programme;
use App\Models\User;
use App\Policies\AcademicSessionPolicy;
use App\Policies\ActivityLogPolicy;
use App\Policies\CourseOfferingPolicy;
use App\Policies\CoursePolicy;
use App\Policies\DocumentPolicy;
use App\Policies\FolderTemplatePolicy;
use App\Policies\PermissionPolicy;
use App\Policies\ProgrammePolicy;
use App\Policies\RolePolicy;
use App\Policies\UserPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        AcademicSession::class => AcademicSessionPolicy::class,
        Activity::class => ActivityLogPolicy::class,
        Course::class => CoursePolicy::class,
        CourseOffering::class => CourseOfferingPolicy::class,
        Document::class => DocumentPolicy::class,
        FolderTemplate::class => FolderTemplatePolicy::class,
        Permission::class => PermissionPolicy::class,
        Programme::class => ProgrammePolicy::class,
        Role::class => RolePolicy::class,
        User::class => UserPolicy::class,
    ];

    /**
     * Bootstrap any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();
    }
}
