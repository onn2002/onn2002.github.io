<?php

namespace App\Policies;

use App\Models\Document;
use App\Models\User;

class DocumentPolicy
{
    public function before(User $user, string $ability): ?bool
    {
        if ($user->hasRole('admin')) {
            return true;
        }

        return null;
    }

    public function viewAny(User $user): bool
    {
        return $user->hasRole('lecturer');
    }

    public function view(User $user, Document $document): bool
    {
        return (int) $document->uploader_id === (int) $user->getKey();
    }

    public function create(User $user): bool
    {
        return $user->hasRole('lecturer');
    }

    public function update(User $user, Document $document): bool
    {
        return $this->view($user, $document);
    }

    public function delete(User $user, Document $document): bool
    {
        return $this->view($user, $document);
    }

    public function restore(User $user, Document $document): bool
    {
        return $this->view($user, $document);
    }

    public function forceDelete(User $user, Document $document): bool
    {
        return $user->hasRole('admin');
    }
}
