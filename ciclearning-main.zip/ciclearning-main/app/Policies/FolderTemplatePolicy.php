<?php

namespace App\Policies;

use App\Models\FolderTemplate;
use App\Models\User;

class FolderTemplatePolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return $user->can('folder-template.manage');
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, FolderTemplate $folderTemplate): bool
    {
        return $user->can('folder-template.manage');
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return $user->can('folder-template.manage');
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, FolderTemplate $folderTemplate): bool
    {
        return $user->can('folder-template.manage');
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, FolderTemplate $folderTemplate): bool
    {
        return $user->can('folder-template.manage');
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, FolderTemplate $folderTemplate): bool
    {
        return $user->can('folder-template.manage');
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, FolderTemplate $folderTemplate): bool
    {
        return $user->can('folder-template.manage');
    }
}
