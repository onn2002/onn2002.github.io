<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class CourseOffering extends Model
{
    /** @use HasFactory<\Database\Factories\CourseOfferingFactory> */
    use HasFactory;

    use LogsActivity;
    use SoftDeletes;

    protected $fillable = [
        'programme_id',
        'academic_session_id',
        'course_id',
    ];

    public function programme(): BelongsTo
    {
        return $this->belongsTo(Programme::class);
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(AcademicSession::class, 'academic_session_id');
    }

    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class);
    }

    public function lecturers(): BelongsToMany
    {
        return $this->belongsToMany(User::class)
            ->withTimestamps();
    }

    public function documents(): HasMany
    {
        return $this->hasMany(Document::class, 'offering_id');
    }

    public function scopeAssignedTo(Builder $query, User $user): Builder
    {
        return $query->whereHas(
            'lecturers',
            fn (Builder $relation) => $relation->whereKey($user->getKey())
        );
    }

    protected function courseIdentifier(): Attribute
    {
        return Attribute::make(
            get: fn (): ?string => $this->course
                ? implode('_', array_filter([
                    $this->course->course_code,
                    $this->course->title_slug,
                ]))
                : null,
        );
    }

    protected function programmeCode(): Attribute
    {
        return Attribute::make(
            get: fn (): ?string => $this->programme?->code,
        );
    }

    protected function sessionCode(): Attribute
    {
        return Attribute::make(
            get: fn (): ?string => $this->session?->code,
        );
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logFillable()
            ->useLogName('course_offerings');
    }
}
