<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Course extends Model
{
    /** @use HasFactory<\Database\Factories\CourseFactory> */
    use HasFactory;

    use LogsActivity;
    use SoftDeletes;

    protected $fillable = [
        'course_code',
        'title',
        'title_slug',
    ];

    public function courseOfferings(): HasMany
    {
        return $this->hasMany(CourseOffering::class);
    }

    public function folderTemplates(): HasMany
    {
        return $this->hasMany(FolderTemplate::class);
    }

    protected static function booted(): void
    {
        static::saving(function (self $course): void {
            if (filled($course->title) && $course->isDirty('title')) {
                $course->title_slug = Str::slug($course->title);
            }

            if (blank($course->title_slug) && filled($course->title)) {
                $course->title_slug = Str::slug($course->title);
            }
        });
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logFillable()
            ->useLogName('courses');
    }
}
