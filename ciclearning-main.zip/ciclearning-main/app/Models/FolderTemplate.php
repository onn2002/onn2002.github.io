<?php

namespace App\Models;

use App\Enums\Milestone;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class FolderTemplate extends Model
{
    /** @use HasFactory<\Database\Factories\FolderTemplateFactory> */
    use HasFactory;

    use LogsActivity;
    use SoftDeletes;

    protected $fillable = [
        'slug',
        'label',
        'milestone',
    ];

    protected $casts = [
        'milestone' => Milestone::class,
    ];

    /**
     * All nodes attached to this template.
     */
    public function nodes(): HasMany
    {
        return $this->hasMany(FolderTemplateNode::class)
            ->orderBy('depth')
            ->orderBy('position');
    }

    /**
     * Root-level nodes (depth === 1).
     */
    public function rootNodes(): HasMany
    {
        return $this->nodes()
            ->whereNull('parent_id')
            ->orderBy('position');
    }

    /**
     * Leaf nodes (no children).
     */
    public function leafNodes(): HasMany
    {
        return $this->nodes()
            ->whereDoesntHave('children')
            ->orderBy('path_cache');
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logFillable()
            ->logOnlyDirty()
            ->useLogName('folder_templates');
    }
}
