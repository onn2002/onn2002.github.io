<?php

namespace App\Models;

use App\Enums\Milestone;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Carbon;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class ReminderSchedule extends Model
{
    /** @use HasFactory<\Database\Factories\ReminderScheduleFactory> */
    use HasFactory;

    use LogsActivity;
    use SoftDeletes;

    protected $fillable = [
        'programme_id',
        'academic_session_id',
        'milestone',
        'send_at',
        'channels',
        'active',
        'sent_at',
    ];

    protected $casts = [
        'milestone' => Milestone::class,
        'send_at' => 'datetime',
        'sent_at' => 'datetime',
        'channels' => 'array',
        'active' => 'boolean',
    ];

    protected $attributes = [
        'channels' => '[]',
    ];

    public function programme(): BelongsTo
    {
        return $this->belongsTo(Programme::class);
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(AcademicSession::class, 'academic_session_id');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('active', true);
    }

    public function scopeDue(Builder $query, ?Carbon $reference = null): Builder
    {
        $reference ??= now(config('app.timezone'));

        return $query
            ->active()
            ->whereNull('sent_at')
            ->where('send_at', '<=', $reference);
    }

    public function scopeScopedTo(
        Builder $query,
        ?int $programmeId,
        ?int $academicSessionId,
        ?Milestone $milestone = null,
    ): Builder {
        return $query
            ->when($programmeId, fn (Builder $q) => $q->where('programme_id', $programmeId))
            ->when($academicSessionId, fn (Builder $q) => $q->where('academic_session_id', $academicSessionId))
            ->when($milestone, fn (Builder $q) => $q->where('milestone', $milestone));
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logFillable()
            ->useLogName('reminder_schedules');
    }
}
