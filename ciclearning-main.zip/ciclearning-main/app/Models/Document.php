<?php

namespace App\Models;

use App\Enums\Milestone;
use App\Services\CompletenessService;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class Document extends Model implements HasMedia
{
    /** @use HasFactory<\Database\Factories\DocumentFactory> */
    use HasFactory;

    use InteractsWithMedia;
    use LogsActivity;
    use SoftDeletes;

    public const MEDIA_COLLECTION = 'document';

    protected $fillable = [
        'offering_id',
        'milestone',
        'folder_slug',
        'uploader_id',
        'stored_filename',
        'original_filename',
        'path_string',
        'filesize',
        'mime',
    ];

    protected $casts = [
        'milestone' => Milestone::class,
        'filesize' => 'int',
    ];

    protected static function booted(): void
    {
        static::saved(function (self $document): void {
            $document->syncMediaMetadata(
                $document->getFirstMedia(self::MEDIA_COLLECTION)
            );
        });

        static::created(function (self $document): void {
            $document->invalidateCurrentCompletenessCache();
        });

        static::updated(function (self $document): void {
            if ($document->wasChanged(['offering_id', 'milestone', 'folder_slug', 'uploader_id'])) {
                $document->invalidateOriginalCompletenessCache();
                $document->invalidateCurrentCompletenessCache();
            }
        });

        static::deleted(function (self $document): void {
            $document->invalidateOriginalCompletenessCache();
        });

        static::restored(function (self $document): void {
            $document->invalidateCurrentCompletenessCache();
        });
    }

    public function offering(): BelongsTo
    {
        return $this->belongsTo(CourseOffering::class, 'offering_id');
    }

    public function uploader(): BelongsTo
    {
        return $this->belongsTo(User::class, 'uploader_id');
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection(self::MEDIA_COLLECTION)
            ->singleFile();
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logFillable()
            ->useLogName('documents');
    }

    public function refreshMediaMetadata(): void
    {
        $this->syncMediaMetadata(
            $this->getFirstMedia(self::MEDIA_COLLECTION)
        );
    }

    public function folderPath(): string
    {
        return $this->folder_slug;
    }

    public function folderPathSegments(): array
    {
        return array_values(array_filter(explode('/', $this->folder_slug)));
    }

    private function invalidateCurrentCompletenessCache(): void
    {
        self::invalidateCompletenessCache(
            $this->offering_id,
            $this->milestone instanceof Milestone ? $this->milestone : null,
            $this->uploader_id
        );
    }

    private function invalidateOriginalCompletenessCache(): void
    {
        $milestone = $this->getOriginal('milestone');
        $milestoneEnum = $milestone instanceof Milestone
            ? $milestone
            : (is_string($milestone) ? Milestone::tryFrom($milestone) : null);

        self::invalidateCompletenessCache(
            $this->getOriginal('offering_id'),
            $milestoneEnum,
            $this->getOriginal('uploader_id')
        );
    }

    protected function syncMediaMetadata(?Media $media): void
    {
        if (! $media) {
            return;
        }

        $originalName = $media->getAttribute('name');
        $extension = pathinfo($media->file_name, PATHINFO_EXTENSION);

        if ($originalName && $extension) {
            $originalName .= '.'.$extension;
        } elseif (! $originalName) {
            $originalName = $media->file_name;
        }

        $attributes = [
            'stored_filename' => $media->file_name,
            'original_filename' => $originalName,
            'path_string' => $media->getPathRelativeToRoot(),
            'filesize' => $media->size,
            'mime' => $media->mime_type,
        ];

        $changes = collect($attributes)
            ->filter(fn ($value, $key) => $this->getAttribute($key) !== $value);

        if ($changes->isEmpty()) {
            return;
        }

        $this->forceFill($attributes);
        $this->saveQuietly();
    }

    private static function invalidateCompletenessCache(?int $offeringId, ?Milestone $milestone, ?int $uploaderId): void
    {
        if (! $offeringId || ! $milestone || ! $uploaderId) {
            return;
        }

        $offering = CourseOffering::query()->find($offeringId);
        $user = User::query()->find($uploaderId);

        if (! $offering || ! $user) {
            return;
        }

        app(CompletenessService::class)->invalidate($user, $offering, $milestone);
    }
}
