<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class FolderTemplateNode extends Model
{
    /** @use HasFactory<\Database\Factories\FolderTemplateNodeFactory> */
    use HasFactory;

    use LogsActivity;
    use SoftDeletes;

    public const MAX_DEPTH = 3;

    protected $fillable = [
        'folder_template_id',
        'parent_id',
        'slug',
        'label',
        'required',
        'depth',
        'position',
        'path_cache',
    ];

    protected $casts = [
        'depth' => 'int',
        'position' => 'int',
        'required' => 'bool',
    ];

    protected $attributes = [
        'required' => true,
    ];

    protected static function booted(): void
    {
        static::saving(function (self $node): void {
            $node->slug = $node->generateSlug();
            $node->label = trim($node->label);

            $node->depth = $node->resolveDepth();
            $node->guardMaxDepth();

            if ($node->position === null) {
                $node->position = $node->nextPosition();
            }

            $node->path_cache = $node->buildPathCache();

            if ($node->exists) {
                $node->guardDescendantDepth();
            }
        });

        static::saved(function (self $node): void {
            $node->refreshDescendants();
        });
    }

    public function folderTemplate(): BelongsTo
    {
        return $this->belongsTo(FolderTemplate::class);
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('position');
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logFillable()
            ->logOnlyDirty()
            ->useLogName('folder_template_nodes');
    }

    public function pathSegments(): array
    {
        return explode('/', $this->path_cache);
    }

    public function pathString(): string
    {
        return $this->path_cache;
    }

    public function isLeaf(): bool
    {
        return ! $this->children()->exists();
    }

    public function scopeOrdered(Builder $query): Builder
    {
        return $query
            ->orderBy('depth')
            ->orderBy('position');
    }

    protected function generateSlug(): string
    {
        $candidate = $this->slug ?: $this->label;
        $slug = Str::of($candidate ?? '')
            ->title()
            ->replaceMatches('/[^A-Za-z0-9]/', '')
            ->toString();

        if ($slug === '') {
            throw ValidationException::withMessages([
                'slug' => 'Slug must contain alphanumeric characters.',
            ]);
        }

        return $slug;
    }

    protected function resolveDepth(): int
    {
        $parentDepth = 0;
        if ($this->parent_id) {
            $parent = $this->parent()->withoutGlobalScopes()->first();

            if (! $parent) {
                throw ValidationException::withMessages([
                    'parent_id' => 'Parent node is invalid or no longer exists.',
                ]);
            }

            $parentDepth = $parent->depth;
        }

        return $parentDepth + 1;
    }

    protected function guardMaxDepth(): void
    {
        if ($this->depth > self::MAX_DEPTH) {
            throw ValidationException::withMessages([
                'parent_id' => sprintf(
                    'Cannot place node beyond maximum depth of %d.',
                    self::MAX_DEPTH
                ),
            ]);
        }
    }

    protected function guardDescendantDepth(): void
    {
        $maxLevels = $this->subtreeLevels();
        $projectedMax = $this->depth + ($maxLevels - 1);

        if ($projectedMax > self::MAX_DEPTH) {
            throw ValidationException::withMessages([
                'parent_id' => sprintf(
                    'Moving this branch would exceed the maximum depth of %d.',
                    self::MAX_DEPTH
                ),
            ]);
        }
    }

    protected function buildPathCache(): string
    {
        $slug = $this->slug;

        if ($this->parent_id) {
            $parentPath = $this->parent()
                ->withoutGlobalScopes()
                ->value('path_cache');

            if (! $parentPath) {
                throw ValidationException::withMessages([
                    'parent_id' => 'Unable to resolve parent path.',
                ]);
            }

            return $parentPath.'/'.$slug;
        }

        return $slug;
    }

    protected function nextPosition(): int
    {
        $query = static::query()
            ->where('folder_template_id', $this->folder_template_id)
            ->where('parent_id', $this->parent_id);

        $maxPosition = $query->max('position');

        return $maxPosition === null ? 0 : $maxPosition + 1;
    }

    protected function subtreeLevels(): int
    {
        $max = 1;

        $children = $this->children()->get();

        foreach ($children as $child) {
            $max = max($max, 1 + $child->subtreeLevels());
        }

        return $max;
    }

    protected function refreshDescendants(): void
    {
        $children = $this->children()->get();

        foreach ($children as $index => $child) {
            $updates = [
                'depth' => $this->depth + 1,
                'path_cache' => $this->path_cache.'/'.$child->slug,
            ];

            if ($child->position !== $index) {
                $updates['position'] = $index;
            }

            $child->forceFill($updates);
            $child->saveQuietly();
            $child->refreshDescendants();
        }
    }
}
