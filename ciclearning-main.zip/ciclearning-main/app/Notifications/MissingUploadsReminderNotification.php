<?php

namespace App\Notifications;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\ReminderSchedule;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Filament\Actions\Action;
use Filament\Notifications\Notification as FilamentNotification;

class MissingUploadsReminderNotification extends Notification
{
    use Queueable;

    /**
     * @param  array<int, array{
     *     offering: CourseOffering,
     *     milestone: Milestone,
     *     missing_folders: array<int, string>
     * }>  $items
     * @param  array<int, string>  $channels
     */
    public function __construct(
        protected ReminderSchedule $schedule,
        protected array $items,
        protected array $channels = ['mail', 'database'],
    ) {
        $this->channels = ['mail'];
    }

    /**
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return $this->channels;
    }

    public function toMail(object $notifiable): MailMessage
    {
        $message = (new MailMessage())
            ->subject($this->mailSubject())
            ->greeting(sprintf('Hello %s,', $notifiable->name ?? 'Lecturer'))
            ->line($this->mailIntroLine());

        $multipleItems = count($this->items) > 1;

        if ($multipleItems) {
            collect($this->items)
                ->map(fn (array $item): string => $this->courseContext($item['offering']))
                ->unique()
                ->each(fn (string $context) => $message->line(sprintf('%s', $context)));
        }

        foreach ($this->items as $item) {
            $message->line($item['milestone']->label());

            foreach ($item['missing_folders'] as $folder) {
                $message->line(sprintf('- %s', $folder));
            }

            $message->line('');
        }

        return $message
            ->line('Please upload the necessary files at your earliest convenience.')
            ->action('Open Lecturer uploads dashboard', $this->reminderUrl());
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return $this->databasePayload();
    }

    /**
     * @return array<string, mixed>
     */
    public function toDatabase(object $notifiable): array
    {
        return $this->databasePayload();
    }

    protected function mailSubject(): string
    {
        if (count($this->items) === 1) {
            $item = $this->items[0];

            return sprintf(
                'Reminder: Pending documents for %s (%s)',
                $this->courseDisplay($item['offering']),
                $item['milestone']->label()
            );
        }

        return 'Reminder: Pending documents across your courses';
    }

    protected function mailIntroLine(): string
    {
        if (count($this->items) === 1) {
            $item = $this->items[0];

            return sprintf(
                'This is a friendly reminder for %s that you have not yet uploaded files to the following folders:',
                $this->courseContext($item['offering'])
            );
        }

        return 'This is a friendly reminder that you have not yet uploaded files to the following folders:';
    }

    protected function reminderUrl(): string
    {
        return route('filament.lecturer.pages.uploads');
    }

    protected function courseDisplay(CourseOffering $offering): string
    {
        $code = $offering->course?->course_code;
        $title = $offering->course?->title;

        return $code && $title ? "{$code} {$title}" : ($title ?? ($code ?? 'Course'));
    }

    protected function courseContext(CourseOffering $offering): string
    {
        return trim(sprintf(
            '%s %s %s',
            $offering->programme?->name ?? 'Programme',
            $offering->session?->code ?? 'Session',
            $this->courseDisplay($offering)
        ));
    }

    /**
     * @return array<string, mixed>
     */
    protected function databasePayload(): array
    {
        $notification = FilamentNotification::make()
            ->title($this->databaseTitle())
            ->body($this->databaseBody())
            ->actions([
                Action::make('open')
                    ->button()
                    ->markAsRead()
                    ->url($this->reminderUrl()),
            ])
            ->icon('heroicon-o-exclamation-triangle')
            ->iconColor('warning');

        return [
            ...$notification->getDatabaseMessage(),
            'schedule_id' => $this->schedule->getKey(),
            'items' => $this->formattedItems(),
            'url' => $this->reminderUrl(),
        ];
    }

    protected function databaseTitle(): string
    {
        $grouped = collect($this->items)
            ->groupBy(fn (array $item): int|string|null => $item['offering']->getKey());

        if ($grouped->count() === 1) {
            $first = $grouped->first()->first();
            $offering = $first['offering'];

            return sprintf(
                'Reminder for %s %s',
                $this->courseDisplay($offering),
                $offering->session?->code ?? 'Session'
            );
        }

        return 'Reminder for multiple courses';
    }

    protected function databaseBody(): string
    {
        $grouped = collect($this->items)
            ->groupBy(fn (array $item): int|string|null => $item['offering']->getKey());
        $groupedCount = $grouped->count();

        $body = $grouped
            ->map(function ($itemsByOffering) use ($groupedCount): string {
                $first = $itemsByOffering->first();
                $offering = $first['offering'];
                $courseAndSession = sprintf(
                    '%s %s',
                    $this->courseDisplay($offering),
                    $offering->session?->code ?? 'Session'
                );

                $sections = collect($itemsByOffering)->map(function (array $item): string {
                    $folders = collect($item['missing_folders'])
                        ->map(fn (string $folder): string => sprintf('- %s', $folder))
                        ->implode("\n");

                    return sprintf(
                        "%s:\n%s",
                        $item['milestone']->label(),
                        $folders
                    );
                })->implode("\n\n");

                if ($groupedCount === 1) {
                    return $sections;
                }

                return sprintf(
                    "%s\n%s",
                    $courseAndSession,
                    $sections
                );
            })
            ->implode("\n\n\n");

        return str_replace("\n", '<br>', $body);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    protected function formattedItems(): array
    {
        return array_map(
            function (array $item): array {
                return [
                    'programme' => $item['offering']->programme?->name,
                    'programme_code' => $item['offering']->programme?->code,
                    'session' => $item['offering']->session?->code,
                    'course' => $item['offering']->course?->title,
                    'course_identifier' => $item['offering']->course_identifier,
                    'milestone' => $item['milestone']->value,
                    'milestone_label' => $item['milestone']->label(),
                    'missing_folders' => $item['missing_folders'],
                ];
            },
            $this->items
        );
    }
}
