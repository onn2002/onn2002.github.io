<?php

namespace App\Filament\Lecturer\Pages;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\User;
use BackedEnum;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Collection as SupportCollection;
use Livewire\Attributes\Computed;

class UploadsDashboard extends Page
{
    protected static BackedEnum|string|null $navigationIcon = Heroicon::OutlinedArrowUpTray;

    protected static ?string $navigationLabel = 'Documents Management';

    protected static ?string $slug = 'uploads';

    protected static ?string $title = 'Documents Management';

    protected string $view = 'filament.lecturer.pages.uploads-dashboard';

    public ?int $selectedProgrammeId = null;

    public ?int $selectedSessionId = null;

    public ?int $selectedOfferingId = null;

    public ?string $selectedMilestone = null;

    public ?int $currentUserId = null;

    public array $programmeOptions = [];

    public array $sessionOptions = [];

    public array $offeringOptions = [];

    public array $milestoneOptions = [];

    protected ?SupportCollection $availableOfferings = null;

    public static function canAccess(): bool
    {
        $user = auth()->user();

        if (! $user instanceof User) {
            return false;
        }

        return $user->hasAnyRole(['lecturer', 'admin']);
    }

    public static function shouldRegisterNavigation(): bool
    {
        return static::canAccess();
    }

    public function mount(): void
    {
        /** @var User|null $user */
        $user = auth()->user();

        if (! $user) {
            abort(403);
        }

        $this->currentUserId = (int) $user->getKey();
        $this->availableOfferings = $this->loadOfferings($user);

        $this->milestoneOptions = collect(Milestone::cases())
            ->map(fn (Milestone $milestone) => [
                'value' => $milestone->value,
                'label' => $milestone->label(),
            ])
            ->values()
            ->all();

        $this->programmeOptions = $this->buildProgrammeOptions();
        $this->selectedProgrammeId = $this->resolveSelection($this->programmeOptions);

        $this->sessionOptions = $this->buildSessionOptions();
        $this->selectedSessionId = $this->resolveSelection($this->sessionOptions);

        $this->offeringOptions = $this->buildOfferingOptions();
        $this->selectedOfferingId = $this->resolveSelection($this->offeringOptions);

        $this->selectedMilestone ??= $this->milestoneOptions[0]['value'] ?? null;
    }

    public function updatedSelectedProgrammeId($value): void
    {
        $this->selectedProgrammeId = $this->normaliseNullableInt($value);

        $this->sessionOptions = $this->buildSessionOptions();
        $this->selectedSessionId = $this->resolveSelection($this->sessionOptions, $this->selectedSessionId);

        $this->offeringOptions = $this->buildOfferingOptions();
        $this->selectedOfferingId = $this->resolveSelection($this->offeringOptions);

        $this->resetFolderContext();
    }

    public function updatedSelectedSessionId($value): void
    {
        $this->selectedSessionId = $this->normaliseNullableInt($value);

        $this->offeringOptions = $this->buildOfferingOptions();
        $this->selectedOfferingId = $this->resolveSelection($this->offeringOptions, $this->selectedOfferingId);

        $this->resetFolderContext();
    }

    public function updatedSelectedOfferingId($value): void
    {
        $this->selectedOfferingId = $this->normaliseNullableInt($value);

        if (! $this->isValueInOptions($this->offeringOptions, $this->selectedOfferingId)) {
            $this->selectedOfferingId = $this->resolveSelection($this->offeringOptions);
        }

        $this->resetFolderContext();
    }

    public function updatedSelectedMilestone(?string $value): void
    {
        if (! $this->isMilestoneValue($value)) {
            $this->selectedMilestone = $this->milestoneOptions[0]['value'] ?? null;
        } else {
            $this->selectedMilestone = $value;
        }

        $this->resetFolderContext();
    }

    #[Computed]
    public function hasOfferings(): bool
    {
        return $this->offerings()->isNotEmpty();
    }

    #[Computed]
    public function selectedOffering(): ?CourseOffering
    {
        if (! $this->selectedOfferingId) {
            return null;
        }

        return $this->offerings()
            ->firstWhere('id', $this->selectedOfferingId);
    }

    #[Computed]
    public function selectedMilestoneEnum(): ?Milestone
    {
        return Milestone::tryFrom($this->selectedMilestone ?? '');
    }

    private function loadOfferings(User $user): SupportCollection
    {
        $query = CourseOffering::query()
            ->with(['programme', 'session', 'course'])
            ->orderBy('programme_id')
            ->orderBy('academic_session_id')
            ->orderBy('course_id');

        if (! $user->hasRole('admin')) {
            $query->assignedTo($user);
        }

        return $query->get();
    }

    private function offerings(): SupportCollection
    {
        if ($this->availableOfferings instanceof SupportCollection) {
            return $this->availableOfferings;
        }

        $user = auth()->user();

        if ($user instanceof User) {
            $this->availableOfferings = $this->loadOfferings($user);

            return $this->availableOfferings;
        }

        $this->availableOfferings = collect();

        return $this->availableOfferings;
    }

    private function buildProgrammeOptions(): array
    {
        return $this->offerings()
            ->filter(fn (CourseOffering $offering) => $offering->programme_id !== null)
            ->unique('programme_id')
            ->sortBy(fn (CourseOffering $offering) => $offering->programme?->code ?? '')
            ->map(fn (CourseOffering $offering) => [
                'value' => $offering->programme_id,
                'label' => $offering->programme?->code ?? sprintf('Programme %d', $offering->programme_id),
            ])
            ->values()
            ->all();
    }

    private function buildSessionOptions(): array
    {
        return $this->offeringsFilteredByProgramme()
            ->filter(fn (CourseOffering $offering) => $offering->academic_session_id !== null)
            ->unique('academic_session_id')
            ->sortBy(fn (CourseOffering $offering) => $offering->session?->code ?? '')
            ->map(fn (CourseOffering $offering) => [
                'value' => $offering->academic_session_id,
                'label' => $offering->session?->code ?? sprintf('Session %d', $offering->academic_session_id),
            ])
            ->values()
            ->all();
    }

    private function buildOfferingOptions(): array
    {
        return $this->offeringsFilteredByProgramme()
            ->filter(fn (CourseOffering $offering) => $this->selectedSessionId === null
                || $offering->academic_session_id === $this->selectedSessionId)
            ->map(function (CourseOffering $offering): array {
                $code = $offering->course?->course_code ?? sprintf('Course %d', $offering->course_id);
                $title = $offering->course?->title ?? null;

                return [
                    'value' => $offering->getKey(),
                    'label' => trim($code.(($title ? ' — '.$title : ''))),
                ];
            })
            ->sortBy('label')
            ->values()
            ->all();
    }

    private function offeringsFilteredByProgramme(): SupportCollection
    {
        if (! $this->selectedProgrammeId) {
            return $this->offerings();
        }

        if (! $this->isValueInOptions($this->programmeOptions, $this->selectedProgrammeId)) {
            return collect();
        }

        return $this->offerings()
            ->where('programme_id', $this->selectedProgrammeId);
    }

    private function resolveSelection(array $options, ?int $preferred = null): ?int
    {
        if ($preferred !== null && $this->isValueInOptions($options, $preferred)) {
            return $preferred;
        }

        $first = $options[0]['value'] ?? null;

        if ($first === null) {
            return null;
        }

        return (int) $first;
    }

    private function isValueInOptions(array $options, ?int $value): bool
    {
        if ($value === null) {
            return false;
        }

        foreach ($options as $option) {
            if ((int) ($option['value'] ?? 0) === $value) {
                return true;
            }
        }

        return false;
    }

    private function normaliseNullableInt(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_numeric($value)) {
            return (int) $value;
        }

        return null;
    }

    private function isMilestoneValue(?string $value): bool
    {
        return collect($this->milestoneOptions)
            ->contains(fn (array $option) => $option['value'] === $value);
    }

    private function resetFolderContext(): void
    {
        $this->dispatch('open-files', slug: null);
        $this->dispatch('close-upload-modal');
    }
}
