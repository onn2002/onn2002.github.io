<?php

namespace App\Filament\Lecturer\Resources\Documents\Pages;

use App\Filament\Lecturer\Resources\Documents\DocumentResource;
use Filament\Resources\Pages\ListRecords;

class ListDocuments extends ListRecords
{
    protected static string $resource = DocumentResource::class;

    protected function getHeaderActions(): array
    {
        return [];
    }

    public function getHeading(): string
    {
        return 'Documents';
    }

    public function getSubheading(): ?string
    {
        return 'Search and manage the documents you have uploaded.';
    }
}
