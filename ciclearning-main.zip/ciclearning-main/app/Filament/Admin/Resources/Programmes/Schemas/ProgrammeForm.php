<?php

namespace App\Filament\Admin\Resources\Programmes\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;
use Illuminate\Validation\Rules\Unique;

class ProgrammeForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->columns(2)
            ->components([
                TextInput::make('code')
                    ->label('Code')
                    ->required()
                    ->maxLength(10)
                    ->alphaDash()
                    ->dehydrateStateUsing(fn (?string $state): ?string => filled($state) ? mb_strtoupper($state) : null)
                    ->unique(
                        table: 'programmes',
                        column: 'code',
                        ignoreRecord: true,
                        modifyRuleUsing: fn (Unique $rule): Unique => $rule->whereNull('deleted_at'),
                    ),
                TextInput::make('name')
                    ->label('Name')
                    ->required()
                    ->maxLength(255),
            ]);
    }
}
