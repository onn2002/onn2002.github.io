<?php

namespace App\Filament\Admin\Resources\Programmes\Pages;

use App\Filament\Admin\Resources\Programmes\ProgrammeResource;
use Filament\Resources\Pages\CreateRecord;

class CreateProgramme extends CreateRecord
{
    protected static string $resource = ProgrammeResource::class;
}
