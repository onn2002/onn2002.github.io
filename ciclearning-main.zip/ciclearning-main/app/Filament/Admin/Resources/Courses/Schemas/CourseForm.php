<?php

namespace App\Filament\Admin\Resources\Courses\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;
use Illuminate\Validation\Rules\Unique;

class CourseForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->columns(2)
            ->components([
                TextInput::make('course_code')
                    ->label('Course code')
                    ->required()
                    ->maxLength(20)
                    ->alphaDash()
                    ->dehydrateStateUsing(fn (?string $state): ?string => filled($state) ? mb_strtoupper($state) : null)
                    ->unique(
                        table: 'courses',
                        column: 'course_code',
                        ignoreRecord: true,
                        modifyRuleUsing: fn (Unique $rule): Unique => $rule->whereNull('deleted_at'),
                    ),
                TextInput::make('title')
                    ->label('Title')
                    ->required()
                    ->maxLength(255),
            ]);
    }
}
