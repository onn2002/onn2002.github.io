<?php

namespace App\Filament\Admin\Resources\Permissions\Schemas;

use Filament\Schemas\Schema;

class PermissionForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
