<?php

namespace App\Filament\Admin\Resources\AcademicSessions\Schemas;

use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;
use Illuminate\Validation\Rules\Unique;

class AcademicSessionForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->columns(3)
            ->components([
                TextInput::make('code')
                    ->label('Code')
                    ->required()
                    ->maxLength(20)
                    ->dehydrateStateUsing(fn (?string $state): ?string => filled($state) ? mb_strtoupper($state) : null)
                    ->unique(
                        table: 'academic_sessions',
                        column: 'code',
                        ignoreRecord: true,
                        modifyRuleUsing: fn (Unique $rule): Unique => $rule->whereNull('deleted_at'),
                    ),
                DatePicker::make('starts_at')
                    ->label('Starts on')
                    ->required()
                    ->displayFormat('Y-m-d')
                    ->native(false),
                DatePicker::make('ends_at')
                    ->label('Ends on')
                    ->required()
                    ->displayFormat('Y-m-d')
                    ->native(false)
                    ->afterOrEqual('starts_at'),
            ]);
    }
}
