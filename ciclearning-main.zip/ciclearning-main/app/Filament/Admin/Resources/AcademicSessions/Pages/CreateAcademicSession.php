<?php

namespace App\Filament\Admin\Resources\AcademicSessions\Pages;

use App\Filament\Admin\Resources\AcademicSessions\AcademicSessionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateAcademicSession extends CreateRecord
{
    protected static string $resource = AcademicSessionResource::class;
}
