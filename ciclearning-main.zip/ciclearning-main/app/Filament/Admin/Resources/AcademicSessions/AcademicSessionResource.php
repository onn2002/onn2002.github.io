<?php

namespace App\Filament\Admin\Resources\AcademicSessions;

use App\Filament\Admin\Resources\AcademicSessions\Pages\CreateAcademicSession;
use App\Filament\Admin\Resources\AcademicSessions\Pages\EditAcademicSession;
use App\Filament\Admin\Resources\AcademicSessions\Pages\ListAcademicSessions;
use App\Filament\Admin\Resources\AcademicSessions\Schemas\AcademicSessionForm;
use App\Filament\Admin\Resources\AcademicSessions\Tables\AcademicSessionsTable;
use App\Models\AcademicSession;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use UnitEnum;

class AcademicSessionResource extends Resource
{
    protected static ?string $model = AcademicSession::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCalendarDays;

    protected static UnitEnum|string|null $navigationGroup = 'Catalog';

    protected static ?int $navigationSort = 20;

    protected static ?string $recordTitleAttribute = 'code';

    public static function shouldRegisterNavigation(): bool
    {
        return auth()->check() && static::canViewAny();
    }

    public static function form(Schema $schema): Schema
    {
        return AcademicSessionForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return AcademicSessionsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListAcademicSessions::route('/'),
            'create' => CreateAcademicSession::route('/create'),
            'edit' => EditAcademicSession::route('/{record}/edit'),
        ];
    }

    public static function getRecordRouteBindingEloquentQuery(): Builder
    {
        return parent::getRecordRouteBindingEloquentQuery()
            ->withoutGlobalScopes([
                SoftDeletingScope::class,
            ]);
    }
}
