<?php

namespace App\Filament\Admin\Resources\Documents\Tables;

use App\Enums\Milestone;
use App\Models\AcademicSession;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\Programme;
use App\Services\DocumentOperationsService;
use Filament\Actions\Action;
use Filament\Actions\DeleteAction;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Arr;
use Illuminate\Support\Number;
use Illuminate\Validation\ValidationException;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;

class DocumentsTable
{
    public static function configure(Table $table, bool $showLecturerColumn = true): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query): Builder => $query
                ->with([
                    'offering.programme',
                    'offering.session',
                    'offering.course',
                    'uploader',
                ])
                ->latest('created_at'))
            ->columns(self::columns(showLecturerColumn: $showLecturerColumn))
            ->filters([
                SelectFilter::make('uploader_id')
                    ->label('Lecturer')
                    ->relationship('uploader', 'name')
                    ->searchable(),
                SelectFilter::make('programme_id')
                    ->label('Programme')
                    ->options(fn (): array => self::programmeOptions())
                    ->searchable()
                    ->query(function (Builder $query, array $data): Builder {
                        $programmeId = $data['value'] ?? null;

                        return $query->when(
                            $programmeId,
                            fn (Builder $query) => $query->whereHas(
                                'offering',
                                fn (Builder $relation) => $relation->where('programme_id', $programmeId)
                            )
                        );
                    }),
                SelectFilter::make('academic_session_id')
                    ->label('Session')
                    ->options(fn (): array => self::sessionOptions())
                    ->searchable()
                    ->query(function (Builder $query, array $data): Builder {
                        $sessionId = $data['value'] ?? null;

                        return $query->when(
                            $sessionId,
                            fn (Builder $query) => $query->whereHas(
                                'offering',
                                fn (Builder $relation) => $relation->where('academic_session_id', $sessionId)
                            )
                        );
                    }),
                SelectFilter::make('course_id')
                    ->label('Course')
                    ->options(fn (): array => self::courseOptions())
                    ->searchable()
                    ->query(function (Builder $query, array $data): Builder {
                        $courseId = $data['value'] ?? null;

                        return $query->when(
                            $courseId,
                            fn (Builder $query) => $query->whereHas(
                                'offering',
                                fn (Builder $relation) => $relation->where('course_id', $courseId)
                            )
                        );
                    }),
                SelectFilter::make('offering_id')
                    ->label('Course offering')
                    ->options(fn (): array => self::offeringOptions())
                    ->searchable()
                    ->query(function (Builder $query, array $data): Builder {
                        $offeringId = $data['value'] ?? null;

                        return $query->when(
                            $offeringId,
                            fn (Builder $query) => $query->where('offering_id', $offeringId)
                        );
                    }),
                SelectFilter::make('milestone')
                    ->label('Milestone')
                    ->options(fn (): array => collect(Milestone::cases())
                        ->mapWithKeys(fn (Milestone $milestone) => [$milestone->value => $milestone->label()])
                        ->toArray()),
                Filter::make('folder')
                    ->form([
                        TextInput::make('folder_slug')
                            ->label('Folder slug')
                            ->placeholder('e.g. /assignments/week-1'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        $folder = trim((string) ($data['folder_slug'] ?? ''));

                        if ($folder === '') {
                            return $query;
                        }

                        return $query->where('folder_slug', 'like', sprintf('%%%s%%', $folder));
                    }),
                Filter::make('created_between')
                    ->label('Uploaded between')
                    ->form([
                        DatePicker::make('from')
                            ->label('From')
                            ->native(false),
                        DatePicker::make('until')
                            ->label('Until')
                            ->native(false),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when($data['from'] ?? null, fn (Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date))
                            ->when($data['until'] ?? null, fn (Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date));
                    }),
                SelectFilter::make('mime')
                    ->label('MIME type')
                    ->options(fn (): array => self::mimeOptions())
                    ->searchable(),
            ])
            ->recordActions([
                Action::make('replace')
                    ->label('Replace')
                    ->modalHeading('Replace document')
                    ->modalButton('Upload replacement')
                    ->authorize(fn (Document $record): bool => auth()->user()?->can('update', $record) ?? false)
                    ->form([
                        self::replacementFileUpload(),
                    ])
                    ->action(function (Document $record, array $data): void {
                        $file = self::normalizeUploadedFile($data['file'] ?? null);

                        if (! $file) {
                            Notification::make()
                                ->title('Upload required')
                                ->body('Select a replacement file before continuing.')
                                ->danger()
                                ->send();

                            return;
                        }

                        try {
                            app(DocumentOperationsService::class)->replace($record, $file);
                        } catch (ValidationException $exception) {
                            Notification::make()
                                ->title('Unable to replace document')
                                ->body(self::validationMessage($exception))
                                ->danger()
                                ->send();

                            throw $exception;
                        }

                        $record->refresh();

                        Notification::make()
                            ->title('Document replaced')
                            ->body('The file was replaced successfully and metadata has been updated.')
                            ->success()
                            ->send();
                    }),
                DeleteAction::make('delete')
                    ->label('Delete')
                    ->modalHeading('Delete document')
                    ->modalDescription('This removes the stored file and archives the document record.')
                    ->authorize(fn (Document $record): bool => auth()->user()?->can('delete', $record) ?? false)
                    ->action(function (Document $record): void {
                        try {
                            app(DocumentOperationsService::class)->delete($record);
                        } catch (ValidationException $exception) {
                            Notification::make()
                                ->title('Unable to delete document')
                                ->body(self::validationMessage($exception))
                                ->danger()
                                ->send();

                            throw $exception;
                        }

                        Notification::make()
                            ->title('Document deleted')
                            ->body('The document has been archived and removed from storage.')
                            ->success()
                            ->send();
                    }),
            ])
            ->toolbarActions([]);
    }

    private static function columns(bool $showLecturerColumn = true): array
    {
        return array_values(array_filter([
            $showLecturerColumn
                ? TextColumn::make('uploader.name')
                    ->label('Lecturer')
                    ->badge()
                    ->sortable()
                    ->searchable()
                : null,
            TextColumn::make('offering.programme.code')
                ->label('Programme')
                ->sortable()
                ->searchable(),
            TextColumn::make('offering.session.code')
                ->label('Session')
                ->sortable()
                ->searchable(),
            TextColumn::make('offering.course.course_code')
                ->label('Course code')
                ->sortable()
                ->searchable(),
            TextColumn::make('offering.course.title')
                ->label('Course title')
                ->sortable()
                ->searchable()
                ->limit(40)
                ->wrap(),
            TextColumn::make('milestone')
                ->label('Milestone')
                ->badge()
                ->formatStateUsing(fn (mixed $state): ?string => self::resolveMilestoneLabel($state))
                ->sortable(),
            TextColumn::make('folder_slug')
                ->label('Folder')
                ->wrap()
                ->toggleable(isToggledHiddenByDefault: true),
            TextColumn::make('stored_filename')
                ->label('Stored name')
                ->copyable()
                ->wrap()
                ->searchable(),
            TextColumn::make('original_filename')
                ->label('Original name')
                ->wrap()
                ->searchable(),
            TextColumn::make('path_string')
                ->label('Storage path')
                ->copyable()
                ->wrap()
                ->toggleable(isToggledHiddenByDefault: true),
            TextColumn::make('mime')
                ->label('MIME')
                ->badge()
                ->toggleable(isToggledHiddenByDefault: true),
            TextColumn::make('filesize')
                ->label('Size')
                ->formatStateUsing(fn (mixed $state): ?string => self::formatFilesize($state))
                ->toggleable(isToggledHiddenByDefault: true),
            TextColumn::make('created_at')
                ->label('Uploaded at')
                ->dateTime()
                ->sortable(),
        ]));
    }

    private static function replaceUploadRules(FileUpload $upload): FileUpload
    {
        $upload->required()
            ->maxSize(self::maxUploadKilobytes());

        $mimeTypes = self::allowedMimeTypes();

        if ($mimeTypes !== []) {
            $upload->acceptedFileTypes($mimeTypes);
        }

        return $upload;
    }

    private static function replacementFileUpload(): FileUpload
    {
        return self::replaceUploadRules(
            FileUpload::make('file')
                ->label('Replacement file')
                ->storeFiles(false)
        );
    }

    private static function normalizeUploadedFile(mixed $value): ?UploadedFile
    {
        $value = Arr::first(Arr::wrap($value), fn ($item) => filled($item));

        if (is_string($value) && TemporaryUploadedFile::canUnserialize($value)) {
            $value = TemporaryUploadedFile::unserializeFromLivewireRequest($value);
            $value = Arr::first(Arr::wrap($value), fn ($item) => filled($item));
        }

        if ($value instanceof TemporaryUploadedFile) {
            return $value;
        }

        if ($value instanceof UploadedFile) {
            return $value;
        }

        return null;
    }

    private static function formatFilesize(mixed $state): ?string
    {
        if ($state === null) {
            return null;
        }

        $size = is_numeric($state) ? (int) $state : null;

        if (! $size) {
            return null;
        }

        return Number::fileSize($size);
    }

    private static function resolveMilestoneLabel(mixed $state): ?string
    {
        if ($state instanceof Milestone) {
            return $state->label();
        }

        if (is_string($state)) {
            return Milestone::tryFrom($state)?->label();
        }

        return null;
    }

    private static function allowedMimeTypes(): array
    {
        return array_values(array_filter((array) config('admin.mime_whitelist', [])));
    }

    private static function maxUploadKilobytes(): int
    {
        $maxMb = (int) config('admin.max_upload_mb', 25);

        return max($maxMb, 1) * 1024;
    }

    private static function programmeOptions(): array
    {
        return Programme::query()
            ->orderBy('code')
            ->pluck('code', 'id')
            ->toArray();
    }

    private static function sessionOptions(): array
    {
        return AcademicSession::query()
            ->orderBy('code')
            ->pluck('code', 'id')
            ->toArray();
    }

    private static function courseOptions(): array
    {
        return Course::query()
            ->orderBy('course_code')
            ->pluck('course_code', 'id')
            ->toArray();
    }

    private static function offeringOptions(): array
    {
        return CourseOffering::query()
            ->with(['programme', 'session', 'course'])
            ->orderByDesc('created_at')
            ->get()
            ->mapWithKeys(function (CourseOffering $offering): array {
                $label = implode(' · ', array_filter([
                    $offering->programme?->code,
                    $offering->session?->code,
                    $offering->course?->course_code,
                ]));

                return [
                    $offering->getKey() => $label !== '' ? $label : 'Offering #'.$offering->getKey(),
                ];
            })
            ->toArray();
    }

    private static function mimeOptions(): array
    {
        return Document::query()
            ->whereNotNull('mime')
            ->distinct()
            ->orderBy('mime')
            ->pluck('mime', 'mime')
            ->toArray();
    }

    private static function validationMessage(ValidationException $exception): string
    {
        return collect($exception->errors())
            ->flatten()
            ->implode(' ') ?: 'Please review the highlighted fields.';
    }
}
