<?php

namespace App\Filament\Admin\Resources\CourseOfferings\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ForceDeleteAction;
use Filament\Actions\ForceDeleteBulkAction;
use Filament\Actions\RestoreAction;
use Filament\Actions\RestoreBulkAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TrashedFilter;
use Filament\Tables\Table;

class CourseOfferingsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                TextColumn::make('programme.code')
                    ->label('Programme')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('session.code')
                    ->label('Session')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('course.course_code')
                    ->label('Course code')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('course.title')
                    ->label('Course title')
                    ->searchable()
                    ->limit(40),
                TextColumn::make('lecturers_count')
                    ->label('Lecturers')
                    ->sortable()
                    ->badge(),
                TextColumn::make('created_at')
                    ->label('Created')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('programme_id')
                    ->label('Programme')
                    ->relationship('programme', 'name')
                    ->searchable(),
                SelectFilter::make('academic_session_id')
                    ->label('Academic session')
                    ->relationship('session', 'code')
                    ->searchable(),
                SelectFilter::make('course_id')
                    ->label('Course')
                    ->relationship('course', 'title')
                    ->searchable(),
                TrashedFilter::make(),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
                RestoreAction::make(),
                ForceDeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                    RestoreBulkAction::make(),
                    ForceDeleteBulkAction::make(),
                ]),
            ]);
    }
}
