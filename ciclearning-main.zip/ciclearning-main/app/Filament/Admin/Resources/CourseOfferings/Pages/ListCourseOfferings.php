<?php

namespace App\Filament\Admin\Resources\CourseOfferings\Pages;

use App\Filament\Admin\Resources\CourseOfferings\CourseOfferingResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListCourseOfferings extends ListRecords
{
    protected static string $resource = CourseOfferingResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}
