<?php

namespace App\Filament\Admin\Resources\CourseOfferings\Schemas;

use App\Models\CourseOffering;
use Filament\Forms\Components\Select;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;
use Illuminate\Validation\Rule;

class CourseOfferingForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->columns(3)
            ->components([
                Select::make('programme_id')
                    ->label('Programme')
                    ->relationship('programme', 'name')
                    ->required()
                    ->searchable()
                    ->preload()
                    ->live(),
                Select::make('academic_session_id')
                    ->label('Academic session')
                    ->relationship('session', 'code')
                    ->required()
                    ->searchable()
                    ->preload()
                    ->live(),
                Select::make('course_id')
                    ->label('Course')
                    ->relationship('course', 'title')
                    ->required()
                    ->searchable()
                    ->preload()
                    ->live()
                    ->rule(function (Get $get, ?CourseOffering $record) {
                        $programmeId = $get('programme_id');
                        $sessionId = $get('academic_session_id');

                        if (! $programmeId || ! $sessionId) {
                            return null;
                        }

                        $rule = Rule::unique('course_offerings', 'course_id')
                            ->where('programme_id', $programmeId)
                            ->where('academic_session_id', $sessionId)
                            ->whereNull('deleted_at');

                        if ($record?->exists) {
                            $rule->ignore($record->getKey());
                        }

                        return $rule;
                    }),
            ]);
    }
}
