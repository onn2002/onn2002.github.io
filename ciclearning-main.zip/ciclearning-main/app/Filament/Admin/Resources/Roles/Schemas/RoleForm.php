<?php

namespace App\Filament\Admin\Resources\Roles\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;
use Illuminate\Validation\Rules\Unique;

class RoleForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->columns(2)
            ->components([
                TextInput::make('name')
                    ->label('Name')
                    ->required()
                    ->maxLength(255)
                    ->unique(
                        table: 'roles',
                        column: 'name',
                        ignoreRecord: true,
                        modifyRuleUsing: fn (Unique $rule): Unique => $rule->where('guard_name', 'web'),
                    ),
                TextInput::make('guard_name')
                    ->label('Guard')
                    ->default('web')
                    ->disabled()
                    ->dehydrated(true)
                    ->dehydrateStateUsing(fn (?string $state): string => $state ?? 'web'),
            ]);
    }
}
