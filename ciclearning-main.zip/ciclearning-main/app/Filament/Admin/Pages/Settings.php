<?php

namespace App\Filament\Admin\Pages;

use App\Services\SettingsService;
use App\Support\EnvManager;
use BackedEnum;
use Carbon\CarbonInterface;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\TimePicker;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use UnitEnum;

class Settings extends Page implements HasForms
{
    use InteractsWithForms;

    protected static BackedEnum|string|null $navigationIcon = Heroicon::OutlinedCog6Tooth;

    protected static UnitEnum|string|null $navigationGroup = 'System';

    protected static ?int $navigationSort = 99;

    protected string $view = 'filament.admin.pages.settings';

    public ?array $data = [];

    public function mount(): void
    {
        $this->form->fill($this->getCurrentSettings());
    }

    public static function canAccess(): bool
    {
        return auth()->user()?->can('settings.manage') ?? false;
    }

    public static function shouldRegisterNavigation(): bool
    {
        return static::canAccess();
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->schema([
                Section::make('Uploads')
                    ->schema([
                        TagsInput::make('mime_whitelist')
                            ->label('Allowed MIME types')
                            ->required()
                            ->placeholder('application/pdf')
                            ->helperText('Files outside of this list will be rejected during upload.')
                            ->separator(','),
                        TextInput::make('max_upload_mb')
                            ->label('Max upload size (MB)')
                            ->numeric()
                            ->minValue(1)
                            ->required(),
                    ])->columns(2),
                Section::make('WhatsApp override')
                    ->schema([
                        Toggle::make('whatsapp.override_enabled')
                            ->label('Enable WhatsApp override')
                            ->inline(false),
                        TextInput::make('whatsapp.api_key')
                            ->label('API key'),
                        TextInput::make('whatsapp.api_secret')
                            ->label('API secret')
                            ->password()
                            ->revealable(),
                        TextInput::make('whatsapp.from')
                            ->label('From number'),
                    ])->columns(3),
                Section::make('SMTP override')
                    ->schema([
                        Toggle::make('smtp.override_enabled')
                            ->label('Enable SMTP override')
                            ->inline(false),
                        TextInput::make('smtp.host')
                            ->label('SMTP host')
                            ->live(),
                        TextInput::make('smtp.port')
                            ->label('SMTP port')
                            ->numeric(),
                        TextInput::make('smtp.username')
                            ->label('SMTP username'),
                        TextInput::make('smtp.password')
                            ->label('SMTP password')
                            ->password()
                            ->revealable(),
                        TextInput::make('smtp.encryption')
                            ->label('Encryption')
                            ->helperText('Typically tls or ssl'),
                    ])->columns(2),
                Section::make('Reminders')
                    ->schema([
                        CheckboxList::make('reminders.days')
                            ->label('Reminder days')
                            ->options($this->reminderDayOptions())
                            ->columns(3)
                            ->helperText('Lecturers will be reminded about missing uploads on the selected days.'),
                        TimePicker::make('reminders.time')
                            ->label('Reminder time (MYT)')
                            ->seconds(false)
                            ->timezone('Asia/Kuala_Lumpur')
                            ->helperText('Time of day to send reminders (Asia/Kuala_Lumpur).'),
                        CheckboxList::make('reminders.channels')
                            ->label('Channels')
                            ->options([
                                'mail' => 'Email',
                                'database' => 'In-app notification',
                            ])
                            ->columns(2)
                            ->helperText('Channels used to send reminders to lecturers.'),
                    ])->columns(2),
            ])
            ->extraAttributes(['style' => 'margin-bottom: 1.2rem;'])
            ->statePath('data');
    }

    public function submit(): void
    {
        $state = $this->form->getState();
        $settingsService = app(SettingsService::class);
        $reminders = $this->prepareReminderPayload($state['reminders'] ?? []);

        $validatedReminders = $this->validateReminderSettings($reminders);

        $settingsService->setReminderRecurrence($validatedReminders);
        $settingsService->setSmtpOverride($state['smtp'] ?? []);

        $mimeWhitelist = $this->normaliseMimeList($state['mime_whitelist'] ?? []);

        $payload = [
            'ADMIN_MIME_WHITELIST' => implode(',', $mimeWhitelist),
            'ADMIN_MAX_UPLOAD_MB' => (int) ($state['max_upload_mb'] ?? 0),
            'ADMIN_SMTP_OVERRIDE_ENABLED' => $state['smtp']['override_enabled'] ?? false,
            'ADMIN_SMTP_HOST' => $state['smtp']['host'] ?? null,
            'ADMIN_SMTP_PORT' => $state['smtp']['port'] ?? null,
            'ADMIN_SMTP_USERNAME' => $state['smtp']['username'] ?? null,
            'ADMIN_SMTP_PASSWORD' => $state['smtp']['password'] ?? null,
            'ADMIN_SMTP_ENCRYPTION' => $state['smtp']['encryption'] ?? null,
            'ADMIN_WHATSAPP_OVERRIDE_ENABLED' => $state['whatsapp']['override_enabled'] ?? false,
            'ADMIN_WHATSAPP_API_KEY' => $state['whatsapp']['api_key'] ?? null,
            'ADMIN_WHATSAPP_API_SECRET' => $state['whatsapp']['api_secret'] ?? null,
            'ADMIN_WHATSAPP_FROM' => $state['whatsapp']['from'] ?? null,
        ];

        app(EnvManager::class)->set($payload);

        config()->set('admin', $this->normaliseConfig($state));

        Notification::make()
            ->title('Settings saved')
            ->success()
            ->body('Changes are applied immediately. Consider clearing configuration cache in production environments.')
            ->send();

        config()->set('admin.reminders', $settingsService->reminderRecurrence());

        $this->form->fill($this->getCurrentSettings());
    }

    protected function getCurrentSettings(): array
    {
        $settingsService = app(SettingsService::class);

        return $this->normaliseConfig([
            'mime_whitelist' => config('admin.mime_whitelist', []),
            'max_upload_mb' => config('admin.max_upload_mb', 25),
            'smtp' => config('admin.smtp', []),
            'whatsapp' => config('admin.whatsapp', []),
            'reminders' => $settingsService->reminderRecurrence(),
        ]);
    }

    /**
     * @param  array<string, mixed>  $state
     * @return array<string, mixed>
     */
    protected function normaliseConfig(array $state): array
    {
        $settingsService = app(SettingsService::class);
        $reminders = $this->normaliseReminderConfig($state['reminders'] ?? $settingsService->reminderRecurrence());
        $mimeWhitelist = $this->normaliseMimeList($state['mime_whitelist'] ?? []);

        return [
            'mime_whitelist' => $mimeWhitelist,
            'max_upload_mb' => (int) ($state['max_upload_mb'] ?? config('admin.max_upload_mb', 25)),
            'smtp' => [
                'override_enabled' => (bool) ($state['smtp']['override_enabled'] ?? config('admin.smtp.override_enabled')),
                'host' => $state['smtp']['host'] ?? config('admin.smtp.host'),
                'port' => $state['smtp']['port'] ?? config('admin.smtp.port'),
                'username' => $state['smtp']['username'] ?? config('admin.smtp.username'),
                'password' => $state['smtp']['password'] ?? config('admin.smtp.password'),
                'encryption' => $state['smtp']['encryption'] ?? config('admin.smtp.encryption'),
            ],
            'whatsapp' => [
                'override_enabled' => (bool) ($state['whatsapp']['override_enabled'] ?? config('admin.whatsapp.override_enabled')),
                'api_key' => $state['whatsapp']['api_key'] ?? config('admin.whatsapp.api_key'),
                'api_secret' => $state['whatsapp']['api_secret'] ?? config('admin.whatsapp.api_secret'),
                'from' => $state['whatsapp']['from'] ?? config('admin.whatsapp.from'),
            ],
            'reminders' => $reminders,
        ];
    }

    /**
     * @return array<string, string>
     */
    protected function reminderDayOptions(): array
    {
        return [
            'monday' => 'Monday',
            'tuesday' => 'Tuesday',
            'wednesday' => 'Wednesday',
            'thursday' => 'Thursday',
            'friday' => 'Friday',
            'saturday' => 'Saturday',
            'sunday' => 'Sunday',
        ];
    }

    /**
     * @param  array<string, mixed>  $reminders
     * @return array<string, mixed>
     */
    protected function normaliseReminderConfig(array $reminders): array
    {
        $dayOptions = array_keys($this->reminderDayOptions());

        $days = array_values(array_filter(
            array_map('strtolower', $reminders['days'] ?? []),
            fn (string $day): bool => in_array($day, $dayOptions, true),
        ));

        $channels = array_values(array_filter($reminders['channels'] ?? ['mail', 'database']));

        return [
            'days' => $days,
            'time' => $reminders['time'] ?? '09:00',
            'channels' => $channels === [] ? ['mail', 'database'] : $channels,
        ];
    }

    /**
     * @param  array<string, mixed>  $reminders
     * @return array<string, mixed>
     */
    protected function prepareReminderPayload(array $reminders): array
    {
        $time = $reminders['time'] ?? null;

        if ($time instanceof CarbonInterface) {
            $time = $time->copy()->setTimezone('Asia/Kuala_Lumpur')->format('H:i');
        } elseif (is_string($time)) {
            $time = substr($time, 0, 5);
        }

        return [
            'days' => array_values(array_filter(array_map('strtolower', $reminders['days'] ?? []))),
            'time' => $time,
            'channels' => array_values(array_filter($reminders['channels'] ?? ['mail', 'database'])),
        ];
    }

    /**
     * @param  array<string, mixed>  $reminders
     * @return array<string, mixed>
     */
    protected function validateReminderSettings(array $reminders): array
    {
        $validator = Validator::make($reminders, [
            'days' => ['required', 'array', 'min:1'],
            'days.*' => ['string', Rule::in(array_keys($this->reminderDayOptions()))],
            'time' => ['required', 'date_format:H:i'],
            'channels' => ['required', 'array', 'min:1'],
            'channels.*' => ['string'],
        ]);

        return $validator->validate();
    }

    /**
     * @param  array<string>|string  $values
     * @return array<int, string>
     */
    protected function normaliseMimeList(array|string $values): array
    {
        if (is_string($values)) {
            $values = explode(',', $values);
        }

        return array_values(array_filter(array_map('trim', $values)));
    }
}
