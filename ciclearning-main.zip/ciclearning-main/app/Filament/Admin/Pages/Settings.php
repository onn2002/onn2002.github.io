<?php

namespace App\Filament\Admin\Pages;

use App\Support\EnvManager;
use BackedEnum;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use UnitEnum;

class Settings extends Page implements HasForms
{
    use InteractsWithForms;

    protected static BackedEnum|string|null $navigationIcon = Heroicon::OutlinedCog6Tooth;

    protected static UnitEnum|string|null $navigationGroup = 'System';

    protected static ?int $navigationSort = 99;

    protected string $view = 'filament.admin.pages.settings';

    public ?array $data = [];

    public function mount(): void
    {
        $this->form->fill($this->getCurrentSettings());
    }

    public static function canAccess(): bool
    {
        return auth()->user()?->can('settings.manage') ?? false;
    }

    public static function shouldRegisterNavigation(): bool
    {
        return static::canAccess();
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->schema([
                Section::make('Uploads')
                    ->schema([
                        TagsInput::make('mime_whitelist')
                            ->label('Allowed MIME types')
                            ->required()
                            ->placeholder('application/pdf')
                            ->helperText('Files outside of this list will be rejected during upload.')
                            ->separator(','),
                        TextInput::make('max_upload_mb')
                            ->label('Max upload size (MB)')
                            ->numeric()
                            ->minValue(1)
                            ->required(),
                    ])->columns(2),
                Section::make('WhatsApp override')
                    ->schema([
                        TextInput::make('whatsapp.api_key')
                            ->label('API key'),
                        TextInput::make('whatsapp.api_secret')
                            ->label('API secret')
                            ->password()
                            ->revealable(),
                        TextInput::make('whatsapp.from')
                            ->label('From number'),
                    ])->columns(3),
                Section::make('SMTP override')
                    ->schema([
                        TextInput::make('smtp.host')
                            ->label('SMTP host')
                            ->live(),
                        TextInput::make('smtp.port')
                            ->label('SMTP port')
                            ->numeric(),
                        TextInput::make('smtp.username')
                            ->label('SMTP username'),
                        TextInput::make('smtp.password')
                            ->label('SMTP password')
                            ->password()
                            ->revealable(),
                        TextInput::make('smtp.encryption')
                            ->label('Encryption')
                            ->helperText('Typically tls or ssl'),
                    ])->columns(2),
            ])
            ->extraAttributes(['style' => 'margin-bottom: 1.2rem;'])
            ->statePath('data');
    }

    public function submit(): void
    {
        $state = $this->form->getState();

        $payload = [
            'ADMIN_MIME_WHITELIST' => implode(',', array_map('trim', $state['mime_whitelist'] ?? [])),
            'ADMIN_MAX_UPLOAD_MB' => (int) ($state['max_upload_mb'] ?? 0),
            'ADMIN_SMTP_OVERRIDE_ENABLED' => $state['smtp']['override_enabled'] ?? false,
            'ADMIN_SMTP_HOST' => $state['smtp']['host'] ?? null,
            'ADMIN_SMTP_PORT' => $state['smtp']['port'] ?? null,
            'ADMIN_SMTP_USERNAME' => $state['smtp']['username'] ?? null,
            'ADMIN_SMTP_PASSWORD' => $state['smtp']['password'] ?? null,
            'ADMIN_SMTP_ENCRYPTION' => $state['smtp']['encryption'] ?? null,
            'ADMIN_WHATSAPP_OVERRIDE_ENABLED' => $state['whatsapp']['override_enabled'] ?? false,
            'ADMIN_WHATSAPP_API_KEY' => $state['whatsapp']['api_key'] ?? null,
            'ADMIN_WHATSAPP_API_SECRET' => $state['whatsapp']['api_secret'] ?? null,
            'ADMIN_WHATSAPP_FROM' => $state['whatsapp']['from'] ?? null,
        ];

        app(EnvManager::class)->set($payload);

        config()->set('admin', $this->normaliseConfig($state));

        Notification::make()
            ->title('Settings saved')
            ->success()
            ->body('Changes are applied immediately. Consider clearing configuration cache in production environments.')
            ->send();

        $this->form->fill($this->getCurrentSettings());
    }

    protected function getCurrentSettings(): array
    {
        return $this->normaliseConfig([
            'mime_whitelist' => config('admin.mime_whitelist', []),
            'max_upload_mb' => config('admin.max_upload_mb', 25),
            'smtp' => config('admin.smtp', []),
            'whatsapp' => config('admin.whatsapp', []),
        ]);
    }

    /**
     * @param  array<string, mixed>  $state
     * @return array<string, mixed>
     */
    protected function normaliseConfig(array $state): array
    {
        return [
            'mime_whitelist' => array_values(array_filter(array_map('trim', $state['mime_whitelist'] ?? []))),
            'max_upload_mb' => (int) ($state['max_upload_mb'] ?? config('admin.max_upload_mb', 25)),
            'smtp' => [
                'host' => $state['smtp']['host'] ?? config('admin.smtp.host'),
                'port' => $state['smtp']['port'] ?? config('admin.smtp.port'),
                'username' => $state['smtp']['username'] ?? config('admin.smtp.username'),
                'password' => $state['smtp']['password'] ?? config('admin.smtp.password'),
                'encryption' => $state['smtp']['encryption'] ?? config('admin.smtp.encryption'),
            ],
            'whatsapp' => [
                'api_key' => $state['whatsapp']['api_key'] ?? config('admin.whatsapp.api_key'),
                'api_secret' => $state['whatsapp']['api_secret'] ?? config('admin.whatsapp.api_secret'),
                'from' => $state['whatsapp']['from'] ?? config('admin.whatsapp.from'),
            ],
        ];
    }
}
