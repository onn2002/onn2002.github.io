<?php

namespace App\Filament\Admin\Pages;

use BackedEnum;
use Filament\Pages\Page;
use UnitEnum;

class ManageFolderTemplates extends Page
{
    protected static BackedEnum|string|null $navigationIcon = 'heroicon-o-folder';

    protected static ?string $navigationLabel = 'Folder Templates';

    protected static UnitEnum|string|null $navigationGroup = 'Catalog';

    protected static ?int $navigationSort = 40;

    protected static ?string $title = 'Folder Templates';

    protected static ?string $slug = 'folder-templates';

    protected string $view = 'filament.admin.pages.manage-folder-templates';

    public static function canAccess(): bool
    {
        return auth()->user()?->can('folder-template.manage') ?? false;
    }
}
