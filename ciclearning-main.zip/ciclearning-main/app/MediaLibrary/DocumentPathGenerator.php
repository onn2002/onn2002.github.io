<?php

namespace App\MediaLibrary;

use App\Models\Document;
use App\Services\FolderPathService;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Spatie\MediaLibrary\Support\PathGenerator\DefaultPathGenerator;
use Spatie\MediaLibrary\Support\PathGenerator\PathGenerator;

class DocumentPathGenerator implements PathGenerator
{
    public function __construct(
        private readonly FolderPathService $folderPathService,
    ) {}

    public function getPath(Media $media): string
    {
        return $this->resolvePath($media);
    }

    public function getPathForConversions(Media $media): string
    {
        $basePath = $this->resolvePath($media);

        return rtrim($basePath, '/').'/conversions/';
    }

    public function getPathForResponsiveImages(Media $media): string
    {
        $basePath = $this->resolvePath($media);

        return rtrim($basePath, '/').'/responsive-images/';
    }

    private function resolvePath(Media $media): string
    {
        $model = $media->model;

        if (! $model instanceof Document) {
            return $this->fallback()->getPath($media);
        }

        $model->loadMissing([
            'offering.programme',
            'offering.session',
            'offering.course',
        ]);

        $offering = $model->offering;
        $milestone = $model->milestone;
        $folderSlug = $model->folder_slug;

        if (! $offering || ! $milestone || ! is_string($folderSlug)) {
            return $this->fallback()->getPath($media);
        }

        return $this->folderPathService->buildPathFromSlug(
            $offering,
            $milestone,
            $folderSlug
        );
    }

    private function fallback(): PathGenerator
    {
        return new DefaultPathGenerator;
    }
}
