<?php

namespace App\Livewire\Lecturer;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\User;
use App\Services\CompletenessService;
use Livewire\Attributes\On;
use Livewire\Component;

class FolderTileGrid extends Component
{
    public ?int $offeringId = null;

    public ?string $milestone = null;

    public ?int $userId = null;

    public array $tiles = [];

    public ?string $selectedFolder = null;

    private ?string $stateHash = null;

    public function render()
    {
        $this->ensureTilesLoaded();

        return view('livewire.lecturer.folder-tile-grid');
    }

    #[On('documents-updated')]
    public function refreshTiles(?string $slug = null): void
    {
        $this->stateHash = null;
        $this->ensureTilesLoaded();

        if ($slug !== null && $this->folderExists($slug)) {
            $this->selectedFolder = $slug;
        }
    }

    public function selectFolder(string $slug): void
    {
        if (! $this->folderExists($slug)) {
            return;
        }

        $this->selectedFolder = $slug;
        $this->dispatch('open-files', slug: $slug);
    }

    public function openUpload(string $slug): void
    {
        if (! $this->folderExists($slug)) {
            return;
        }

        $this->selectedFolder = $slug;
        $this->dispatch('open-files', slug: $slug);
        $this->dispatch('open-upload', slug: $slug);
    }

    private function ensureTilesLoaded(): void
    {
        $hash = $this->stateSignature();

        if ($hash !== null && $hash === $this->stateHash) {
            return;
        }

        $this->stateHash = $hash;
        $this->tiles = [];

        if (! $this->offeringId || ! $this->userId || empty($this->milestone)) {
            return;
        }

        $milestoneEnum = Milestone::tryFrom($this->milestone);

        if (! $milestoneEnum) {
            return;
        }

        $offering = CourseOffering::query()->find($this->offeringId);
        $user = User::query()->find($this->userId);

        if (! $offering || ! $user) {
            return;
        }

        $status = app(CompletenessService::class)->statusFor($user, $offering, $milestoneEnum);

        $leafNodes = FolderTemplate::query()
            ->where('milestone', $milestoneEnum)
            ->with(['leafNodes' => fn ($query) => $query->orderBy('path_cache')])
            ->get()
            ->flatMap(fn (FolderTemplate $template) => $template->leafNodes)
            ->sortBy('path_cache')
            ->values();

        $this->tiles = $leafNodes
            ->map(fn (FolderTemplateNode $node) => $this->formatTile($node, $status))
            ->all();

        if ($this->selectedFolder !== null && ! $this->folderExists($this->selectedFolder)) {
            $this->selectedFolder = null;
        }
    }

    /**
     * @param  array<string, mixed>  $status
     */
    private function formatTile(FolderTemplateNode $node, array $status): array
    {
        $slug = $node->pathString();
        $data = $status[$slug] ?? [];

        $required = (bool) $node->required;
        $you = (int) ($data['you'] ?? 0);
        $total = (int) ($data['total'] ?? 0);
        $done = $required ? (bool) ($data['done'] ?? false) : true;

        return [
            'slug' => $slug,
            'label' => $node->label,
            'required' => $required,
            'you' => $you,
            'total' => $total,
            'done' => $done,
        ];
    }

    private function folderExists(string $slug): bool
    {
        return collect($this->tiles)
            ->contains(fn (array $tile) => $tile['slug'] === $slug);
    }

    private function stateSignature(): ?string
    {
        if ($this->offeringId === null && $this->userId === null && $this->milestone === null) {
            return null;
        }

        return md5(sprintf('%s|%s|%s', $this->offeringId, $this->milestone, $this->userId));
    }
}
