<?php

namespace App\Livewire\Lecturer;

use App\Enums\Milestone;
use App\Models\Document;
use App\Models\FolderTemplateNode;
use App\Services\DocumentOperationsService;
use Filament\Actions\Action;
use Filament\Actions\Concerns\InteractsWithActions;
use Filament\Actions\Contracts\HasActions as HasActionsContract;
use Filament\Actions\DeleteAction;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Notifications\Notification;
use Filament\Support\Contracts\TranslatableContentDriver;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Arr;
use Livewire\Attributes\Computed;
use Livewire\Attributes\On;
use Livewire\Component;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;

class FolderFileList extends Component implements HasActionsContract, HasForms, HasTable
{
    use InteractsWithActions;
    use InteractsWithForms;
    use InteractsWithTable;

    public ?int $offeringId = null;

    public ?string $milestone = null;

    public ?int $userId = null;

    public ?string $folderSlug = null;

    #[On('open-files')]
    public function openFolder(?string $slug): void
    {
        $this->folderSlug = $slug;
        $this->resetTable();
    }

    #[On('documents-updated')]
    public function refreshFiles(?string $slug = null): void
    {
        if ($slug !== null) {
            $this->folderSlug = $slug;
        }

        $this->resetTable();
    }

    public function render()
    {
        return view('livewire.lecturer.folder-file-list');
    }

    protected function getTableQuery(): Builder
    {
        $milestone = $this->resolveMilestone();

        if (! $this->offeringId || ! $milestone || ! $this->folderSlug) {
            return Document::query()->whereRaw('1 = 0');
        }

        return Document::query()
            ->where('offering_id', $this->offeringId)
            ->where('milestone', $milestone->value)
            ->where('folder_slug', $this->folderSlug)
            ->with(['uploader'])
            ->latest();
    }

    protected function getTableColumns(): array
    {
        return [
//            TextColumn::make('stored_filename')
//                ->label('Stored name')
//                ->copyable()
//                ->wrap(),
//            TextColumn::make('original_filename')
//                ->label('Reference name')
//                ->copyable()
//                ->wrap(),
            TextColumn::make('path_string')
                ->label('Storage path')
                ->copyable()
                ->wrap(),
            TextColumn::make('uploader.name')
                ->label('Uploader')
                ->badge()
                ->color('gray'),
            TextColumn::make('created_at')
                ->label('Uploaded at')
                ->since(),
        ];
    }

    protected function getTableActions(): array
    {
        return [
            Action::make('replace')
                ->label('Replace')
                ->modalHeading('Replace document')
                ->modalButton('Upload replacement')
                ->authorize(fn (Document $record) => auth()->user()?->can('update', $record) ?? false)
                ->form(function (): array {
                    $upload = FileUpload::make('file')
                        ->label('Replacement file')
                        ->required()
                        ->maxSize($this->maxUploadKilobytes())
                        ->storeFiles(false);

                    $mimeTypes = $this->allowedMimeTypes();

                    if ($mimeTypes !== []) {
                        $upload->acceptedFileTypes($mimeTypes);
                    }

                    return [$upload];
                })
                ->action(function (Document $record, array $data): void {
                    $file = $this->normalizeUploadedFile($data['file'] ?? null);

                    if (! $file) {
                        return;
                    }

                    app(DocumentOperationsService::class)->replace($record, $file);

                    Notification::make()
                        ->title('Document replaced')
                        ->success()
                        ->body('The file was replaced successfully and metadata has been updated.')
                        ->send();

                    $this->dispatch('documents-updated', slug: $record->folder_slug);
                    $this->resetTable();
                }),
            DeleteAction::make('delete')
                ->label('Delete')
                ->modalHeading('Delete document')
                ->modalDescription('This removes the stored file and archives the record. You can upload again later if needed.')
                ->authorize(fn (Document $record) => auth()->user()?->can('delete', $record) ?? false)
                ->action(function (Document $record): void {
                    $slug = $record->folder_slug;

                    app(DocumentOperationsService::class)->delete($record);

                    Notification::make()
                        ->title('Document deleted')
                        ->success()
                        ->body('The document has been removed and folder status updated.')
                        ->send();

                    $this->dispatch('documents-updated', slug: $slug);
                    $this->resetTable();
                }),
        ];
    }

    protected function getTableEmptyStateHeading(): ?string
    {
        if (! $this->folderSlug) {
            return 'Select a folder to view files';
        }

        return 'No uploads yet';
    }

    protected function getTableEmptyStateDescription(): ?string
    {
        if (! $this->folderSlug) {
            return 'Choose a folder from the status grid to list available files.';
        }

        return 'Upload the first file to complete this folder.';
    }

    protected function getTableEmptyStateIcon(): ?string
    {
        return 'heroicon-o-document-text';
    }

    #[Computed]
    public function folderLabel(): ?string
    {
        $milestone = $this->resolveMilestone();

        if (! $milestone || ! $this->folderSlug) {
            return null;
        }

        return FolderTemplateNode::query()
            ->where('path_cache', $this->folderSlug)
            ->whereHas('folderTemplate', fn ($query) => $query->where('milestone', $milestone))
            ->value('label');
    }

    public function makeFilamentTranslatableContentDriver(): ?TranslatableContentDriver
    {
        return null;
    }

    protected function resolveMilestone(): ?Milestone
    {
        return Milestone::tryFrom($this->milestone ?? '');
    }

    private function allowedMimeTypes(): array
    {
        return array_values(array_filter((array) config('admin.mime_whitelist', [])));
    }

    private function maxUploadKilobytes(): int
    {
        $maxMb = (int) config('admin.max_upload_mb', 25);

        return max($maxMb, 1) * 1024;
    }

    private function normalizeUploadedFile(mixed $value): ?UploadedFile
    {
        $value = Arr::first(Arr::wrap($value), fn ($item) => filled($item));

        if (is_string($value) && TemporaryUploadedFile::canUnserialize($value)) {
            $value = TemporaryUploadedFile::unserializeFromLivewireRequest($value);
            $value = Arr::first(Arr::wrap($value), fn ($item) => filled($item));
        }

        if ($value instanceof TemporaryUploadedFile) {
            return $value;
        }

        if ($value instanceof UploadedFile) {
            return $value;
        }

        return null;
    }
}
