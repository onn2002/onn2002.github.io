<?php

namespace App\Livewire\Lecturer;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\FolderTemplateNode;
use App\Models\User;
use App\Services\DocumentStorageService;
use App\Services\FolderPathService;
use Filament\Notifications\Notification;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\On;
use Livewire\Component;
use Livewire\WithFileUploads;

class UploadModal extends Component
{
    use WithFileUploads;

    public ?int $offeringId = null;

    public ?string $milestone = null;

    public ?int $userId = null;

    public $file;

    public ?string $folderSlug = null;

    public ?string $folderLabel = null;

    public ?string $pathPreview = null;

    private DocumentStorageService $storageService;

    private FolderPathService $folderPathService;

    public function boot(
        DocumentStorageService $storageService,
        FolderPathService $folderPathService
    ): void {
        $this->storageService = $storageService;
        $this->folderPathService = $folderPathService;
    }

    #[On('open-upload')]
    public function openUpload(?string $slug): void
    {
        if (! $slug) {
            return;
        }

        try {
            $context = $this->prepareContext($slug);
        } catch (ValidationException) {
            $this->dispatch('close-modal', id: 'lecturer-upload-modal');

            Notification::make()
                ->title('Unable to open upload form')
                ->danger()
                ->body('The selected folder is not available for this milestone.')
                ->send();

            return;
        }

        $this->folderSlug = $context['slug'];
        $this->folderLabel = $context['label'];
        $this->pathPreview = $context['path'];
        $this->file = null;

        $this->dispatch('open-modal', id: 'lecturer-upload-modal');
    }

    #[On('close-upload-modal')]
    public function close(): void
    {
        $this->resetFormState();
        $this->dispatch('close-modal', id: 'lecturer-upload-modal');
    }

    public function submit(): void
    {
        $this->validate([
            'file' => ['required', 'file'],
        ], attributes: [
            'file' => 'upload',
        ]);

        $milestone = $this->resolveMilestone();
        $offering = $this->resolveOffering();
        $user = $this->resolveUser();
        $folderSlug = $this->folderSlug;

        if (! $milestone || ! $offering || ! $user || ! $folderSlug) {
            Notification::make()
                ->title('Upload incomplete')
                ->danger()
                ->body('Please select a folder and try again.')
                ->send();

            return;
        }

        $node = $this->resolveNode($folderSlug, $milestone);

        if (! $node || ! $node->isLeaf()) {
            Notification::make()
                ->title('Upload failed')
                ->danger()
                ->body('The selected folder is no longer available.')
                ->send();

            return;
        }

        $document = $this->storageService->store(
            $offering,
            $milestone,
            $node,
            $this->file,
            $user
        );

        Notification::make()
            ->title('Upload complete')
            ->success()
            ->body(sprintf(
                "Stored as %s.\nPath: %s",
                $document->stored_filename,
                $document->path_string
            ))
            ->send();

        $this->dispatch('documents-updated', slug: $document->folder_slug);
        $this->dispatch('open-files', slug: $document->folder_slug);
        $this->dispatch('close-modal', id: 'lecturer-upload-modal');

        $this->file = null;
    }

    public function render()
    {
        return view('livewire.lecturer.upload-modal');
    }

    private function prepareContext(string $slug): array
    {
        $milestone = $this->resolveMilestone();
        $offering = $this->resolveOffering();

        if (! $milestone || ! $offering) {
            throw ValidationException::withMessages([
                'folder' => 'Select a valid offering and milestone first.',
            ]);
        }

        $node = $this->resolveNode($slug, $milestone);

        if (! $node || ! $node->isLeaf()) {
            throw ValidationException::withMessages([
                'folder' => 'Selected folder is not available.',
            ]);
        }

        $path = $this->folderPathService->buildPath($offering, $milestone, $node);

        return [
            'slug' => $node->pathString(),
            'label' => $node->label,
            'path' => $path,
        ];
    }

    private function resolveMilestone(): ?Milestone
    {
        return Milestone::tryFrom($this->milestone ?? '');
    }

    private function resolveOffering(): ?CourseOffering
    {
        if (! $this->offeringId) {
            return null;
        }

        return CourseOffering::query()
            ->with(['programme', 'session', 'course'])
            ->find($this->offeringId);
    }

    private function resolveUser(): ?User
    {
        if (! $this->userId) {
            return null;
        }

        return User::query()->find($this->userId);
    }

    private function resolveNode(string $slug, Milestone $milestone): ?FolderTemplateNode
    {
        return FolderTemplateNode::query()
            ->where('path_cache', $slug)
            ->whereHas('folderTemplate', fn ($query) => $query->where('milestone', $milestone))
            ->first();
    }

    private function resetFormState(): void
    {
        $this->file = null;
        $this->folderSlug = null;
        $this->folderLabel = null;
        $this->pathPreview = null;
        $this->resetErrorBag();
    }
}
