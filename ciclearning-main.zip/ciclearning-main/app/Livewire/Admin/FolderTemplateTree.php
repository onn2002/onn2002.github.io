<?php

namespace App\Livewire\Admin;

use App\Enums\Milestone;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use Filament\Notifications\Notification;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection as SupportCollection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Locked;
use Livewire\Attributes\On;
use Livewire\Component;
use Throwable;

class FolderTemplateTree extends Component
{
    private const ALL_MILESTONES_VALUE = 'all';

    private const UNASSIGNED_MILESTONE_KEY = '__unassigned__';

    #[Locked]
    public array $milestones = [];

    public string $selectedMilestone;

    #[Locked]
    public ?int $templateId = null;

    public array $tree = [];

    public array $pendingTree = [];

    public bool $hasPendingReorder = false;

    public ?int $selectedNodeId = null;

    public array $nodeForm = [
        'label' => '',
        'required' => true,
    ];

    public array $selectedNodeDetails = [];

    public function mount(?string $milestone = null): void
    {
        $milestoneOptions = collect(Milestone::cases())
            ->map(fn (Milestone $case) => [
                'value' => $case->value,
                'label' => $case->label(),
            ]);

        $this->milestones = $milestoneOptions
            ->prepend([
                'value' => self::ALL_MILESTONES_VALUE,
                'label' => 'All',
            ])
            ->values()
            ->all();

        $default = $milestone ?? self::ALL_MILESTONES_VALUE;

        if (! $this->isValidMilestoneSelection($default)) {
            $default = self::ALL_MILESTONES_VALUE;
        }

        $this->selectedMilestone = $default;

        $this->loadTemplate(resetSelection: true);
    }

    public function updatedSelectedMilestone(string $milestone): void
    {
        if (! $this->isValidMilestoneSelection($milestone)) {
            return;
        }

        $this->selectedMilestone = $milestone;
        $this->loadTemplate(resetSelection: true);
    }

    public function selectNode(int $nodeId): void
    {
        $this->hydrateSelection($nodeId);
    }

    public function deselectNode(): void
    {
        $this->selectedNodeId = null;
        $this->nodeForm = $this->defaultNodeForm();
        $this->selectedNodeDetails = [];
        $this->resetErrorBag(['nodeForm.label']);
        $this->dispatch('node-selected', id: null);
    }

    public function saveNodeDetails(): void
    {
        if (! $this->selectedNodeId) {
            return;
        }

        $data = $this->validate([
            'nodeForm.label' => ['required', 'string', 'max:160'],
            'nodeForm.required' => ['boolean'],
        ], attributes: [
            'nodeForm.label' => 'folder name',
            'nodeForm.required' => 'required flag',
        ]);

        $node = $this->nodeQuery()->find($this->selectedNodeId);

        if (! $node) {
            $this->deselectNode();

            return;
        }

        try {
            DB::transaction(function () use ($node, $data): void {
                $node->label = $data['nodeForm']['label'];
                $node->slug = Str::of($data['nodeForm']['label'])->title()->replaceMatches('/[^A-Za-z0-9]/', '')->toString();
                $node->required = $data['nodeForm']['required'];
                $node->save();
            });

            Notification::make()
                ->title('Node details updated')
                ->success()
                ->send();

            $this->loadTemplate(preferredSelectionId: $node->id);
        } catch (ValidationException $exception) {
            $this->reportValidationException($exception, 'nodeForm.label');
        } catch (QueryException) {
            $this->reportDuplicateError('nodeForm.label');
        }
    }

    public function addRoot(): void
    {
        $this->createNode(null);
    }

    public function addChild(): void
    {
        if (! $this->selectedNodeId) {
            Notification::make()
                ->title('Select a folder to add a child.')
                ->warning()
                ->send();

            return;
        }

        $this->createNode($this->selectedNodeId);
    }

    public function deleteSelected(): void
    {
        if (! $this->selectedNodeId) {
            return;
        }

        $node = $this->nodeQuery()
            ->withCount('children')
            ->find($this->selectedNodeId);

        if (! $node) {
            $this->deselectNode();

            return;
        }

        if ($node->children_count > 0) {
            Notification::make()
                ->title('Remove child folders before deleting this folder.')
                ->danger()
                ->send();

            return;
        }

        $node->delete();

        Notification::make()
            ->title('Folder removed')
            ->success()
            ->send();

        $this->loadTemplate(resetSelection: true);
    }

    #[On('tree-reordered')]
    public function stageReorder(array $tree): void
    {
        if ($this->isAllMilestoneSelected()) {
            $this->dispatch('tree-updated');

            return;
        }

        $this->pendingTree = $tree;
        $this->tree = $this->reorderTree($tree, $this->tree);
        $this->hasPendingReorder = true;
        $this->resetErrorBag(['tree']);
    }

    public function saveReorder(): void
    {
        if ($this->isAllMilestoneSelected()) {
            return;
        }

        if (! $this->hasPendingReorder || empty($this->pendingTree)) {
            return;
        }

        try {
            DB::transaction(function (): void {
                $this->persistBranch($this->pendingTree, null, 1);
            });

            $this->hasPendingReorder = false;
            $this->pendingTree = [];

            Notification::make()
                ->title('Folder order saved')
                ->success()
                ->send();

            $this->loadTemplate(preferredSelectionId: $this->selectedNodeId);
        } catch (ValidationException $exception) {
            $this->reportValidationException($exception);
        } catch (Throwable $throwable) {
            report($throwable);

            Notification::make()
                ->title('Unable to reorder folders right now.')
                ->danger()
                ->send();

            $this->dispatch('tree-updated');
        }
    }

    public function render()
    {
        return view('livewire.admin.folder-template-tree');
    }

    protected function loadTemplate(bool $resetSelection = false, ?int $preferredSelectionId = null): void
    {
        if ($this->isAllMilestoneSelected()) {
            $this->templateId = null;
            $this->tree = $this->buildTreeForAllMilestones();
            $this->pendingTree = [];
            $this->hasPendingReorder = false;

            $selectionId = $preferredSelectionId ?? ($resetSelection ? null : $this->selectedNodeId);
            $this->hydrateSelection($selectionId);

            $this->dispatch('tree-updated');

            return;
        }

        $label = Milestone::tryFrom($this->selectedMilestone)?->label()
            ?? Str::headline(str_replace('_', ' ', $this->selectedMilestone));

        $template = FolderTemplate::firstOrCreate(
            ['milestone' => $this->selectedMilestone],
            [
                'slug' => $this->selectedMilestone,
                'label' => $label,
            ]
        );

        $this->templateId = $template->id;
        $this->tree = $this->buildTree($template);
        $this->pendingTree = [];
        $this->hasPendingReorder = false;

        $selectionId = $preferredSelectionId ?? ($resetSelection ? null : $this->selectedNodeId);
        $this->hydrateSelection($selectionId);

        $this->dispatch('tree-updated');
    }

    protected function hydrateSelection(?int $nodeId): void
    {
        if (! $nodeId) {
            $this->deselectNode();

            return;
        }

        $node = $this->nodeQuery()
            ->with(['folderTemplate'])
            ->withCount('children')
            ->find($nodeId);

        if (! $node) {
            $this->deselectNode();

            return;
        }

        $this->selectedNodeId = $node->id;
        $this->nodeForm = [
            'label' => $node->label,
            'required' => (bool) $node->required,
        ];
        $this->selectedNodeDetails = [
            'path' => $node->pathString(),
            'depth' => $node->depth,
            'children_count' => $node->children_count,
            'parent_id' => $node->parent_id,
            'template_id' => $node->folder_template_id,
            'template_label' => $node->folderTemplate?->label,
            'milestone' => $node->folderTemplate?->milestone?->value,
            'milestone_label' => $node->folderTemplate?->milestone?->label(),
        ];

        $this->resetErrorBag(['nodeForm.label']);
        $this->dispatch('node-selected', id: $this->selectedNodeId);
    }

    protected function createNode(?int $parentId): void
    {
        if (! $this->templateId) {
            return;
        }

        $parent = null;

        if ($parentId) {
            $parent = $this->nodeQuery()->find($parentId);

            if (! $parent) {
                $this->deselectNode();

                return;
            }

            if ($parent->depth >= FolderTemplateNode::MAX_DEPTH) {
                Notification::make()
                    ->title('Folders cannot exceed three levels.')
                    ->danger()
                    ->send();

                return;
            }
        }

        $label = $this->nextAvailableLabel($parentId);

        try {
            $node = DB::transaction(function () use ($parentId, $label) {
                return FolderTemplateNode::create([
                    'folder_template_id' => $this->templateId,
                    'parent_id' => $parentId,
                    'label' => $label,
                    'slug' => Str::of($label)->title()->replaceMatches('/[^A-Za-z0-9]/', '')->toString(),
                    'required' => true,
                ]);
            });

            Notification::make()
                ->title('Folder added')
                ->success()
                ->send();

            $this->loadTemplate(preferredSelectionId: $node->id);
        } catch (ValidationException $exception) {
            $this->reportValidationException($exception);
        } catch (QueryException) {
            $this->reportDuplicateError('tree');
        }
    }

    protected function nextAvailableLabel(?int $parentId, string $base = 'New Folder'): string
    {
        $siblings = $this->nodeQuery()
            ->when($parentId, fn (Builder $query) => $query->where('parent_id', $parentId))
            ->when(! $parentId, fn (Builder $query) => $query->whereNull('parent_id'))
            ->pluck('slug')
            ->all();

        $existing = collect($siblings);

        $candidate = $base;
        $suffix = 1;

        while ($existing->contains(Str::of($candidate)->title()->replaceMatches('/[^A-Za-z0-9]/', '')->toString())) {
            $suffix++;
            $candidate = $base.' '.$suffix;
        }

        return $candidate;
    }

    protected function buildTree(FolderTemplate $template): array
    {
        $nodes = $template->nodes()->get();

        $grouped = $nodes->groupBy('parent_id');

        return $this->mapBranch($grouped, null);
    }

    protected function mapBranch(SupportCollection $grouped, ?int $parentId): array
    {
        return $grouped->get($parentId, collect())
            ->sortBy('position')
            ->map(function (FolderTemplateNode $node) use ($grouped) {
                return [
                    'id' => $node->id,
                    'label' => $node->label,
                    'slug' => $node->slug,
                    'path' => $node->pathString(),
                    'required' => (bool) $node->required,
                    'children' => $this->mapBranch($grouped, $node->id),
                ];
            })
            ->values()
            ->all();
    }

    protected function nodeQuery(): Builder
    {
        $query = FolderTemplateNode::query();

        if ($this->templateId) {
            $query->where('folder_template_id', $this->templateId);
        }

        return $query;
    }

    protected function persistBranch(array $branch, ?int $parentId, int $depth): void
    {
        if ($depth > FolderTemplateNode::MAX_DEPTH) {
            throw ValidationException::withMessages([
                'tree' => 'Cannot exceed maximum depth of '.FolderTemplateNode::MAX_DEPTH.'.',
            ]);
        }

        foreach ($branch as $position => $node) {
            $id = $node['id'] ?? null;

            if (! $id) {
                continue;
            }

            $model = $this->nodeQuery()->find($id);

            if (! $model) {
                continue;
            }

            $model->parent_id = $parentId;
            $model->position = $position;
            $model->save();

            $children = $node['children'] ?? [];
            $this->persistBranch($children, $model->id, $depth + 1);
        }
    }

    /**
     * Rebuilds the in-memory tree so the UI reflects the staged drag order.
     */
    protected function reorderTree(array $pending, array $current): array
    {
        if (empty($pending)) {
            return $current;
        }

        $flat = $this->flattenTree($current);
        $rebuilt = $this->rebuildTreeFromPending($pending, $flat);

        return empty($rebuilt) ? $current : $rebuilt;
    }

    protected function flattenTree(array $branch): array
    {
        $flat = [];

        foreach ($branch as $node) {
            $id = $node['id'] ?? null;

            if (! $id) {
                continue;
            }

            $children = $node['children'] ?? [];

            $flat[$id] = array_merge($node, [
                'children' => [],
            ]);

            foreach ($this->flattenTree($children) as $childId => $childNode) {
                $flat[$childId] = $childNode;
            }
        }

        return $flat;
    }

    protected function rebuildTreeFromPending(array $pending, array $flat): array
    {
        $rebuilt = [];

        foreach ($pending as $node) {
            $id = $node['id'] ?? null;

            if (! $id || ! isset($flat[$id])) {
                continue;
            }

            $item = $flat[$id];
            $item['children'] = $this->rebuildTreeFromPending($node['children'] ?? [], $flat);

            $rebuilt[] = $item;
        }

        return $rebuilt;
    }

    protected function reportValidationException(ValidationException $exception, string $key = 'tree'): void
    {
        $message = collect($exception->errors())
            ->flatten()
            ->first();

        if ($message) {
            $this->addError($key, $message);
        }

        Notification::make()
            ->title($message ?? 'Validation error')
            ->danger()
            ->send();
    }

    protected function reportDuplicateError(string $key): void
    {
        $message = 'Folder slug must be unique within the same parent.';

        $this->addError($key, $message);

        Notification::make()
            ->title($message)
            ->danger()
            ->send();
    }

    protected function defaultNodeForm(): array
    {
        return [
            'label' => '',
            'required' => true,
        ];
    }

    protected function buildTreeForAllMilestones(): array
    {
        $templates = FolderTemplate::query()
            ->orderBy('label')
            ->with(['nodes' => fn ($query) => $query->orderBy('depth')->orderBy('position')])
            ->get();

        $groupedTemplates = $templates->groupBy(
            fn (FolderTemplate $template) => $template->milestone?->value ?? self::UNASSIGNED_MILESTONE_KEY
        );

        $sections = collect(Milestone::cases())
            ->map(function (Milestone $milestone) use ($groupedTemplates) {
                $templatesForMilestone = $groupedTemplates->get($milestone->value, collect());

                return $this->buildSectionFromTemplates(
                    $milestone->value,
                    $milestone->label(),
                    $templatesForMilestone
                );
            })
            ->all();

        if ($groupedTemplates->has(self::UNASSIGNED_MILESTONE_KEY)) {
            $unassignedTemplates = $groupedTemplates->get(self::UNASSIGNED_MILESTONE_KEY, collect());

            $sections[] = $this->buildSectionFromTemplates(
                self::UNASSIGNED_MILESTONE_KEY,
                'Unassigned',
                $unassignedTemplates
            );
        }

        return $sections;
    }

    protected function buildSectionFromTemplates(string $milestoneKey, string $label, SupportCollection $templates): array
    {
        $nodes = $templates
            ->sortBy('label')
            ->flatMap(fn (FolderTemplate $template) => $this->mapTemplateNodes($template))
            ->values()
            ->all();

        return [
            'milestone' => $milestoneKey === self::UNASSIGNED_MILESTONE_KEY ? null : $milestoneKey,
            'label' => $label,
            'nodes' => $nodes,
        ];
    }

    protected function mapTemplateNodes(FolderTemplate $template): array
    {
        $grouped = $template->nodes->groupBy('parent_id');

        return collect($this->mapBranch($grouped, null))
            ->map(fn (array $node) => $this->decorateNodeWithTemplate($node, $template))
            ->all();
    }

    protected function decorateNodeWithTemplate(array $node, FolderTemplate $template): array
    {
        $node['template_id'] = $template->id;
        $node['template_label'] = $template->label;
        $node['milestone'] = $template->milestone?->value;
        $node['display_path'] = $template->slug.'/'.$node['path'];
        $node['children'] = collect($node['children'] ?? [])
            ->map(fn (array $child) => $this->decorateNodeWithTemplate($child, $template))
            ->all();

        return $node;
    }

    protected function isValidMilestoneSelection(?string $value): bool
    {
        return collect($this->milestones)
            ->pluck('value')
            ->contains($value);
    }

    protected function isAllMilestoneSelected(): bool
    {
        return $this->selectedMilestone === self::ALL_MILESTONES_VALUE;
    }

    public function getViewingAllMilestonesProperty(): bool
    {
        return $this->isAllMilestoneSelected();
    }
}
