<?php

namespace App\Enums;

use Illuminate\Support\Str;

enum Milestone: string
{
    case BeginningOfSemester = 'beginning_of_semester';
    case MidTermExamination = 'mid_term_examination';
    case FinalExamPackage = 'final_exam_package';
    case EndOfSemester = 'end_of_semester';

    public function label(): string
    {
        return match ($this) {
            self::BeginningOfSemester => 'Beginning of Semester',
            self::MidTermExamination => 'Mid-Term Examination',
            self::FinalExamPackage => 'Final Exam Package',
            self::EndOfSemester => 'End of Semester',
        };
    }

    public function pathSegment(): string
    {
        $camel = Str::of($this->label())
            ->replaceMatches('/[^A-Za-z0-9]+/u', ' ')
            ->camel();

        return ucfirst((string) $camel);
    }

    /**
     * @return array<string>
     */
    public static function values(): array
    {
        return array_map(
            static fn (self $milestone): string => $milestone->value,
            self::cases(),
        );
    }
}
