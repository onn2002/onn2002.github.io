<?php

namespace App\Services;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\User;
use Illuminate\Support\Collection;

class ReminderTargetingService
{
    public function __construct(
        protected CompletenessService $completenessService,
        protected FolderPathService $folderPathService,
    ) {}

    /**
     * @return Collection<int, array{
     *     lecturer: User,
     *     items: array<int, array{
     *         offering: CourseOffering,
     *         milestone: Milestone,
     *         missing_folders: array<int, string>
     *     }>
     * }>
     */
    public function buildTargets(
        ?int $programmeId,
        ?int $sessionId,
        ?Milestone $milestone = null,
    ): Collection {
        $milestones = $milestone ? [$milestone] : Milestone::cases();

        $offerings = CourseOffering::query()
            ->when($programmeId, fn ($query) => $query->where('programme_id', $programmeId))
            ->when($sessionId, fn ($query) => $query->where('academic_session_id', $sessionId))
            ->with(['programme', 'session', 'course', 'lecturers'])
            ->get();

        $targets = collect();

        foreach ($offerings as $offering) {
            foreach ($milestones as $targetMilestone) {
                foreach ($offering->lecturers as $lecturer) {
                    $missing = $this->missingFolders($lecturer, $offering, $targetMilestone);

                    if ($missing->isEmpty()) {
                        continue;
                    }

                    $key = $lecturer->getKey();
                    $current = $targets->get($key, [
                        'lecturer' => $lecturer,
                        'items' => [],
                    ]);

                    $current['items'][] = [
                        'offering' => $offering,
                        'milestone' => $targetMilestone,
                        'missing_folders' => $missing->values()->all(),
                    ];

                    $targets->put($key, $current);
                }
            }
        }

        return $targets->values();
    }

    /**
     * @return Collection<int, string>
     */
    protected function missingFolders(User $lecturer, CourseOffering $offering, Milestone $milestone): Collection
    {
        $status = $this->completenessService->statusFor($lecturer, $offering, $milestone);

        return collect($status)
            ->filter(fn (array $folder): bool => ($folder['required'] ?? false) && ! ($folder['done'] ?? false))
            ->keys();
    }
}
