<?php

namespace App\Services;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class FolderPathService
{
    public function buildPath(CourseOffering $offering, Milestone $milestone, FolderTemplateNode $node): string
    {
        if (! $node->isLeaf()) {
            throw ValidationException::withMessages([
                'folder' => 'Select a leaf folder before uploading.',
            ]);
        }

        return $this->buildPathFromSlug($offering, $milestone, $node->pathString());
    }

    public function buildPathFromSlug(CourseOffering $offering, Milestone $milestone, string $folderSlug): string
    {
        $segments = $this->baseSegments($offering, $milestone);
        $folderSlug = trim($folderSlug, '/');

        if ($folderSlug !== '') {
            $segments[] = $folderSlug;
        }

        return $this->implodeSegments($segments);
    }

    public function resolveLeafByPath(FolderTemplate $template, string $path): FolderTemplateNode
    {
        $node = $template->nodes()
            ->where('path_cache', $path)
            ->first();

        if (! $node) {
            throw ValidationException::withMessages([
                'folder_slug' => 'Folder path is not registered for this milestone.',
            ]);
        }

        if ($node->children()->exists()) {
            throw ValidationException::withMessages([
                'folder_slug' => 'Only leaf folders can receive uploads.',
            ]);
        }

        return $node;
    }

    public function resolveLeafById(FolderTemplate $template, int $id): FolderTemplateNode
    {
        $node = $template->nodes()->find($id);

        if (! $node) {
            throw ValidationException::withMessages([
                'folder' => 'Folder is not available for this milestone.',
            ]);
        }

        if ($node->children()->exists()) {
            throw ValidationException::withMessages([
                'folder' => 'Only leaf folders can receive uploads.',
            ]);
        }

        return $node;
    }

    protected function normalise(?string $value): ?string
    {
        if (! $value) {
            return null;
        }

        $clean = Str::of($value)
            ->replace(['/', '\\'], '-')
            ->trim()
            ->toString();

        return $clean === '' ? null : $clean;
    }

    /**
     * @return array<int, string>
     */
    private function baseSegments(CourseOffering $offering, Milestone $milestone): array
    {
        return array_values(array_filter([
            $this->normalise($offering->programme?->code ?? 'programme-'.$offering->programme_id),
            $this->normalise($offering->session?->code ?? 'session-'.$offering->academic_session_id),
            $this->normalise($offering->course_identifier ?? 'course-'.$offering->course_id),
            $milestone->pathSegment(),
        ], fn (?string $segment) => $segment !== null && $segment !== ''));
    }

    /**
     * @param  array<int, string>  $segments
     */
    private function implodeSegments(array $segments): string
    {
        $path = implode('/', $segments);

        if ($path === '') {
            return '';
        }

        return Str::finish($path, '/');
    }
}
