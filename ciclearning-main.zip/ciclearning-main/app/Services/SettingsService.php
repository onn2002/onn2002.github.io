<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Arr;

class SettingsService
{
    public const SMTP_OVERRIDE_KEY = 'smtp.override';
    public const REMINDER_RECURRENCE_KEY = 'reminders.recurrence';

    /**
     * @return array{
     *     override_enabled: bool,
     *     host: string|null,
     *     port: string|null,
     *     username: string|null,
     *     password: string|null,
     *     encryption: string|null
     * }
     */
    public function smtpOverride(): array
    {
        $stored = $this->asArray(Setting::get(self::SMTP_OVERRIDE_KEY));
        $fallback = config('admin.smtp', []);

        $normalised = [
            'override_enabled' => $this->boolValue(
                Arr::get($stored, 'override_enabled'),
                (bool) Arr::get($fallback, 'override_enabled', false)
            ),
            'host' => $this->valueOrFallback(Arr::get($stored, 'host'), Arr::get($fallback, 'host')),
            'port' => $this->valueOrFallback(Arr::get($stored, 'port'), Arr::get($fallback, 'port')),
            'username' => $this->valueOrFallback(Arr::get($stored, 'username'), Arr::get($fallback, 'username')),
            'password' => $this->valueOrFallback(Arr::get($stored, 'password'), Arr::get($fallback, 'password')),
            'encryption' => $this->valueOrFallback(Arr::get($stored, 'encryption'), Arr::get($fallback, 'encryption', 'tls')),
        ];

        if ($stored === [] || $stored !== $normalised) {
            Setting::set(self::SMTP_OVERRIDE_KEY, $normalised);
        }

        return $normalised;
    }

    /**
     * @param  array{
     *     override_enabled?: bool,
     *     host?: string|null,
     *     port?: string|null,
     *     username?: string|null,
     *     password?: string|null,
     *     encryption?: string|null
     * }  $values
     */
    public function setSmtpOverride(array $values): void
    {
        $current = $this->smtpOverride();

        $payload = [
            'override_enabled' => $this->boolValue(
                $values['override_enabled'] ?? $current['override_enabled'],
                $current['override_enabled']
            ),
            'host' => $this->valueOrFallback($values['host'] ?? $current['host'], $current['host']),
            'port' => $this->valueOrFallback($values['port'] ?? $current['port'], $current['port']),
            'username' => $this->valueOrFallback($values['username'] ?? $current['username'], $current['username']),
            'password' => $this->valueOrFallback($values['password'] ?? $current['password'], $current['password']),
            'encryption' => $this->valueOrFallback($values['encryption'] ?? $current['encryption'], $current['encryption']),
        ];

        Setting::set(self::SMTP_OVERRIDE_KEY, $payload);
    }

    /**
     * @return array{
     *     days: array<int, string>,
     *     time: string,
     *     channels: array<int, string>
     * }
     */
    public function reminderRecurrence(): array
    {
        $stored = $this->asArray(Setting::get(self::REMINDER_RECURRENCE_KEY));
        $fallback = config('admin.reminders', []);

        $defaults = [
            'days' => ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
            'time' => '09:00',
            'channels' => ['mail', 'database'],
        ];

        $days = $this->normaliseDays($stored['days'] ?? $fallback['days'] ?? $defaults['days']);
        $channels = array_values(array_map('strtolower', $stored['channels'] ?? $fallback['channels'] ?? $defaults['channels']));
        $time = (string) ($stored['time'] ?? $fallback['time'] ?? $defaults['time']);

        if ($stored === []) {
            Setting::set(self::REMINDER_RECURRENCE_KEY, [
                'days' => $days ?: $defaults['days'],
                'time' => $time,
                'channels' => $channels ?: $defaults['channels'],
            ]);

            $stored = $this->asArray(Setting::get(self::REMINDER_RECURRENCE_KEY));

            $days = $this->normaliseDays($stored['days'] ?? $fallback['days'] ?? $defaults['days']);
            $channels = array_values(array_map('strtolower', $stored['channels'] ?? $fallback['channels'] ?? $defaults['channels']));
            $time = (string) ($stored['time'] ?? $fallback['time'] ?? $defaults['time']);
        } elseif (
            $days !== ($stored['days'] ?? [])
            || $channels !== ($stored['channels'] ?? [])
            || $time !== (string) ($stored['time'] ?? '')
        ) {
            Setting::set(self::REMINDER_RECURRENCE_KEY, [
                'days' => $days ?: $defaults['days'],
                'time' => $time,
                'channels' => $channels ?: $defaults['channels'],
            ]);
        }

        return [
            'days' => $days === [] ? $defaults['days'] : $days,
            'time' => $time,
            'channels' => $channels === [] ? $defaults['channels'] : $channels,
        ];
    }

    /**
     * @param  array{
     *     days?: array<int, string>,
     *     time?: string,
     *     channels?: array<int, string>
     * }  $values
     */
    public function setReminderRecurrence(array $values): void
    {
        $current = $this->reminderRecurrence();
        $days = $this->normaliseDays($values['days'] ?? $current['days']);
        $channels = array_values(array_map('strtolower', $values['channels'] ?? $current['channels']));

        Setting::set(self::REMINDER_RECURRENCE_KEY, array_merge($current, [
            'days' => $days === [] ? $current['days'] : $days,
            'time' => $values['time'] ?? $current['time'],
            'channels' => $channels === [] ? $current['channels'] : $channels,
        ]));
    }

    /**
     * @param  mixed  $value
     * @return array<string, mixed>
     */
    protected function asArray(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }

        return [];
    }

    /**
     * Use fallback when the value is null or an empty string.
     */
    protected function valueOrFallback(mixed $value, mixed $fallback): mixed
    {
        return $value === null || $value === '' ? $fallback : $value;
    }

    protected function boolValue(mixed $value, bool $fallback): bool
    {
        if ($value === null || $value === '') {
            return (bool) $fallback;
        }

        return (bool) $value;
    }

    /**
     * @param  array<int, string>  $days
     * @return array<int, string>
     */
    protected function normaliseDays(array $days): array
    {
        $aliases = [
            'mon' => 'monday',
            'monday' => 'monday',
            'tue' => 'tuesday',
            'tues' => 'tuesday',
            'tuesday' => 'tuesday',
            'wed' => 'wednesday',
            'weds' => 'wednesday',
            'wednesday' => 'wednesday',
            'thu' => 'thursday',
            'thurs' => 'thursday',
            'thursday' => 'thursday',
            'fri' => 'friday',
            'friday' => 'friday',
            'sat' => 'saturday',
            'saturday' => 'saturday',
            'sun' => 'sunday',
            'sunday' => 'sunday',
        ];

        $normalised = [];

        foreach ($days as $day) {
            $key = strtolower(trim((string) $day));
            $mapped = $aliases[$key] ?? null;

            if ($mapped) {
                $normalised[$mapped] = $mapped;
            }
        }

        return array_values($normalised);
    }
}
