<?php

namespace App\Services;

use Closure;

class ReminderMailConfigService
{
    public function __construct(
        protected SettingsService $settingsService,
    ) {}

    public function applyOverrideForReminders(Closure $callback): mixed
    {
        $override = $this->settingsService->smtpOverride();

        $originalMailer = config('mail.mailers.smtp');
        $originalFrom = config('mail.from');

        try {
            if ($this->shouldOverride($override)) {
                $smtpConfig = $originalMailer ?? [];

                $smtpConfig['host'] = $override['host'];
                $smtpConfig['port'] = $override['port'];
                $smtpConfig['username'] = $override['username'];
                $smtpConfig['password'] = $override['password'];
                $smtpConfig['encryption'] = $override['encryption'] ?? $smtpConfig['encryption'] ?? null;

                config()->set('mail.mailers.smtp', $smtpConfig);
            }

            return $callback();
        } finally {
            if ($originalMailer !== null) {
                config()->set('mail.mailers.smtp', $originalMailer);
            }

            if ($originalFrom !== null) {
                config()->set('mail.from', $originalFrom);
            }
        }
    }

    /**
     * @param  array<string, mixed>  $override
     */
    protected function shouldOverride(array $override): bool
    {
        return ($override['override_enabled'] ?? false) && ! empty($override['host']);
    }
}
