<?php

namespace App\Services;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplate;
use App\Models\FolderTemplateNode;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

class CompletenessService
{
    public function statusFor(User $user, CourseOffering $offering, Milestone $milestone): array
    {
        return Cache::rememberForever(
            $this->cacheKey($user, $offering, $milestone),
            fn () => $this->computeStatus($user, $offering, $milestone)
        );
    }

    public function invalidate(User $user, CourseOffering $offering, Milestone $milestone): void
    {
        Cache::forget($this->cacheKey($user, $offering, $milestone));
    }

    private function computeStatus(User $user, CourseOffering $offering, Milestone $milestone): array
    {
        $leafNodes = $this->leafNodesFor($milestone);

        if ($leafNodes->isEmpty()) {
            return [];
        }

        $baseQuery = Document::query()
            ->where('offering_id', $offering->getKey())
            ->where('milestone', $milestone->value);

        $totals = (clone $baseQuery)
            ->selectRaw('folder_slug, COUNT(*) as aggregate_count')
            ->groupBy('folder_slug')
            ->pluck('aggregate_count', 'folder_slug');

        $userTotals = (clone $baseQuery)
            ->selectRaw('folder_slug, COUNT(*) as user_count')
            ->where('uploader_id', $user->getKey())
            ->groupBy('folder_slug')
            ->pluck('user_count', 'folder_slug');

        return $leafNodes
            ->mapWithKeys(function (FolderTemplateNode $node) use ($totals, $userTotals): array {
                $folderSlug = $node->pathString();
                $total = (int) ($totals[$folderSlug] ?? 0);
                $userCount = (int) ($userTotals[$folderSlug] ?? 0);

                $required = (bool) $node->required;
                $done = $required ? $userCount > 0 : true;

                return [
                    $folderSlug => [
                        'required' => $required,
                        'you' => $userCount,
                        'total' => $total,
                        'done' => $done,
                    ],
                ];
            })
            ->all();
    }

    private function cacheKey(User $user, CourseOffering $offering, Milestone $milestone): string
    {
        return implode(':', [
            'completeness',
            $user->getKey(),
            $offering->getKey(),
            $milestone->value,
        ]);
    }

    /**
     * @return Collection<string, FolderTemplateNode>
     */
    private function leafNodesFor(Milestone $milestone): Collection
    {
        return FolderTemplate::query()
            ->where('milestone', $milestone)
            ->with(['leafNodes'])
            ->get()
            ->flatMap(fn (FolderTemplate $template) => $template->leafNodes)
            ->keyBy(fn (FolderTemplateNode $node) => $node->pathString());
    }
}
