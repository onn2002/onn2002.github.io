<?php

namespace App\Services;

use App\Support\FilenameSanitizer;
use DateTimeInterface;
use Illuminate\Support\Str;

class DocumentRenamer
{
    private const MAX_BASE_LENGTH = 200;

    public function __construct(
        private readonly FilenameSanitizer $sanitizer,
    ) {}

    /**
     * @param  callable(string):bool|null  $existsProbe
     */
    public function generate(string $originalName, string $courseCode, DateTimeInterface $mytNow, ?callable $existsProbe = null): string
    {
        $existsProbe ??= static fn (): bool => false;

        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $extension = $extension !== '' ? Str::of($extension)->lower()->toString() : '';

        $baseName = pathinfo($originalName, PATHINFO_FILENAME);
        $sanitizedBase = Str::of($this->sanitizer->sanitize($baseName))
            ->limit(self::MAX_BASE_LENGTH, '')
            ->trim()
            ->toString();

        if ($sanitizedBase === '') {
            $sanitizedBase = self::fallbackBaseName();
        }

        $courseSegment = $this->normaliseCourseCode($courseCode);
        $dateSegment = $mytNow->format('Ymd');

        $filename = $this->composeFilename($sanitizedBase, $courseSegment, $dateSegment, $extension);

        $suffix = 1;
        while ($existsProbe($filename)) {
            $suffix++;
            $filename = $this->composeFilename(
                $sanitizedBase,
                $courseSegment,
                $dateSegment,
                $extension,
                $suffix
            );
        }

        return $filename;
    }

    private function composeFilename(string $base, string $courseSegment, string $dateSegment, string $extension, int $suffix = 1): string
    {
        $name = "{$base}_{$courseSegment}_{$dateSegment}";

        if ($suffix > 1) {
            $name .= "_{$suffix}";
        }

        if ($extension === '') {
            return $name;
        }

        return "{$name}.{$extension}";
    }

    private function normaliseCourseCode(string $courseCode): string
    {
        $normalised = Str::of($courseCode)
            ->replace(['\\', '/'], '-')
            ->replaceMatches('/\s+/u', '')
            ->limit(50, '')
            ->toString();

        if ($normalised === '') {
            return 'course';
        }

        return $normalised;
    }

    private static function fallbackBaseName(): string
    {
        return 'file';
    }
}
