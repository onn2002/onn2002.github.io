<?php

namespace App\Services;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplateNode;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class DocumentOperationsService
{
    public function __construct(
        private readonly DocumentRenamer $renamer,
        private readonly FolderPathService $folderPathService,
    ) {}

    public function rename(Document $document, string $desiredName): Document
    {
        [$offering, $milestone] = $this->assertDocumentContext($document);

        $media = $this->resolveMedia($document);
        $disk = $this->disk();

        $directory = $this->folderPathService->buildPathFromSlug(
            $offering,
            $milestone,
            $document->folder_slug
        );

        $trimmedName = trim($desiredName);

        if ($trimmedName === '') {
            throw ValidationException::withMessages([
                'name' => 'Provide a valid file name.',
            ]);
        }

        $baseName = trim(pathinfo($trimmedName, PATHINFO_FILENAME));

        if ($baseName === '') {
            throw ValidationException::withMessages([
                'name' => 'Provide a valid file name.',
            ]);
        }

        $extension = pathinfo($media->file_name, PATHINFO_EXTENSION);
        $original = $extension !== ''
            ? sprintf('%s.%s', $baseName, $extension)
            : $baseName;

        $filename = $this->renamer->generate(
            $original,
            $this->resolveCourseCode($offering),
            CarbonImmutable::now('Asia/Kuala_Lumpur'),
            function (string $candidate) use ($disk, $directory, $media): bool {
                if ($candidate === $media->file_name) {
                    return false;
                }

                return $disk->exists($directory.$candidate);
            }
        );

        $mediaName = pathinfo($filename, PATHINFO_FILENAME);
        $oldPath = $media->getPathRelativeToRoot();
        $newPath = $directory.$filename;

        if ($oldPath !== $newPath) {
            $this->ensureDirectory($disk, $directory);

            if ($disk->exists($newPath) && $filename !== $media->file_name) {
                throw ValidationException::withMessages([
                    'file' => 'A document with this name already exists in the destination folder.',
                ]);
            }

            if (! $disk->move($oldPath, $newPath)) {
                throw ValidationException::withMessages([
                    'file' => 'Unable to rename the document on disk.',
                ]);
            }
        }

        DB::transaction(function () use ($document, $media, $filename, $mediaName): void {
            $media->forceFill([
                'file_name' => $filename,
                'name' => $mediaName,
            ])->save();

            $document->refreshMediaMetadata();
        });

        return $document->fresh();
    }

    public function move(Document $document, FolderTemplateNode $destination): Document
    {
        if (! $destination->isLeaf()) {
            throw ValidationException::withMessages([
                'folder' => 'Only leaf folders can receive documents.',
            ]);
        }

        $destination->loadMissing('folderTemplate');

        [$offering, $milestone] = $this->assertDocumentContext($document);
        $templateMilestone = $destination->folderTemplate?->milestone;

        if ($templateMilestone !== $milestone) {
            throw ValidationException::withMessages([
                'folder' => 'Selected folder is not part of this milestone.',
            ]);
        }

        $targetSlug = $destination->pathString();

        if ($targetSlug === $document->folder_slug) {
            return $document->fresh();
        }

        $media = $this->resolveMedia($document);
        $disk = $this->disk();

        $directory = $this->folderPathService->buildPath(
            $offering,
            $milestone,
            $destination
        );

        $currentPath = $media->getPathRelativeToRoot();
        $newFilename = $media->file_name;
        $newPath = $directory.$newFilename;

        if ($currentPath !== $newPath) {
            $this->ensureDirectory($disk, $directory);

            if ($disk->exists($newPath)) {
                $newFilename = $this->renamer->generate(
                    $document->original_filename ?? $media->file_name,
                    $this->resolveCourseCode($offering),
                    CarbonImmutable::now('Asia/Kuala_Lumpur'),
                    fn (string $candidate) => $disk->exists($directory.$candidate)
                );

                $newPath = $directory.$newFilename;
            }

            if (! $disk->move($currentPath, $newPath)) {
                throw ValidationException::withMessages([
                    'folder' => 'Unable to move the document to the selected folder.',
                ]);
            }
        }

        $mediaName = pathinfo($newFilename, PATHINFO_FILENAME);

        DB::transaction(function () use ($document, $targetSlug, $media, $newFilename, $mediaName): void {
            $document->forceFill([
                'folder_slug' => $targetSlug,
            ])->save();

            $media->forceFill([
                'file_name' => $newFilename,
                'name' => $mediaName,
            ])->save();

            $document->refreshMediaMetadata();
        });

        return $document->fresh();
    }

    public function replace(Document $document, UploadedFile $file): Document
    {
        $this->validateFile($file);

        [$offering, $milestone] = $this->assertDocumentContext($document);

        $media = $this->resolveMedia($document);
        $disk = $this->disk();
        $directory = $this->folderPathService->buildPathFromSlug(
            $offering,
            $milestone,
            $document->folder_slug
        );

        $original = $file->getClientOriginalName() ?: $file->getFilename();

        $filename = $this->renamer->generate(
            $original,
            $this->resolveCourseCode($offering),
            CarbonImmutable::now('Asia/Kuala_Lumpur'),
            function (string $candidate) use ($disk, $directory, $media): bool {
                if ($candidate === $media->file_name) {
                    return false;
                }

                return $disk->exists($directory.$candidate);
            }
        );

        $mediaName = pathinfo($filename, PATHINFO_FILENAME);

        $this->ensureDirectory($disk, $directory);

        DB::transaction(function () use ($document, $file, $filename, $mediaName): void {
            $document
                ->addMedia($file)
                ->usingName($mediaName)
                ->usingFileName($filename)
                ->toMediaCollection(Document::MEDIA_COLLECTION);

            $document->refreshMediaMetadata();
        });

        return $document->fresh();
    }

    public function delete(Document $document): void
    {
        $media = $document->getFirstMedia(Document::MEDIA_COLLECTION);

        DB::transaction(function () use ($document, $media): void {
            if ($media) {
                $media->delete();
            }

            $document->delete();
        });
    }

    private function disk(): Filesystem
    {
        return Storage::disk(config('media-library.disk_name', 'public'));
    }

    private function resolveMedia(Document $document): Media
    {
        $media = $document->getFirstMedia(Document::MEDIA_COLLECTION);

        if (! $media) {
            throw ValidationException::withMessages([
                'document' => 'Document media is missing.',
            ]);
        }

        return $media;
    }

    private function assertDocumentContext(Document $document): array
    {
        $document->loadMissing([
            'offering.programme',
            'offering.session',
            'offering.course',
        ]);

        $offering = $document->offering;
        $milestone = $document->milestone;
        $folder = $document->folder_slug;

        if (! $offering || ! $milestone instanceof Milestone || ! is_string($folder) || $folder === '') {
            throw ValidationException::withMessages([
                'document' => 'Document is missing required associations.',
            ]);
        }

        return [$offering, $milestone];
    }

    private function ensureDirectory(Filesystem $disk, string $directory): void
    {
        $disk->makeDirectory($directory);
    }

    private function resolveCourseCode(CourseOffering $offering): string
    {
        $course = $offering->course;

        if ($course && $course->course_code) {
            return $course->course_code;
        }

        return 'course-'.$offering->course_id;
    }

    private function validateFile(UploadedFile $file): void
    {
        $allowed = array_filter((array) config('admin.mime_whitelist', []));
        $mime = $file->getMimeType() ?: $file->getClientMimeType();

        if ($allowed !== [] && $mime && ! in_array($mime, $allowed, true)) {
            throw ValidationException::withMessages([
                'file' => "Files of type {$mime} are not permitted.",
            ]);
        }

        $maxMb = (int) config('admin.max_upload_mb', 25);
        $maxBytes = $maxMb > 0 ? $maxMb * 1024 * 1024 : null;
        $size = $file->getSize();

        if ($maxBytes !== null && $size !== false && $size > $maxBytes) {
            throw ValidationException::withMessages([
                'file' => sprintf('File exceeds the maximum size of %d MB.', $maxMb),
            ]);
        }
    }
}
