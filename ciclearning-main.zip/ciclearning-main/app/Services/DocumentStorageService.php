<?php

namespace App\Services;

use App\Enums\Milestone;
use App\Models\CourseOffering;
use App\Models\Document;
use App\Models\FolderTemplateNode;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class DocumentStorageService
{
    public function __construct(
        private readonly FolderPathService $folderPathService,
        private readonly DocumentRenamer $renamer,
    ) {}

    public function store(
        CourseOffering $offering,
        Milestone $milestone,
        FolderTemplateNode $leaf,
        UploadedFile $file,
        User $uploader,
    ): Document {
        $this->validateFile($file);

        $originalMime = $file->getClientMimeType() ?: $file->getMimeType();
        $originalSize = $file->getSize();

        $diskName = config('media-library.disk_name', 'public');
        $disk = Storage::disk($diskName);

        $directory = $this->folderPathService->buildPath($offering, $milestone, $leaf);
        $this->ensureDirectoryExists($diskName, $directory);

        $courseCode = $this->resolveCourseCode($offering);
        $timestamp = CarbonImmutable::now('Asia/Kuala_Lumpur');
        $originalName = $file->getClientOriginalName() ?: $file->getFilename();

        $filename = $this->renamer->generate(
            $originalName,
            $courseCode,
            $timestamp,
            fn (string $candidate) => $disk->exists($directory.$candidate),
        );

        $mediaName = pathinfo($filename, PATHINFO_FILENAME);

        $documentId = DB::transaction(function () use (
            $offering,
            $milestone,
            $leaf,
            $file,
            $uploader,
            $filename,
            $mediaName
        ): int {
            $document = Document::query()->create([
                'offering_id' => $offering->getKey(),
                'milestone' => $milestone,
                'folder_slug' => $leaf->pathString(),
                'uploader_id' => $uploader->getKey(),
            ]);

            $document
                ->addMedia($file)
                ->usingName($mediaName)
                ->usingFileName($filename)
                ->toMediaCollection(Document::MEDIA_COLLECTION);

            return $document->getKey();
        });

        $document = Document::query()->findOrFail($documentId);
        $document->refreshMediaMetadata();

        if ($originalSize !== false && $originalSize !== null && (int) $document->filesize === 0) {
            $document->forceFill(['filesize' => $originalSize])->saveQuietly();
        }

        if ($originalMime && $document->mime !== $originalMime) {
            $document->forceFill(['mime' => $originalMime])->saveQuietly();
        }

        return $document->refresh();
    }

    private function validateFile(UploadedFile $file): void
    {
        $allowed = array_filter((array) config('admin.mime_whitelist', []));
        $mime = $file->getMimeType() ?: $file->getClientMimeType();

        if ($allowed !== [] && $mime && ! in_array($mime, $allowed, true)) {
            throw ValidationException::withMessages([
                'file' => "Files of type {$mime} are not permitted.",
            ]);
        }

        $maxMb = (int) config('admin.max_upload_mb', 25);
        $maxBytes = $maxMb > 0 ? $maxMb * 1024 * 1024 : null;
        $size = $file->getSize();

        if ($maxBytes !== null && $size !== false && $size > $maxBytes) {
            throw ValidationException::withMessages([
                'file' => sprintf(
                    'File exceeds the maximum size of %d MB.',
                    $maxMb
                ),
            ]);
        }
    }

    private function resolveCourseCode(CourseOffering $offering): string
    {
        $courseCode = $offering->course?->course_code;

        if ($courseCode) {
            return $courseCode;
        }

        return 'course-'.$offering->course_id;
    }

    private function ensureDirectoryExists(string $diskName, string $directory): void
    {
        Storage::disk($diskName)->makeDirectory($directory);
    }
}
