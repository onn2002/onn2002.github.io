## ciclearning — Course Document Submission System (MVP)

Simple, role‑based uploads for course documents with an enforced folder structure, server‑side file renaming, per‑lecturer completeness tracking, and admin reporting/reminders. Built on Laravel + Filament with Spatie packages.

- Tech stack: Laravel 12 (PHP 8.2+), Filament Admin, spatie/laravel-permission, spatie/laravel-medialibrary, spatie/laravel-activitylog, Laravel Notifications (Email/DB; WhatsApp via Vonage planned)
- Timezone: Asia/Kuala_Lumpur (MYT) — configured in `config/app.php`
- Docs: see `docs/prd.md` (authoritative product spec) and `docs/features.md` (build plan)

## Getting Started

### Prerequisites

- PHP 8.2+ with extensions required by Laravel
- Composer
- Node 18+ and pnpm/npm (Vite)
- MySQL (default), or configure your preferred DB in `.env`

### Setup

1) Configure environment

```
cp .env.example .env
# Edit .env → DB_*, MAIL_*, QUEUE_CONNECTION=database, FILESYSTEM_DISK=local
```

2) Install and initialize

```
composer install
php artisan key:generate
php artisan migrate --force
pnpm install
pnpm run dev  # or: pnpm run build
```

Alternatively, the project includes helpful Composer scripts:

```
composer run setup  # installs deps, generates key, migrates, builds assets
composer run dev    # runs server + queue listener + logs + Vite (concurrently)
```

### Run locally

- App server: `php artisan serve` (or `composer run dev`)
- Vite dev server: `pnpm run dev` (bundled in `composer run dev`)
- Queue worker (database): `php artisan queue:work` (bundled in `composer run dev`)
- Scheduler: for reminders, run `php artisan schedule:work` in a separate process, or add a cron entry:

```
* * * * * cd /path/to/project && php artisan schedule:run >> /dev/null 2>&1
```

### Filament Panels

- Admin Panel: `/admin` (blue theme) for catalogue, configuration, and reporting tasks; requires the `admin` role.
  - **Access Control**: Users (with role assignment), Roles (permission management), Permissions (read-only list).
  - **Catalog**: Programmes, Academic Sessions, Courses, Course Offerings (with lecturer assignment), Folder Templates (tree management with drag-and-drop to three levels).
  - **System**: Activity Log (Spatie activity viewer) and Settings (env-backed upload/MIME/comms overrides; TODO: migrate to persistent storage).
- Lecturer Panel: `/lecturer` (green theme) for uploads and personal progress; accessible to users with the `lecturer` role (admins may also access it).
- Both panels share the `web` guard, require verified email addresses, and expose dedicated login pages at `/admin/login` and `/lecturer/login`.

### Creating users & assigning roles

Run `php artisan migrate:fresh --seed` to load the default roles (`admin`, `lecturer`) and demo accounts.

To create additional users manually:

```
php artisan tinker
>>> $user = \App\Models\User::factory()->create(['email' => 'new-admin@example.com']);
>>> $user->assignRole('admin'); // or 'lecturer'
```

## Key Behaviors (from PRD)

- Path structure (enforced): `{programme_code}/{semester_code}/{course_identifier}/{milestone}/{folder_path}/` (where `folder_path` may contain nested segments)
- Server‑side rename: `{original_base_name_sanitized}_{course_code}_{YYYYMMDD}.{ext}` (MYT date; collisions append `_{n}`)
- Roles: `admin`, `lecturer` (Spatie Permission)
- Completeness: ✅/❌ per lecturer for each required folder
- Notifications: Email and in‑app; WhatsApp (Vonage) planned in MVP scope
- Audit: All file ops and key actions recorded (spatie/activitylog)

See full spec: `docs/prd.md`.

## Configuration Notes

- Timezone is set to `Asia/Kuala_Lumpur` in `config/app.php`.
- Filesystem `local` disk is configured at `storage/app/private` and served through Laravel (no public symlink required for private files). Use `public` disk for public assets if needed (`php artisan storage:link`).
- Email defaults to `MAIL_MAILER=log`. Configure SMTP in `.env` to send real email; admin overrides can be set via the Admin “Settings” page, which writes to `ADMIN_SMTP_*` env keys.
- WhatsApp/Vonage integration is planned; override fields in the Settings page persist to `ADMIN_WHATSAPP_*` env keys but are not consumed yet.
- Upload constraints (MIME whitelist, max upload size) are consolidated in `config/admin.php` and can be edited from the Admin Settings page (persisted to `.env`).

## Scripts and Tooling

- Test suite: `composer test` (Pest) — basic Laravel tests scaffolded
- Code style: `vendor/bin/pint`
- Useful: `php artisan migrate:fresh` during development

## Roadmap / Next Steps

- Implement the document upload/rename pipeline (path rules, collision handling) and expose it in the Lecturer panel.
- Surface lecturer completeness dashboards and admin reminder workflows (automated + manual triggers).
- Persist admin settings to a durable store (database/settings table) instead of `.env`, and extend coverage to media constraints.
- Integrate Vonage WhatsApp overrides once comms requirements are finalised.

Refer to `docs/features.md` for the suggested implementation sequence and `docs/prd.md` for acceptance criteria.
